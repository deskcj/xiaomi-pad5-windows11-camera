﻿$ErrorActionPreference='Stop';Set-StrictMode -Version Latest
$project=Split-Path -Parent $PSScriptRoot;$driver=Join-Path $project 'release\Driver'
. (Join-Path $driver 'Tools\CameraPackages.ps1')
$passed=[Collections.Generic.List[string]]::new()
function Assert([bool]$Ok,[string]$Name){if(-not $Ok){throw ('FAIL '+$Name)};$passed.Add($Name)}
$fixture=@'
[Version]
Class=Extension
ExtensionId={7649844B-A877-45EA-82D1-209503372162}
[Manufacturer]
%QC%=QC,NTARM64
[QC.NTARM64]
%Sensor%=Sensor,ACPI\QCOM0506
%Sensor%=Sensor,ACPI\VEN_QCOM&DEV_0506
[Sensor.NT.HW]
AddReg=SensorReg
[SensorReg]
HKR,,"CameraImagesPath",0x00000000,"%13%"
'@
Assert (Test-ConflictingSensorExtension $fixture) 'Associated Extension redirects front camera data independently of InfPath'
Assert (Test-ConflictingSensorExtension ($fixture.Replace('0506','0529'))) 'Rear sensor data extension detected'
Assert (-not(Test-ConflictingSensorExtension ($fixture.Replace('Class=Extension','Class=Camera')))) 'Primary sensor driver cannot enter extension uninstall'
Assert (-not(Test-ConflictingSensorExtension ($fixture.Replace('CameraImagesPath','OtherSetting')))) 'Unrelated extension settings preserved'
Assert (-not(Test-ConflictingSensorExtension ($fixture.Replace('0506','0535')))) 'Platform extension preserved'
Assert (-not(Test-ConflictingSensorExtension ($fixture+"`n[QC.NTARM64]`n%Other%=Other,PCI\VEN_1234"))) 'Mixed model list prevents uninstall'
Assert (-not(Test-ConflictingSensorExtension ($fixture.Replace('ACPI\VEN_QCOM&DEV_0506','ACPI\UNKNOWN')))) 'Unknown compatible ID prevents uninstall'
Assert (Test-CameraOnlyHardwareId '*QCOM0506') 'Windows generic sensor compatible ID recognized for phantom cleanup'
Assert (-not(Test-CameraOnlyHardwareId '*QCOM0535')) 'Generic platform ID remains protected'
$phantom=[pscustomobject]@{id='ACPI\QCOM0506\old';hardware=@('ACPI\VEN_QCOM&DEV_0506&SUBSYS_MTPA8150','ACPI\QCOM0506','*QCOM0506')}
Assert (@(Select-StaleCameraDevices @($phantom) @()).Count -eq 1) 'Disconnected sensor with actual Windows compatible IDs selected'
Assert (@(Select-StaleCameraDevices @($phantom) @($phantom.id)).Count -eq 0) 'Present sensor never selected as phantom'
Assert (Test-CameraOnlyHardwareId 'VIDEO\VEN_4D4F4351&DEV_41333530&SUBSYS_303531384150544D&REV_506&QCOM_AVStream_8150') 'Exact native camera AVStream compatible ID recognized'
$out=Join-Path $project ('work\sensor-extension-tests-'+[guid]::NewGuid().ToString('N'));New-Item -ItemType Directory -Path $out|Out-Null
$script:mode='PASS';$script:calls=[Collections.Generic.List[string]]::new();$script:candidate=$null
# Mock only the Windows process boundary; file mutations stay in the fixture.
function Invoke-CameraPackageTool([string[]]$Arguments,[string]$LogPrefix){
 $script:calls.Add(($Arguments -join '|'))
 if($Arguments[0] -eq '/export-driver'){
  if($script:mode -eq 'PENDING_EXPORT'){return [pscustomobject]@{pending=$true;pid=42;creation='test';code=$null}}
  if($script:mode -ne 'BAD_EXPORT'){Copy-Item -LiteralPath $script:candidate.path -Destination (Join-Path $Arguments[2].Trim('"') 'sensor.inf')}
  return [pscustomobject]@{pending=$false;pid=0;creation='';code=0}
 }
 if($script:mode -eq 'PENDING_DELETE'){return [pscustomobject]@{pending=$true;pid=43;creation='test';code=$null}}
 if($script:mode -eq 'REFUSED'){return [pscustomobject]@{pending=$false;pid=0;creation='';code=-536870339}}
 if($script:mode -eq 'REBOOT'){return [pscustomobject]@{pending=$false;pid=0;creation='';code=3010}}
 if($script:mode -ne 'FALSE_SUCCESS'){Remove-Item -LiteralPath $script:candidate.path}
 return [pscustomobject]@{pending=$false;pid=0;creation='';code=0}
}
function Run-Case([string]$Mode){
 $script:mode=$Mode;$script:calls.Clear();$dir=Join-Path $out $Mode;New-Item -ItemType Directory -Path $dir|Out-Null
 $inf=Join-Path $dir 'oem123.inf';[IO.File]::WriteAllText($inf,$fixture)
 $script:candidate=[pscustomobject]@{inf='oem123.inf';path=$inf;sha256=(Get-FileHash -LiteralPath $inf).Hash}
 return Remove-ConflictingSensorExtensions (Join-Path $dir 'Logs') @($script:candidate)
}
$r=Run-Case 'PASS'
Assert ($r.status -eq 'COMPLETE' -and $r.removed.Count -eq 1 -and $r.backups.Count -eq 1 -and -not $r.rebootRequired) 'Exact backup precedes successful extension detach'
Assert ($script:calls[0].StartsWith('/export-driver|') -and $script:calls[1] -eq '/delete-driver|oem123.inf|/uninstall') 'Only extension delete uses uninstall without force'
$r=Run-Case 'BAD_EXPORT';Assert ($r.status -eq 'FAILED' -and $script:calls.Count -eq 1 -and (Test-Path -LiteralPath $script:candidate.path)) 'Incomplete backup blocks deletion'
$r=Run-Case 'REFUSED';Assert ($r.status -eq 'FAILED' -and $r.retained[0].code -eq -536870339 -and -not $r.rebootRequired) 'Windows refusal reports failure without force or reboot loop'
$r=Run-Case 'FALSE_SUCCESS';Assert ($r.status -eq 'FAILED') 'Present extension cannot be called removed on zero exit alone'
$r=Run-Case 'REBOOT';Assert ($r.status -eq 'PENDING_RESTART' -and $r.rebootRequired -and $r.removed.Count -eq 0) 'Pending removal needs restart verification'
$r=Run-Case 'PENDING_EXPORT';Assert ($r.status -eq 'PENDING_PROCESS' -and $r.pendingPid -eq 42 -and $script:calls.Count -eq 1) 'Running export blocks further changes'
$r=Run-Case 'PENDING_DELETE';Assert ($r.status -eq 'PENDING_PROCESS' -and $r.pendingPid -eq 43) 'Running detach preserves process identity'
$script:candidate.sha256='changed';$script:calls.Clear()
$r=Remove-ConflictingSensorExtensions (Join-Path $out 'changed') @($script:candidate)
Assert ($r.status -eq 'FAILED' -and $script:calls.Count -eq 0) 'Changed package never uninstalled'
# Test actual engine orchestration using simulated sensor state.
$tokens=$null;$errors=$null;$ast=[Management.Automation.Language.Parser]::ParseFile((Join-Path $driver 'Setup.ps1'),[ref]$tokens,[ref]$errors)
Assert ($errors.Count -eq 0) 'Engine parses in PowerShell 5.1'
$fn=$ast.FindAll({param($n)$n -is [Management.Automation.Language.FunctionDefinitionAst] -and $n.Name -eq 'Repair-SensorExtensionData'},$true)[0]
. ([scriptblock]::Create($fn.Extent.Text))
$script:order=[Collections.Generic.List[string]]::new()
function Get-ConflictingSensorExtensions {return @([pscustomobject]@{inf='oem55.inf'},[pscustomobject]@{inf='oem129.inf'})}
function Assert-Idle {$script:order.Add('idle')}
function Progress([int]$P,[string]$Text) {}
function Find-Physical([string]$Slot){return [pscustomobject]@{id=$Slot}}
function Enable-Node([string]$Id,[bool]$Enabled,[string]$Label,[switch]$DeferRestart){$script:order.Add($Id+':'+$Enabled);Assert ([bool]$DeferRestart) ('Restart batched: '+$Label)}
function Save-State {}
function Note([string]$Text) {}
function Set-QispData {$script:order.Add('data-restored')}
function Remove-ConflictingSensorExtensions([string]$Root,[object[]]$Candidates){$script:order.Add('detach');return [ordered]@{status='COMPLETE';rebootRequired=$false;removed=@('oem55.inf','oem129.inf')}}
$r=[ordered]@{driverActions=$false;rebootRequired=$false};$run=$out
Repair-SensorExtensionData
Assert (($script:order -join ',') -eq 'idle,front:False,rear:False,detach,data-restored,front:True,rear:True') 'Both extensions detached with sensors stopped and data restored before enabling'
Assert ($r.driverActions -and $r.extensionCleanup.removed.Count -eq 2) 'Extension mutations recorded in state'
[ordered]@{status='PASS';count=$passed.Count;tests=$passed;driverChanged=$false;cameraOpened=$false;actualReboot=$false}|ConvertTo-Json -Depth 6|Set-Content -LiteralPath (Join-Path $PSScriptRoot 'sensor-extension-results.json') -Encoding UTF8
Write-Output ('PASS_SENSOR_EXTENSIONS count='+$passed.Count)
