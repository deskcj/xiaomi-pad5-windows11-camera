﻿$ErrorActionPreference='Stop';Set-StrictMode -Version Latest
. (Join-Path (Split-Path -Parent $PSScriptRoot) 'release\Driver\Tools\FlashEvidence.ps1')
$out=Join-Path (Split-Path -Parent $PSScriptRoot) 'work\flash-evidence-tests';New-Item -ItemType Directory -Path $out -Force|Out-Null
$tests=[Collections.Generic.List[string]]::new()
function Assert([bool]$Ok,[string]$Name){if(-not $Ok){throw ('FAIL '+$Name)};$tests.Add($Name)}
function Case([string]$Name,[string[]]$Messages){
 $file=Join-Path $out ($Name+'.jsonl');$rows=@();$i=0;foreach($text in $Messages){$rows+=([ordered]@{index=++$i;text=$text}|ConvertTo-Json -Compress)}
 [IO.File]::WriteAllLines($file,$rows,[Text.UTF8Encoding]::new($false));return Get-CameraFlashEvidence $file
}
$fail='[ERROR][SENSOR ] camxflash.cpp:752 CamX::Flash::CreateInitializePacket() Flash init command faled Flash device 4'
$success='[ VERB][SENSOR ] camxflash.cpp:745 CamX::Flash::CreateInitializePacket() Flash init command success Flash device 4'
$low='[ INFO][SENSOR ] camxflash.cpp:1065 CamX::Flash::FirePMIC() SENSOR_FLASH_DEBUG: Flash Operation: Low: numberOfFlashs = 2 1:2 = 300 : 300'
$off='[ INFO][SENSOR ] camxflash.cpp:1056 CamX::Flash::FirePMIC() SENSOR_FLASH_DEBUG: Flash Operation: OFF'
$high='[ INFO][SENSOR ] camxflash.cpp:1079 CamX::Flash::FirePMIC() SENSOR_FLASH_DEBUG: Flash Operation: High: numberOfFlashs = 2 1:2 = 122 : 778'
$r=Case 'failed' @($fail);Assert ($r.status -eq 'FLASH_DRIVER_FAILURE' -and $r.initFailed -eq 1) 'Real vendor typo faled is a flash failure despite successful video'
$r=Case 'mixed' @($success,$fail,$low);Assert ($r.status -eq 'FLASH_DRIVER_FAILURE') 'Later error cannot be hidden by a success marker or a low command'
$r=Case 'torch' @($success,$low,$off);Assert ($r.initSucceeded -eq 1 -and $r.lowCommands -eq 1 -and $r.offCommands -eq 1 -and -not $r.physicalEmissionVerified) 'Torch commands are distinct from physical emission proof'
$r=Case 'photo' @($success,$low,$off,$high);Assert ($r.highCommands -eq 1 -and -not $r.physicalEmissionVerified) 'Photo high command does not claim measured light'
$r=Case 'absent' @('Camera stream produced frames');Assert ($r.status -eq 'NO_FLASH_MARKERS') 'No flash instrumentation is never confirmed initialization'
$r=Case 'spelling' @($fail.Replace('faled','failed'));Assert ($r.status -eq 'FLASH_DRIVER_FAILURE') 'Standard failed spelling is also rejected'
$r=Case 'otherError' @('[ERROR][SENSOR ] camxflash.cpp:1000 CamX::Flash::FirePMIC() ioctl error');Assert ($r.status -eq 'FLASH_DRIVER_FAILURE') 'Explicit flash runtime failure is fatal'
$r=Case 'bounded' @(@($fail)*30);Assert ($r.initFailed -eq 30 -and $r.errors.Count -eq 20) 'All failures counted while report storage remains bounded'
[ordered]@{status='PASS';count=$tests.Count;tests=$tests;hardwareActions=$false}|ConvertTo-Json -Depth 4|Set-Content -LiteralPath (Join-Path $out 'results.json') -Encoding UTF8
'PASS_FLASH_EVIDENCE count='+$tests.Count
