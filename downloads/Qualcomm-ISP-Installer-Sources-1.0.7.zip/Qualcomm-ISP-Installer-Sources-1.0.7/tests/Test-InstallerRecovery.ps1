﻿param([string]$ReportRoot=(Join-Path (Split-Path -Parent $PSScriptRoot) 'work\reports\user-123711'))
$ErrorActionPreference='Stop';Set-StrictMode -Version Latest
$project=Split-Path -Parent $PSScriptRoot;$driver=Join-Path $project 'release\Driver'
if(-not(Test-Path -LiteralPath $ReportRoot)){$ReportRoot=Join-Path $PSScriptRoot 'fixtures\regression-1.0.4'}
. (Join-Path $driver 'Tools\CameraSelection.ps1')
. (Join-Path $driver 'Tools\CaptureEvidence.ps1')
. (Join-Path $driver 'Tools\FlashEvidence.ps1')
. (Join-Path $driver 'Tools\CameraPrerequisites.ps1')
$passed=[Collections.Generic.List[string]]::new()
function Assert([bool]$ok,[string]$name){if(-not $ok){throw ('FAIL '+$name)};$passed.Add($name)}
function Reject([scriptblock]$action,[string]$name){$caught=$false;try{& $action|Out-Null}catch{$caught=$true};Assert $caught $name}
$out=Join-Path $project 'work\recovery-tests';New-Item -ItemType Directory -Path $out -Force|Out-Null
$engine=Join-Path $ReportRoot 'Engine\QISP253-20261107-123503-d62025'
$text=Get-Content -LiteralPath (Join-Path $engine 'verify-rear-probe.out.log') -Raw -Encoding UTF8
$close=Get-Content -LiteralPath (Join-Path $engine 'verify-rear\native-close.json') -Raw -Encoding UTF8|ConvertFrom-Json
$decode=Get-Content -LiteralPath (Join-Path $engine 'verify-rear\mft-decode.json') -Raw -Encoding UTF8|ConvertFrom-Json
$state=[pscustomobject]@{pendingPid=0;unsafeToContinue=$false;captureClosed=$true;fullMftDecoded=$true}
Assert (Test-OperationalCapture $text $close $decode $state) 'Real 186-frame report passes operational verification without claiming native debug success'
Assert (-not $close.nativeCloseSucceeded) 'Missing native evidence remains unconfirmed in the saved report'
$state.captureClosed=$false;Assert (-not(Test-OperationalCapture $text $close $decode $state)) 'An unclosed reader cannot bypass retirement';$state.captureClosed=$true
$state.unsafeToContinue=$true;Assert (-not(Test-OperationalCapture $text $close $decode $state)) 'A real unsafe state is retained';$state.unsafeToContinue=$false
$decode.eventsLost=1;Assert (-not(Test-OperationalCapture $text $close $decode $state)) 'Lost MFT events reject the fallback';$decode.eventsLost=0
$close.errors=@('ICP close failure');Assert (-not(Test-OperationalCapture $text $close $decode $state)) 'Explicit native driver failure is never suppressed';$close.errors=@()
$close.markers=@([pscustomobject]@{kind='ICP_CLOSE_SUCCESS'});Assert (-not(Test-OperationalCapture $text $close $decode $state)) 'Partial native instrumentation cannot masquerade as absent instrumentation';$close.markers=@()
Assert (-not(Test-OperationalCapture ($text.Replace('signal=true','signal=false')) $close $decode $state)) 'Blank camera output is not successful'
Assert (-not(Test-OperationalCapture ($text.Replace('CLOSE256 reader_close hr=00000000','CLOSE256 reader_close hr=80004005')) $close $decode $state)) 'HRESULT close failures remain fatal'
Assert (-not(Test-OperationalCapture ($text+"`n"+$text) $close $decode $state)) 'Duplicate lifecycle/result records are rejected'

$tokens=$null;$errors=$null;$ast=[Management.Automation.Language.Parser]::ParseFile((Join-Path $driver 'Setup.ps1'),[ref]$tokens,[ref]$errors)
Assert ($errors.Count -eq 0) 'New driver engine parses'
$capture=$ast.FindAll({param($n)$n -is [Management.Automation.Language.FunctionDefinitionAst] -and $n.Name -eq 'Capture-One'},$true)[0]
. ([scriptblock]::Create($capture.Extent.Text))
# Execute the actual Capture-One control flow using the real report. Hardware calls
# are stubbed; native diagnostic rejection is injected at the child-process boundary.
Add-Type 'public static class PadCameraNative { public static int NtQueryDebugFilterState(uint c,uint l){return 1;} public static int NtSetDebugFilterState(uint c,uint l,byte e){return 0;} }'
function Assert-Idle {}
function Memory-Guard {}
function Get-CameraInventory {return @()}
function Select-NativeCamera {return [pscustomobject]@{id='mock-native'}}
function Find-Physical {return [pscustomobject]@{id='mock-avs'}}
function Get-NativeLoggingSnapshot {return [pscustomobject]@{mock=$true}}
function Save-State {}
function Note([string]$message) {}
$calls=[Collections.Generic.List[string]]::new()
$script:fixtureText=$text;$script:fixtureClose=$close;$script:fixtureDecode=$decode
function Run-Child([string]$label,[string]$exe,[string[]]$arguments,[int]$timeout=60000){
 $calls.Add($label)
 if($label -match '-probe$'){
  [IO.File]::WriteAllText((Join-Path $run ($label+'.out.log')),$script:fixtureText)
  return $script:fixtureText
 }
 if($label -match '-native-close$'){
  $dir=Join-Path $run ($label -replace '-native-close$','')
  $script:fixtureClose|ConvertTo-Json -Depth 8|Set-Content -LiteralPath (Join-Path $dir 'native-close.json') -Encoding UTF8
  throw 'Injected missing native debug markers'
 }
 if($label -match '-mft-decode$'){$dir=Join-Path $run ($label -replace '-mft-decode$','');$script:fixtureDecode|ConvertTo-Json -Depth 8|Set-Content -LiteralPath (Join-Path $dir 'mft-decode.json') -Encoding UTF8;[IO.File]::WriteAllText((Join-Path $dir 'mft.jsonl'),'{}',[Text.UTF8Encoding]::new($false))}
 return ''
}
$root=$driver;$run=Join-Path $out ('capture-'+[guid]::NewGuid().ToString('N'));New-Item -ItemType Directory -Path $run|Out-Null
$r=[ordered]@{pendingPid=0;unsafeToContinue=$false;captureClosed=$true;fullMftDecoded=$true;warnings=@();captures=@();errors=@();rebootRequired=$false}
$script:sessions=@();$CaptureSeconds=8;$PreviewMap='';$LivePreview=$false;$Mode='Install';$CameraSide='both'
Capture-One 'rear' 'verify-rear' $true;Capture-One 'front' 'verify-front' $true
Assert ($r.captures.Count -eq 2 -and $r.warnings.Count -eq 2 -and -not $r.unsafeToContinue -and $r.captureClosed -and $r.fullMftDecoded) 'Actual capture flow proceeds to front camera after rear optional-log warning'
Assert (@($r.captures|Where-Object {$_.nativeCloseVerified}).Count -eq 0) 'Operational success never claims native hardware close proof'
Assert ($calls.Contains('verify-front-probe') -and $calls.Contains('verify-front-mft-decode')) 'Both independent capture and full trace checks actually run'

$platform=[pscustomobject]@{id='ACPI\QCOM0535\1B';problem=28}
$plan=Get-CameraPrerequisitePlan @($platform)
Assert ($plan.eligible -and $plan.needsRepair -and $plan.entries[0].spec.hardware -eq 'ACPI\QCOM0535') 'Real second-report Code28 platform is recoverable without requiring its missing children first'
Assert (-not (Get-CameraPrerequisitePlan @()).eligible) 'Missing ACPI platform cannot be manufactured by this installer'
Assert (-not (Get-CameraPrerequisitePlan @($platform,$platform)).eligible) 'Ambiguous platform devices reject a guessed binding'
$devices=@($platform,[pscustomobject]@{id='ACPI\QCOM0536\17';problem=0},[pscustomobject]@{id='ACPI\QCOM052A\19';problem=0});$platform.problem=0
Assert (-not (Get-CameraPrerequisitePlan $devices).needsRepair) 'Healthy base camera drivers need no replacement'
function Get-Service {return [pscustomobject]@{Status='Stopped'}}
function Get-Process {return @()}
function Import-PackageCertificates {}
$script:baseDevices=@([pscustomobject]@{id='ACPI\QCOM0535\1B';problem=28})
function Get-PrerequisiteNodes {return $script:baseDevices}
$script:baseCalls=[Collections.Generic.List[string]]::new()
function Progress([int]$percent,[string]$phase) {}
function Run-Child([string]$label,[string]$exe,[string[]]$arguments,[int]$timeout=60000){
 $script:baseCalls.Add($label)
 if($label -eq 'prerequisite-platform'){
  Assert ($arguments[0] -eq 'update' -and $arguments[2] -eq 'ACPI\QCOM0535') 'Platform repair targets its exact real ACPI hardware ID'
  $script:baseDevices=@([pscustomobject]@{id='ACPI\QCOM0535\1B';problem=0},[pscustomobject]@{id='ACPI\QCOM0536\17';problem=0},[pscustomobject]@{id='ACPI\QCOM052A\19';problem=0})
 }
 return ''
}
. (Join-Path $driver 'Tools\CameraPackages.ps1')
Repair-CameraPrerequisites
Assert ($r.prerequisiteRepair.status -eq 'COMPLETE' -and $script:baseCalls.Contains('prerequisite-platform') -and -not $script:baseCalls.Contains('prerequisite-jpeg') -and -not $script:baseCalls.Contains('prerequisite-flash')) 'Actual prerequisite flow restores missing parent then retains children that become healthy'
Assert (@(Get-CameraPackageModels ([IO.File]::ReadAllText((Join-Path $driver 'Prerequisites\platform\qccamplatform8150.inf')))).Count -eq 0) 'Cleanup whitelist never removes the camera platform prerequisite'
Assert (@(Get-CameraPackageModels ([IO.File]::ReadAllText((Join-Path $driver 'Prerequisites\jpeg\qccamjpege_ffu8150.inf')))).Count -eq 0) 'Cleanup whitelist never removes the JPEG prerequisite'
Assert (@(Get-CameraPackageModels ([IO.File]::ReadAllText((Join-Path $driver 'Prerequisites\flash\qccamflash8150.inf')))).Count -eq 0) 'Cleanup whitelist never removes the flash prerequisite'

# Stream compact XML too: ReadElementContentAsString already advances the reader.
$xml=Join-Path $out 'compact.xml';$verdict=Join-Path $out 'compact.json'
'<Events><Event><EventData><Data Name="Message">successfully initialized IFE0!</Data><Data Name="Message">CCaptureFilter::StopVideo INITIALIZED</Data><Data Name="Message">ICP: device close failed</Data><Data Name="Message">successfully closed IFE!</Data></EventData></Event></Events>'|Set-Content -LiteralPath $xml -Encoding UTF8
$p=Start-Process "$env:windir\System32\WindowsPowerShell\v1.0\powershell.exe" -ArgumentList @('-NoProfile','-ExecutionPolicy','Bypass','-File',('"'+(Join-Path $driver 'Tools\Check-NativeClose.ps1')+'"'),'-XmlFile',('"'+$xml+'"'),'-OutputFile',('"'+$verdict+'"')) -WindowStyle Hidden -Wait -PassThru -RedirectStandardError (Join-Path $out 'compact.err.log')
$v=Get-Content -LiteralPath $verdict -Raw|ConvertFrom-Json
Assert ($v.messageCount -eq 4 -and $v.evidenceStatus -eq 'EXPLICIT_DRIVER_FAILURE' -and $p.ExitCode -ne 0) 'Compact XML does not skip adjacent messages or hide an explicit close failure'
foreach($spec in $plan.entries.spec){Assert (Test-Path -LiteralPath (Join-Path $driver $spec.inf)) ('Complete bundled prerequisite INF: '+$spec.slot)}
[ordered]@{status='PASS';count=$passed.Count;tests=$passed;driverChanged=$false;cameraOpened=$false;actualReboot=$false}|ConvertTo-Json -Depth 6|Set-Content -LiteralPath (Join-Path $PSScriptRoot 'installer-recovery-results.json') -Encoding UTF8
Write-Output ('PASS_INSTALLER_RECOVERY count='+$passed.Count)
