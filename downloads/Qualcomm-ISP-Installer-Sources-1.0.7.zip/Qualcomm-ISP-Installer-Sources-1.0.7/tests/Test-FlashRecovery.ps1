﻿$ErrorActionPreference='Stop';Set-StrictMode -Version Latest
$build=Split-Path -Parent $PSScriptRoot;$driver=Join-Path $build 'release\Driver';. (Join-Path $driver 'Tools\CameraFlashRecovery.ps1')
$tests=[Collections.Generic.List[string]]::new()
function Assert([bool]$Ok,[string]$Name){if(-not $Ok){throw ('FAIL '+$Name)};$tests.Add($Name)}
function Reject([scriptblock]$Action,[string]$Name){$caught=$false;try{& $Action|Out-Null}catch{$caught=$true};Assert $caught $Name}
function State{return [ordered]@{pendingPid=0;unsafeToContinue=$false;captureClosed=$true;fullMftDecoded=$true;rebootRequired=$false;captures=@();warnings=@()}}
$s=State;Assert (Test-FlashRecoveryAllowed $s) 'One flash recovery allowed after confirmed capture and trace completion'
foreach($field in 'pendingPid','unsafeToContinue','rebootRequired'){$s=State;$s[$field]=1;Assert (-not(Test-FlashRecoveryAllowed $s)) ('No flash mutation while '+$field)}
foreach($field in 'captureClosed','fullMftDecoded'){$s=State;$s[$field]=$false;Assert (-not(Test-FlashRecoveryAllowed $s)) ('No flash mutation without '+$field)}
$s=State;$s.flashRecoveryAttempts=1;Assert (-not(Test-FlashRecoveryAllowed $s)) 'Repeated failure cannot reset flash indefinitely'
$tokens=$null;$errors=$null;$ast=[Management.Automation.Language.Parser]::ParseFile((Join-Path $driver 'Setup.ps1'),[ref]$tokens,[ref]$errors)
Assert ($errors.Count -eq 0) 'Experimental engine parses in Windows PowerShell 5.1'
$fn=$ast.FindAll({param($n)$n -is [Management.Automation.Language.FunctionDefinitionAst] -and $n.Name -eq 'Capture-WithWarmStartRetry'},$true)[0];. ([scriptblock]::Create($fn.Extent.Text))
$script:calls=[Collections.Generic.List[string]]::new();$script:failureMode='ONCE'
function Save-State {}
function Note([string]$Text) {}
function Capture-One([string]$Side,[string]$Label,[bool]$Native){
 $script:calls.Add('capture:'+ $Label)
 if($script:calls.Count -eq 1 -or $script:failureMode -eq 'ALWAYS'){
  $r.flashChecks=@([ordered]@{label=$Label;evidence=[ordered]@{status='FLASH_DRIVER_FAILURE'}})
  throw 'Real flash init failure; video frame result would otherwise pass'
 }
 $r.captures+=@([ordered]@{side=$Side;label=$Label})
}
$restartFn=${function:Restart-CameraFlashDevice}
function Restart-CameraFlashDevice([string]$Label){$script:calls.Add('restart:'+ $Label)}
$r=State;$Mode='Install';$run=Join-Path $build 'work\missing-fixture';Capture-WithWarmStartRetry 'rear' 'verify-rear' $true
Assert (($script:calls -join ',') -eq 'capture:verify-rear,restart:flash-init-recovery,capture:verify-rear-flash-retry1') 'Actual control flow restarts only flash and retries capture once'
Assert ($r.flashRecoveryAttempts -eq 1 -and $r.warnings.Count -eq 1 -and $r.captures.Count -eq 1) 'Original flash failure retained as recovered warning after a real second capture'
$r=State;$script:calls.Clear();$script:failureMode='ALWAYS';Reject {Capture-WithWarmStartRetry 'rear' 'verify-rear' $true} 'Second flash failure propagates without recursive recovery'
Assert (@($script:calls|Where-Object {$_ -like 'restart:*'}).Count -eq 1) 'Persistent failure causes only one flash reset'
$r=State;$r.captureClosed=$false;$script:calls.Clear();Reject {Capture-WithWarmStartRetry 'rear' 'verify-rear' $true} 'Unclosed camera blocks flash recovery'
Assert (@($script:calls|Where-Object {$_ -like 'restart:*'}).Count -eq 0) 'No device action follows unsafe closure'
$r=State;$Mode='Diagnose';$script:calls.Clear();Reject {Capture-WithWarmStartRetry 'rear' 'verify-rear' $true} 'Diagnose mode never changes a device on flash failure'
Assert (@($script:calls|Where-Object {$_ -like 'restart:*'}).Count -eq 0) 'Diagnostic failure does not trigger install repair'
# Execute the actual targeted PnP helper using only simulated OS calls.
Set-Item -Path Function:\Restart-CameraFlashDevice -Value $restartFn
function Assert-Idle {}
function Get-PrerequisiteNodes{return @([pscustomobject]@{id='ACPI\QCOM052A\19';problem=0})}
function Problem([string]$Id){return 0}
function Run-Child([string]$Label,[string]$Exe,[string[]]$Arguments,[int]$Timeout,[switch]$DeferRestart){Assert (($Arguments -join '|') -eq '/restart-device|"ACPI\QCOM052A\19"') 'Only the real ACPI flash device is restarted';Assert ([bool]$DeferRestart) 'Windows restart status is batched';return ''}
$r=State;Restart-CameraFlashDevice 'flash-test'
Assert ($r.driverActions -and $r.flashDeviceRestarts.Count -eq 1 -and -not $r.flashDeviceRestarts[0].forceUsed) 'Targeted flash action is journaled without force'
function Get-PrerequisiteNodes{return @([pscustomobject]@{id='ACPI\QCOM052A\19';problem=0},[pscustomobject]@{id='ACPI\QCOM052A\other';problem=0})}
$r=State;Reject {Restart-CameraFlashDevice 'ambiguous'} 'Ambiguous flash device list rejects a guessed restart'
[ordered]@{status='PASS';count=$tests.Count;tests=$tests;hardwareActions=$false}|ConvertTo-Json -Depth 5|Set-Content -LiteralPath (Join-Path $build 'work\flash-recovery-tests.json') -Encoding UTF8
'PASS_FLASH_RECOVERY count='+$tests.Count
