﻿[CmdletBinding()]
param([ValidateSet('Scan','Install','Diagnose')][string]$Mode='Scan',[Parameter(Mandatory=$true)][string]$RunRoot,[ValidateSet('both','rear','front')][string]$CameraSide='both',[ValidateRange(3,15)][int]$CaptureSeconds=8,[string]$ResumeUserSid=[Security.Principal.WindowsIdentity]::GetCurrent().User.Value,[string]$PreviewMap='',[switch]$LivePreview,[string]$PreviewStopEvent='',[int]$PreviewOwnerPid=0)
$ErrorActionPreference='Stop';Set-StrictMode -Version Latest
if($PSVersionTable.PSEdition -eq 'Desktop'){$env:PSModulePath=(Join-Path $PSHOME 'Modules')+';'+[Environment]::GetEnvironmentVariable('PSModulePath',[EnvironmentVariableTarget]::Machine)}
$appRoot=Split-Path -Parent $PSScriptRoot;$driver=Join-Path $appRoot 'Driver'
$RunRoot=[IO.Path]::GetFullPath($RunRoot);New-Item -ItemType Directory -Path $RunRoot -Force|Out-Null
$result=[ordered]@{schema=1;appVersion='1.0.7';mode=$Mode;started=(Get-Date -Format o);status='PREPARING';progress=0;message='Проверка устройства и комплекта';code=1;rebootRequired=$false;resumeExe='';engineDirectory='';errors=@();devices=@();checks=@();captures=@();driverChanges=$false}
$operation=$null
function Save-Result {
 $path=Join-Path $RunRoot 'app-result.json';$tmp=$path+'.tmp';$result.updated=(Get-Date -Format o)
 [IO.File]::WriteAllText($tmp,($result|ConvertTo-Json -Depth 12),[Text.UTF8Encoding]::new($false))
 if(Test-Path -LiteralPath $path){[IO.File]::Replace($tmp,$path,[NullString]::Value)}else{[IO.File]::Move($tmp,$path)}
}
function Check([string]$name,[bool]$ok,[string]$detail){$result.checks+=@([ordered]@{name=$name;ok=$ok;detail=$detail})}
function Test-CurrentBootTestSigning([string]$StartOptions){return $StartOptions -match '(?i)(^|\s)TESTSIGNING($|\s)'}
function Resolve-BootSecurity($Native,$Firmware,[int]$RegistryValue,[string]$StartOptions){
 $state='Unknown';$source='Not reported'
 if($Native.SecureBootAvailable){$state=if($Native.SecureBootEnabled){'Enabled'}else{'Disabled'};$source='Current kernel: SystemSecureBootInformation'}
 elseif($Firmware -is [bool]){$state=if($Firmware){'Enabled'}else{'Disabled'};$source='UEFI: Confirm-SecureBootUEFI'}
 elseif($RegistryValue -eq 0 -or $RegistryValue -eq 1){$state=if($RegistryValue -eq 1){'Enabled'}else{'Disabled'};$source='Registry: UEFISecureBootEnabled'}
 $testSigning=if($Native.CodeIntegrityAvailable){($Native.CodeIntegrityOptions -band 2) -ne 0}else{Test-CurrentBootTestSigning $StartOptions}
 $testSource=if($Native.CodeIntegrityAvailable){'Current kernel: SystemCodeIntegrityInformation'}else{'Current kernel boot: SystemStartOptions'}
 $kernelAllowsTestSigning=$Native.CodeIntegrityAvailable -and $testSigning
 $compatible=$state -eq 'Disabled' -or ($state -eq 'Unknown' -and $kernelAllowsTestSigning)
 $detail=switch($state){
  'Enabled' {'Secure Boot включён. Отключите его в UEFI и перезагрузите Windows.'}
  'Disabled' {'Secure Boot выключен.'}
  default {if($kernelAllowsTestSigning){'UEFI не сообщает состояние Secure Boot; ядро Windows разрешает тестовые драйверы.'}else{'Не удалось определить Secure Boot. Подтвердите его отключение в UEFI и повторите установку с правами администратора.'}}
 }
 [ordered]@{
  compatible=$compatible;detail=$detail
  secureBoot=[ordered]@{state=$state;source=$source;registryValue=$RegistryValue;kernelStatus=$Native.SecureBootStatus;capable=if($Native.SecureBootAvailable){$Native.SecureBootCapable}else{$null}}
  testMode=[ordered]@{enabled=[bool]$testSigning;required=$true;signature='test-signed';source=$testSource;kernelStatus=$Native.CodeIntegrityStatus;codeIntegrityOptions=if($Native.CodeIntegrityAvailable){$Native.CodeIntegrityOptions}else{$null};startOptions=$StartOptions}
 }
}
function Get-BootSecurity {
 $native=[pscustomobject]@{SecureBootAvailable=$false;SecureBootEnabled=$false;SecureBootCapable=$false;SecureBootStatus='Unavailable';CodeIntegrityAvailable=$false;CodeIntegrityOptions=0;CodeIntegrityStatus='Unavailable'}
 try {
  if(-not ('XiaomiPad5.CameraBootSecurity' -as [type])){[void][Reflection.Assembly]::LoadFrom((Join-Path $appRoot 'xiaomi-pad5-windows11-camera.exe'))}
  $native=[XiaomiPad5.CameraBootSecurity]::Read()
 }catch{$native.SecureBootStatus=$_.Exception.Message;$native.CodeIntegrityStatus=$_.Exception.Message}
 $firmware=$null;$firmwareError=''
 if(-not $native.SecureBootAvailable){try{$firmware=Confirm-SecureBootUEFI -ErrorAction Stop}catch{$firmwareError=$_.Exception.Message}}
 $secureKey=Get-Item -LiteralPath 'HKLM:\SYSTEM\CurrentControlSet\Control\SecureBoot\State' -ErrorAction SilentlyContinue
 $registryValue=if($secureKey){[int]$secureKey.GetValue('UEFISecureBootEnabled',-1)}else{-1}
 $startOptions=(Get-Item -LiteralPath 'HKLM:\SYSTEM\CurrentControlSet\Control').GetValue('SystemStartOptions','')
 $security=Resolve-BootSecurity $native $firmware $registryValue $startOptions
 $security.secureBoot.firmwareError=$firmwareError
 $security
}
function Get-DeviceReport {
 $devices=@(Get-PnpDevice -PresentOnly|Where-Object {$_.InstanceId -match '^ACPI\\QCOM(0528|05A4|0506|0529|052A|0536|0535)\\|^DISPLAY\\QCOM_AVSTREAM_8150\\|^ROOT\\CAMERA\\' })
 foreach($device in $devices){
  $driverKey='';$version='';$inf='';$service='';$hardware=@()
  $key=Get-Item -LiteralPath ('Registry::HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Enum\'+$device.InstanceId) -ErrorAction SilentlyContinue
  if($key){$service=$key.GetValue('Service','');$hardware=@($key.GetValue('HardwareID',@()));$driverKey=$key.GetValue('Driver','')}
  if($driverKey){$class=Get-Item -LiteralPath ('Registry::HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\Class\'+$driverKey) -ErrorAction SilentlyContinue;if($class){$version=$class.GetValue('DriverVersion','');$inf=$class.GetValue('InfPath','')}}
  [ordered]@{id=$device.InstanceId;name=$device.FriendlyName;problem=[int]$device.Problem;status=[string]$device.Status;service=$service;version=$version;inf=$inf;hardware=$hardware}
 }
}
function Verify-App {
 $manifest=Get-Content -LiteralPath (Join-Path $appRoot 'APP-SHA256.json') -Raw|ConvertFrom-Json
 foreach($file in $manifest.files){$path=[IO.Path]::GetFullPath((Join-Path $appRoot $file.path))
  if(-not $path.StartsWith($appRoot.TrimEnd('\')+'\',[StringComparison]::OrdinalIgnoreCase)){throw 'Некорректный путь в комплекте'}
  if(-not(Test-Path -LiteralPath $path) -or (Get-Item -LiteralPath $path).Length -ne $file.bytes -or (Get-FileHash -LiteralPath $path).Hash -ine $file.sha256){throw ('Комплект повреждён или распакован не полностью: '+$file.path)}
 }
 Check 'Целостность комплекта' $true ('SHA256: '+$manifest.files.Count+' файлов')
}
function Stage-Resume {
 $result.resumeExe=Join-Path $appRoot 'xiaomi-pad5-windows11-camera.exe'
 if(-not(Test-Path -LiteralPath $result.resumeExe)){throw 'Не найдено приложение для продолжения после перезагрузки'}
 $result.resumeTask=& (Join-Path $appRoot 'Scripts\Resume-Task.ps1') -Mode Register -AppRoot $appRoot -UserSid $ResumeUserSid
}
function Test-LivePreviewJournal($Journal,[string]$CurrentBoot){
 if($null -eq $Journal){return $false}
 $boot=$Journal.PSObject.Properties['boot'];$closed=$Journal.PSObject.Properties['captureClosed']
 if(-not $boot -or -not $closed -or $closed.Value -isnot [bool] -or -not [string]$boot.Value){return $false}
 return ($closed.Value -eq $true -or [string]$boot.Value -cne $CurrentBoot)
}
function Get-InstalledPackageReport {
 $path=Join-Path $RunRoot 'installed-package.json'
 $arguments=@('-NoProfile','-ExecutionPolicy','Bypass','-File',('"'+(Join-Path $driver 'Setup.ps1')+'"'),'-Mode','Check','-InstalledAuditFile',('"'+$path+'"'))
 $auditProcess=Start-Process -FilePath (Join-Path $env:windir 'System32\WindowsPowerShell\v1.0\powershell.exe') -ArgumentList $arguments -WindowStyle Hidden -PassThru -RedirectStandardOutput (Join-Path $RunRoot 'installed-package.out.log') -RedirectStandardError (Join-Path $RunRoot 'installed-package.err.log')
 $null=$auditProcess.Handle
 try{
  if(-not $auditProcess.WaitForExit(60000)){throw 'Installed package audit did not finish in time'}
  $auditProcess.Refresh()
  if($auditProcess.ExitCode -ne 0 -or -not(Test-Path -LiteralPath $path)){throw 'Installed package could not be verified; see installed-package.err.log'}
  Get-Content -LiteralPath $path -Raw|ConvertFrom-Json
 }finally{$auditProcess.Dispose()}
}
function Test-PreflightRepairable($Checks,$Plan){
 if(-not $Plan.eligible){return $false}
 $blocking=@($Checks|Where-Object {-not $_.ok -and $_.name -notmatch '^(Устройство |Штатный компонент )'})
 return $blocking.Count -eq 0
}
try{
 Save-Result;Verify-App;. (Join-Path $driver 'Tools\CameraPrerequisites.ps1');$result.progress=5;Save-Result
 $computer=Get-CimInstance Win32_ComputerSystem;$os=Get-CimInstance Win32_OperatingSystem
 $arm=@(Get-CimInstance Win32_Processor|Where-Object Architecture -eq 12).Count -gt 0
 $result.host=[ordered]@{manufacturer=$computer.Manufacturer;model=$computer.Model;architecture=$computer.SystemType;windows=$os.Version;boot=$os.LastBootUpTime.ToUniversalTime().ToString('o')}
 Check 'Xiaomi Pad 5 / Windows ARM64' ($arm -and $computer.Manufacturer -match 'Xiaomi' -and $computer.Model -match 'Pad.?5' -and [int]$os.BuildNumber -ge 22000) ($computer.Model+'; Windows '+$os.Version)
 $result.devices=@(Get-DeviceReport);$result.progress=10;Save-Result
 foreach($prefix in 'ACPI\QCOM0528\','ACPI\QCOM05A4\','ACPI\QCOM0506\','ACPI\QCOM0529\','DISPLAY\QCOM_AVSTREAM_8150\'){
  $found=@($result.devices|Where-Object {$_.id.StartsWith($prefix,[StringComparison]::OrdinalIgnoreCase)})
  Check ('Устройство '+$prefix) ($found.Count -eq 1) ('Обнаружено: '+$found.Count)
 }
 foreach($prefix in 'ACPI\QCOM0535\','ACPI\QCOM0536\','ACPI\QCOM052A\'){
  $found=@($result.devices|Where-Object {$_.id.StartsWith($prefix,[StringComparison]::OrdinalIgnoreCase)})
  Check ('Штатный компонент '+$prefix) ($found.Count -eq 1 -and $found[0].problem -eq 0) ('Platform/JPEG/Flash; найдено: '+$found.Count)
 }
 $result.prerequisites=Get-CameraPrerequisitePlan $result.devices
 $security=Get-BootSecurity
 $result.secureBoot=$security.secureBoot;$result.testMode=$security.testMode
 Check 'Проверка Secure Boot' $security.compatible ($security.detail+' Source='+$security.secureBoot.source+'; UEFISecureBootEnabled='+$security.secureBoot.registryValue)
 $testSigning=$security.testMode.enabled
 Check 'Тестовый режим драйверов' $testSigning ($security.testMode.source+'; CodeIntegrityOptions='+$security.testMode.codeIntegrityOptions+'; SystemStartOptions='+$security.testMode.startOptions)
 $privacy=Get-Item -LiteralPath 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\webcam' -ErrorAction SilentlyContinue
 $permission=if($privacy){$privacy.GetValue('Value','Unknown')}else{'Unknown'}
 Check 'Доступ Windows к камере' ($permission -ne 'Deny') $permission
 $disk=[IO.DriveInfo]::new('C:\');Check 'Место на системном диске' ($disk.AvailableFreeSpace -ge 1GB) ([math]::Round($disk.AvailableFreeSpace/1GB,2).ToString()+' GiB свободно')
 if($Mode -eq 'Scan'){
  $result.message='Проверка установленного комплекта драйверов';Save-Result
  try{$result.installedPackage=Get-InstalledPackageReport}catch{$result.installedPackage=[ordered]@{installed=$false;state='UNKNOWN';cameraVerification='NOT_COMPLETE';continuationRequired=$false;detail=$_.Exception.Message}}
 }
 $result.status='SCAN_COMPLETE';$result.progress=if($Mode -eq 'Scan'){100}else{15};$result.message='Устройства и условия установки проверены';Save-Result
 if($Mode -eq 'Scan'){$result.code=0;exit 0}
 if(-not $testSigning){throw 'Драйверы имеют тестовую подпись. Включите Test Mode, перезагрузите Windows и нажмите «Повторить проверку».'}
 $failed=@($result.checks|Where-Object {-not $_.ok})
 if($failed.Count -and -not($Mode -eq 'Install' -and (Test-PreflightRepairable $result.checks $result.prerequisites))){throw ('Перед установкой нужно исправить: '+(($failed|ForEach-Object {$_.name+' — '+$_.detail}) -join '; '))}
 $admin=([Security.Principal.WindowsPrincipal]::new([Security.Principal.WindowsIdentity]::GetCurrent())).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
 if(-not $admin){throw 'Windows не предоставила права администратора. Повторите установку и подтвердите запрос UAC.'}
 $previewJournal=Join-Path $appRoot 'Data\LivePreviewSession.json'
 if(Test-Path -LiteralPath $previewJournal){
  try{$journal=Get-Content -LiteralPath $previewJournal -Raw|ConvertFrom-Json}catch{$journal=$null}
  if(-not ('XiaomiPad5.PreviewBoot' -as [type])){[void][Reflection.Assembly]::LoadFrom((Join-Path $appRoot 'xiaomi-pad5-windows11-camera.exe'))}
  if(-not(Test-LivePreviewJournal $journal ([XiaomiPad5.PreviewBoot]::Read()))){
   $result.status='PENDING_LIVE_PREVIEW_RESTART';$result.rebootRequired=$true;$result.code=3010;$result.message='Предыдущий поток камеры не закрылся штатно. Нужна перезагрузка перед установкой; продолжение сохранено.';Stage-Resume;Save-Result;exit 3010
  }
 }
 $result.status='RUNNING';$result.message=if($Mode -eq 'Install'){'Установка и исправление конфигурации камер'}else{'Проверка кадров обеих камер'};Save-Result
 $engineRoot=Join-Path $RunRoot 'Engine';New-Item -ItemType Directory -Path $engineRoot -Force|Out-Null
 $exe=Join-Path $env:windir 'System32\WindowsPowerShell\v1.0\powershell.exe'
 $args=@('-NoProfile','-ExecutionPolicy','Bypass','-File',('"'+(Join-Path $driver 'Setup.ps1')+'"'),'-Mode',$Mode,'-ResultRoot',('"'+$engineRoot+'"'),'-CameraSide',$CameraSide,'-CaptureSeconds',[string]$CaptureSeconds,'-Elevated')
 if($PreviewMap){$args+=@('-PreviewMap',('"'+$PreviewMap+'"'))}
 if($LivePreview){if($Mode -ne 'Diagnose' -or $CameraSide -eq 'both' -or -not $PreviewStopEvent -or -not $PreviewOwnerPid){throw 'Live preview requires one camera and a managed lifetime'};$args+=@('-LivePreview','-PreviewStopEvent',('"'+$PreviewStopEvent+'"'),'-PreviewOwnerPid',[string]$PreviewOwnerPid)}
 $operation=Start-Process -FilePath $exe -ArgumentList $args -WindowStyle Hidden -PassThru -RedirectStandardOutput (Join-Path $RunRoot 'engine.out.log') -RedirectStandardError (Join-Path $RunRoot 'engine.err.log')
 $null=$operation.Handle
 Add-Type -TypeDefinition 'using System;using System.Runtime.InteropServices;public static class OwnWorkerMemory{[DllImport("psapi.dll")]static extern bool EmptyWorkingSet(IntPtr h);public static void Trim(){GC.Collect();GC.WaitForPendingFinalizers();GC.Collect();EmptyWorkingSet(System.Diagnostics.Process.GetCurrentProcess().Handle);}}'
 [OwnWorkerMemory]::Trim()
 $operation.WaitForExit();$operation.Refresh();if($null -eq $operation.ExitCode){throw 'Windows did not return an installer exit code; success cannot be confirmed.'};$result.code=$operation.ExitCode
 $files=@(Get-ChildItem -LiteralPath $engineRoot -Filter result.json -Recurse|Sort-Object LastWriteTimeUtc -Descending)
 if($files.Count){
  $state=Get-Content -LiteralPath $files[0].FullName -Raw|ConvertFrom-Json
  $result.engineDirectory=Split-Path -Parent $files[0].FullName;$result.status=$state.status;$result.rebootRequired=$state.rebootRequired;$result.errors=@($state.errors);$result.captures=@($state.captures);$result.driverChanges=$state.driverActions
  $result.installedPackageVerified=($state.PSObject.Properties['activeVerificationPassed'] -and $state.activeVerificationPassed)
  if($state.PSObject.Properties['nativeVerification']){$result.nativeVerification=$state.nativeVerification}
  if($state.PSObject.Properties['packageCleanup']){$result.packageCleanup=$state.packageCleanup}
  if($state.PSObject.Properties['warnings']){$result.warnings=@($state.warnings)}
  if($state.PSObject.Properties['prerequisiteRepair']){$result.prerequisiteRepair=$state.prerequisiteRepair}
  if($state.PSObject.Properties['storageMigration']){$result.storageMigration=$state.storageMigration}
  if($state.unsafeToContinue -or -not $state.captureClosed -or -not $state.fullMftDecoded){$result.rebootRequired=$true;$result.status='PENDING_CAMERA_SESSION_RESTART'}
  $resumeFile=Join-Path $appRoot 'Data\resume.json';$cycles=0
  if(Test-Path -LiteralPath $resumeFile){try{$resume=Get-Content -LiteralPath $resumeFile -Raw -Encoding UTF8|ConvertFrom-Json;$cycles=[int]$resume.cycles}catch{}}
  if($result.rebootRequired -and $cycles -ge 4){
   $result.status='RECOVERY_STOPPED';$result.code=2;$result.rebootRequired=$false;$result.autoResumeStopped=$true
   $result.message='Ошибка сохраняется после нескольких перезагрузок. Автоматическое продолжение остановлено. Сохраните отчёт; повторная перезагрузка сама по себе не исправит причину.'
   & (Join-Path $appRoot 'Scripts\Resume-Task.ps1') -Mode Clear -AppRoot $appRoot -UserSid $ResumeUserSid
  }
  elseif($result.rebootRequired){Stage-Resume;$result.message='Нужна перезагрузка. Продолжение сохранено; после входа приложение откроется снова.'
   if($result.installedPackageVerified -and $state.PSObject.Properties['nativeVerification'] -and $state.nativeVerification.evidence -eq 'MISSING_DRIVER_LOG_MARKERS' -and $state.nativeVerification.framesReceived -and $state.nativeVerification.probeClosed){$result.message='Драйверы установлены и кадры получены. Журнал не подтвердил закрытие камеры; проверка не завершена. Перезагрузите Windows для продолжения.'}
  }
  elseif($operation.ExitCode -eq 0 -and $state.status -like 'PASS*' -and $state.captures.Count -eq $(if($Mode -eq 'Diagnose' -and $CameraSide -ne 'both'){1}else{2}) -and -not $state.unsafeToContinue -and $state.captureClosed -and $state.fullMftDecoded){$result.progress=100;$result.message=$(if($state.captures.Count -eq 2){'Драйверы 253 проверены. Обе камеры передают кадры и закрылись без ошибок.'}else{'Selected camera delivered frames and closed successfully.'});if($result.Contains('warnings') -and $result.warnings.Count){$result.message+=' Служебные отметки драйвера недоступны; проверка кадров и закрытия Windows выполнена.'};try{& (Join-Path $appRoot 'Scripts\Resume-Task.ps1') -Mode Clear -AppRoot $appRoot -UserSid $ResumeUserSid}catch{$result.resumeCleanupError=$_.Exception.Message}}
  else{$result.message='Проверка не завершена: '+($state.errors -join '; ');if($result.code -eq 0){$result.code=1}}
 }else{
  $text='';foreach($log in 'engine.out.log','engine.err.log'){$path=Join-Path $RunRoot $log;if(Test-Path -LiteralPath $path){$text+=[IO.File]::ReadAllText($path)}}
  throw ('Установщик остановился до создания результата. '+$text)
 }
 $result.devices=@(Get-DeviceReport)
}catch{$result.status='ERROR';$result.code=1;$result.errors+=@($_.Exception.Message);$result.message=$_.Exception.Message}
finally{Save-Result}
exit $result.code
