# CPUISP4 public installation validation

The public Setup.cmd and Diagnose.cmd from the extracted CPUISP4 R1 ZIP passed
on our Windows 11 ARM64 nabu tablet, from a directory containing Cyrillic and
spaces. Both rear/front delivered 1280x960 preview images and closed normally.
Setup captured rear75/front193 frames; Diagnose rear114/front201, with zero
duplicate polls in those checks. No restart or forced camera-owner termination.

CPUISP4 SYS bytes are retained unchanged. Updated INF dates (11/04/2026) and
new signed catalogs prevent Windows from reusing the identical CPUISP3 front INF
with a different SYS hash. Shared operational installer/probe code is unchanged.
Source C/H files match the retained CPUISP4 source snapshot and all four drivers
rebuild through EWDK; relinking is not byte-identical to the old signed files.

The initial same-INF conflict and low-RAM stops remain in local evidence. They
were not counted as successful tests. UI working sets were paged out without
terminating apps. The cameras' normal closure was checked before subsequent work.

These are installation/output tests on one tablet, not a claim of universal
Windows/BSP compatibility, new optical quality, Android parity or sustained FPS.
