﻿Xiaomi Pad 5 nabu — Windows ARM64 — Qualcomm ISP253 / Installer R2.5
SYS080 / DeviceMFT075b / tuning253. 2026-11-06.

R2.5 no longer opens the old native camera before replacing drivers. On some
systems that camera returns zero frames and no IFE close trace, blocking setup.
A normal Windows restart is required before rebinding. After restarting, run
Install.cmd again before opening any camera app. Post-install image and close
tests for BOTH cameras remain mandatory. Unknown SMMU mappings are rejected.

R2.4 fixes Native logging parent key missing on a first installation by creating
only the missing qccamavs/Logging descendants under existing Services, and
Debug Print Filter under existing Session Manager. Missing keys are recorded
before writes; rollback removes only newly created empty keys. Russian encoding
is corrected. If R2.3 prepared DMA but stopped with FAILED_RESTORED, use this
new archive. Restart normally when requested and rerun; retain prior journals.

Extract the entire archive into a new folder. Close camera apps and connect power.
Save your original compatible BSP and run Backup-CurrentDrivers.cmd.
Run Install.cmd and approve administrator elevation. Setup.cmd is equivalent.
If RESTART REQUIRED appears, restart Windows normally and run Install.cmd again
before opening any camera app. No automatic reboot is invoked.

SUCCESS / exit0: active files, both camera images, close evidence and full traces passed.
RESTART REQUIRED / exit3010: restart Windows normally, then rerun.
DRIVERS INSTALLED; CAMERA VERIFICATION INCOMPLETE / exit2: active installation
was verified, but camera qualification did not finish. Not both-camera success.
SETUP STOPPED / other code: review the error and save the latest complete Logs folder.
Do not delete safety journals or run another installer concurrently.
If R2.2 cameras already work, reinstalling solely for a clearer message is unnecessary.
New users should use the entire R2.5 kit.

Only Xiaomi Pad 5 nabu, Windows ARM64, compatible base BSP and permitted
test drivers. At least 650 MiB available RAM and 1 GiB free C: space.
Not a clean-Windows BSP. Recognized native qcsmmu 1.0.2100.0 / SM8150v2
hash and mappings required; unknown configurations are rejected.

Installs certificates, five drivers, DeviceMFT, IPE firmware and both datasets
into a persistent C:\ProgramData\XiaomiPad5Camera cache.
If needed, adds SID 2100/2120/2140 to two known SMMU MAP values,
with backup, readback and rollback. A new kernel startup is required afterward.
No SMMU replacement, live reset or automatic reboot.
Prepares EnableLog=1 and IHVSTREAMING levels 0..3 in the active control set
and the driver's literal ControlSet001; other mask bits are preserved.
TraceEnable is recorded without changing it. Originals are backed up before writes.
Changed startup settings require a normal Windows Restart.
Missing persistent settings are not proven as the friend's sole logging cause.
Camera selection uses physical AVS identity and sensor interface/panel, not names.
Ambiguous identities, unfinished operations and missing native-close evidence
stop qualification. Empty/green frames never count as success. Journals remain.

Check.cmd: read-only integrity/platform/DMA/logging check; no camera opening.
PREPARATION_REQUIRED means preparation through Install is needed.
Diagnose.cmd: checks installed package and both cameras without rebinding.
Logs: C:\ProgramData\XiaomiPad5Camera\Logs. Send the entire newest folder.
State: C:\ProgramData\XiaomiPad5Camera\state.json. Backups: Backups.
MAP originals: CameraDma\backup-*; logging: CameraDma\logging-backup-*.json.
Restore using your compatible original BSP. Registry copies are installation-specific;
restoring MAP values also requires a normal restart.

All binaries, certificates, firmware and tuning match accepted R2.2.
R2.5 changes installer scripts/diagnostics; CameraProbe256 remains the R2.2 binary.
R2.2 was actually reinstalled locally: five drivers, rear235/front237 frames
in eight-second 1920x1080 NV12 tests; native-close and full-MFT PASS.
Friend's R2.2 logs confirm installation and rear119 frames/8s, but native-close
HOLD stopped the automatic front test. Friend manually reported cameras work;
that is not automated both-camera qualification.
R2.5 undergoes PowerShell 5.1, registry/recovery/rollback, signature, integrity
and extraction tests. Actual install results are recorded separately; R2.2 PASS
does not replace R2.5 validation. Independent tablet tests remain necessary.
Full Android quality/features are not achieved. Front OV8856 is fixed-focus.
No private keys, chats, photos or supplied machine logs. No H:, EWDK or Codex needed.
