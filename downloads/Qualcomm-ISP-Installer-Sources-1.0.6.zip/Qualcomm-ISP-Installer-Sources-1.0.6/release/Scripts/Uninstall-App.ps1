﻿param([Parameter(Mandatory=$true)][string]$AppRoot,[int]$WaitPid=0,[string]$ResultRoot='')
$ErrorActionPreference='Stop';Set-StrictMode -Version Latest
if($PSVersionTable.PSEdition -eq 'Desktop'){$env:PSModulePath=(Join-Path $PSHOME 'Modules')+';'+[Environment]::GetEnvironmentVariable('PSModulePath',[EnvironmentVariableTarget]::Machine)}
if(-not $ResultRoot){$ResultRoot=Join-Path $AppRoot 'Data\Uninstall'}
$result=[ordered]@{status='ERROR';driversRemoved=$false;errors=@()}
try{
 $expected=[IO.Path]::GetFullPath((Join-Path $env:ProgramFiles 'QualcommISPDrivers-XiaomiPad5')).TrimEnd('\')
 $desktop=[IO.Path]::GetFullPath((Join-Path ([Environment]::GetFolderPath('Desktop')) 'Qualcomm ISP Drivers')).TrimEnd('\')
 $actual=[IO.Path]::GetFullPath($AppRoot).TrimEnd('\')
 if(($actual -ine $expected -and $actual -ine $desktop) -or -not(Test-Path -LiteralPath (Join-Path $actual 'APP-SHA256.json'))){throw 'Refusing to remove an unrecognized installation folder'}
 $links=@(Get-ChildItem -LiteralPath $actual -Recurse -Force|Where-Object {$_.Attributes -band [IO.FileAttributes]::ReparsePoint})
 if((Get-Item -LiteralPath $actual).Attributes -band [IO.FileAttributes]::ReparsePoint -or $links.Count){throw 'Refusing recursive removal through a junction or symbolic link'}
 $exe=Join-Path $actual 'xiaomi-pad5-windows11-camera.exe'
 if(Test-Path -LiteralPath (Join-Path $actual 'Scripts\Resume-Task.ps1')){& (Join-Path $actual 'Scripts\Resume-Task.ps1') -Mode Clear -AppRoot $actual}
 $running=@(Get-CimInstance Win32_Process|Where-Object {$_.ExecutablePath -ieq $exe})
 foreach($proc in $running){$p=Get-Process -Id $proc.ProcessId;$null=$p.CloseMainWindow();if(-not $p.WaitForExit(15000)){throw 'Camera application is still busy. Wait for camera closure before uninstalling.'}}
 if($WaitPid){$parent=Get-Process -Id $WaitPid -ErrorAction SilentlyContinue;if($parent){if(-not $parent.WaitForExit(60000)){throw 'Uninstaller did not exit; removal stopped'}}}
 $runOnce=[Microsoft.Win32.Registry]::CurrentUser.OpenSubKey('Software\Microsoft\Windows\CurrentVersion\RunOnce',$true)
 if($runOnce){try{$command=[string]$runOnce.GetValue('xiaomi-pad5-windows11-camera','');$stableExe=Join-Path $env:ProgramData 'xiaomi-pad5-windows11-camera\App\xiaomi-pad5-windows11-camera.exe';if($command.IndexOf($stableExe,[StringComparison]::OrdinalIgnoreCase) -ge 0 -or $command.IndexOf($exe,[StringComparison]::OrdinalIgnoreCase) -ge 0){$runOnce.DeleteValue('xiaomi-pad5-windows11-camera',$false)}}finally{$runOnce.Dispose()}}
 $shell=New-Object -ComObject WScript.Shell
 $programs=if($actual -ieq $desktop){[Environment]::GetFolderPath('Programs')}else{[Environment]::GetFolderPath('CommonPrograms')}
 foreach($directory in @([Environment]::GetFolderPath('Desktop'),$programs)){$path=Join-Path $directory 'Qualcomm ISP Camera Drivers.lnk';if(Test-Path -LiteralPath $path){if($shell.CreateShortcut($path).TargetPath -ieq $exe){Remove-Item -LiteralPath $path -Force}}}
 $key=if($actual -ieq $desktop){'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\XiaomiPad5QualcommISP'}else{'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\XiaomiPad5QualcommISP'}
 if(Test-Path -LiteralPath $key){$registered=(Get-ItemProperty -LiteralPath $key).InstallLocation;if($registered -ine $actual){throw 'Uninstall registration points to a different folder'};Remove-Item -LiteralPath $key -Recurse -Force}
 # The exact resolved directory and every reparse point were checked above.
 # DriverStore and Windows\System32\drivers\XiaomiPad5Camera are deliberately retained.
 Remove-Item -LiteralPath $actual -Recurse -Force
 $result.status='PASS'
}catch{$result.errors+=@($_.Exception.Message)}
if($result.status -ne 'PASS' -and (Test-Path -LiteralPath $AppRoot)){New-Item -ItemType Directory -Path $ResultRoot -Force|Out-Null;$result|ConvertTo-Json -Depth 5|Set-Content -LiteralPath (Join-Path $ResultRoot 'result.json') -Encoding UTF8}
if($result.status -ne 'PASS'){exit 1};exit 0
