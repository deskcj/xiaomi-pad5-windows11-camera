﻿param([Parameter(Mandatory=$true)][string]$Source,[Parameter(Mandatory=$true)][string]$Bootstrap,[string]$ResultRoot='',[switch]$ProgramFiles)
$ErrorActionPreference='Stop';Set-StrictMode -Version Latest
if($PSVersionTable.PSEdition -eq 'Desktop'){$env:PSModulePath=(Join-Path $PSHOME 'Modules')+';'+[Environment]::GetEnvironmentVariable('PSModulePath',[EnvironmentVariableTarget]::Machine)}
 $target=Join-Path ([Environment]::GetFolderPath('Desktop')) 'Qualcomm ISP Drivers'
if(-not $ResultRoot){$ResultRoot=Join-Path $target ('Data\Setup-'+[guid]::NewGuid().ToString('N'))}
New-Item -ItemType Directory -Path $ResultRoot -Force|Out-Null
$result=[ordered]@{status='INSTALLING';progress=0;path=$target;message='Checking application package';errors=@()}
function Save([int]$pct){
 $result.progress=$pct;$path=Join-Path $ResultRoot 'result.json';$tmp=$path+'.tmp'
 [IO.File]::WriteAllText($tmp,($result|ConvertTo-Json -Depth 5),[Text.UTF8Encoding]::new($false))
 for($attempt=0;$attempt -lt 20;$attempt++){try{if(Test-Path -LiteralPath $path){[IO.File]::Replace($tmp,$path,[NullString]::Value)}else{[IO.File]::Move($tmp,$path)};return}catch [IO.IOException]{if($attempt -eq 19){throw};Start-Sleep -Milliseconds 100}}
}
try{
 Save 5;$Source=[IO.Path]::GetFullPath($Source)
 $manifest=Get-Content -LiteralPath (Join-Path $Source 'APP-SHA256.json') -Raw|ConvertFrom-Json
 $known=@{}
 foreach($file in $manifest.files){$sourcePath=[IO.Path]::GetFullPath((Join-Path $Source $file.path));if(-not $sourcePath.StartsWith($Source.TrimEnd('\')+'\',[StringComparison]::OrdinalIgnoreCase)){throw 'Invalid package path'};if((Get-FileHash -LiteralPath $sourcePath).Hash -ine $file.sha256){throw ('Package integrity check failed: '+$file.path)};$known[$file.path.Replace('\','/')]=$file.sha256}
 if(Test-Path -LiteralPath $target){
  if((Get-Item -LiteralPath $target).Attributes -band [IO.FileAttributes]::ReparsePoint -or @(Get-ChildItem -LiteralPath $target -Recurse -Force|Where-Object {$_.Attributes -band [IO.FileAttributes]::ReparsePoint}).Count){throw 'Installation folder must not contain junctions or symbolic links'}
  if(-not(Test-Path -LiteralPath (Join-Path $target 'APP-SHA256.json'))){foreach($existing in @(Get-ChildItem -LiteralPath $target -Recurse -File -Force)){
   # The current bootstrap extraction/result folder is disposable and never copied as package content.
   if($existing.FullName.StartsWith(([IO.Path]::GetFullPath($ResultRoot).TrimEnd('\')+'\'),[StringComparison]::OrdinalIgnoreCase)){continue}
   $relative=$existing.FullName.Substring($target.Length+1).Replace('\','/');if(-not $known.ContainsKey($relative) -or (Get-FileHash -LiteralPath $existing.FullName).Hash -ine $known[$relative]){throw 'The installation folder contains an unrelated application. No files were replaced.'}
  }}
 }
 $resumeApp=Join-Path $env:ProgramData 'xiaomi-pad5-windows11-camera\App\xiaomi-pad5-windows11-camera.exe'
 $running=@(Get-CimInstance Win32_Process|Where-Object {$_.ExecutablePath -ieq (Join-Path $target 'xiaomi-pad5-windows11-camera.exe') -or $_.ExecutablePath -ieq $resumeApp})
 foreach($proc in $running){
  $until=[datetime]::UtcNow.AddMinutes(10)
  while(@(Get-CimInstance Win32_Process -Filter ('ParentProcessId = '+[int]$proc.ProcessId)|Where-Object {$_.Name -match '^(powershell|pwsh|CameraProbe.*)\.exe$'}).Count){$result.message='Waiting for the running camera operation to finish';Save 5;if([datetime]::UtcNow -ge $until){throw 'The camera operation is still running. Finish it before updating the application.'};Start-Sleep -Seconds 2}
  $p=Get-Process -Id $proc.ProcessId -ErrorAction SilentlyContinue;if($p){$null=$p.CloseMainWindow();if(-not $p.WaitForExit(15000)){throw 'Close the camera application after its current operation completes, then run Setup again.'}}
 }
 $result.message='Installing application files and shortcuts'
 New-Item -ItemType Directory -Path $target -Force|Out-Null
 Copy-Item -LiteralPath (Join-Path $Source 'APP-SHA256.json') -Destination $target -Force
 $index=0
 foreach($file in $manifest.files){
  $sourcePath=[IO.Path]::GetFullPath((Join-Path $Source $file.path));$dest=[IO.Path]::GetFullPath((Join-Path $target $file.path))
  if(-not $sourcePath.StartsWith($Source.TrimEnd('\')+'\',[StringComparison]::OrdinalIgnoreCase) -or -not $dest.StartsWith($target+'\',[StringComparison]::OrdinalIgnoreCase)){throw 'Invalid package path'}
  if((Get-FileHash -LiteralPath $sourcePath).Hash -ine $file.sha256){throw ('Package integrity check failed: '+$file.path)}
  New-Item -ItemType Directory -Path (Split-Path -Parent $dest) -Force|Out-Null
  Copy-Item -LiteralPath $sourcePath -Destination $dest -Force
  if((Get-FileHash -LiteralPath $dest).Hash -ine $file.sha256){throw ('Installed file verification failed: '+$file.path)}
  $index++;Save (10+[int](70*$index/$manifest.files.Count))
 }
 Copy-Item -LiteralPath (Join-Path $Source 'APP-SHA256.json') -Destination $target -Force
 Copy-Item -LiteralPath $Bootstrap -Destination (Join-Path $target 'Uninstall.exe') -Force
 $exe=Join-Path $target 'xiaomi-pad5-windows11-camera.exe'
 $shell=New-Object -ComObject WScript.Shell
 foreach($directory in @([Environment]::GetFolderPath('Desktop'))){
  $link=$shell.CreateShortcut((Join-Path $directory 'Qualcomm ISP Camera Drivers.lnk'));$link.TargetPath=$exe;$link.Arguments='--install';$link.WorkingDirectory=$target;$link.IconLocation=$exe+',0';$link.Save()
 }
 Save 90
 # Portable desktop application: remove only this folder's old Apps entry/Start shortcut.
 $key='HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\XiaomiPad5QualcommISP'
 if(Test-Path -LiteralPath $key){$old=Get-Item -LiteralPath $key;if($old.GetValue('InstallLocation','') -ieq $target){Remove-Item -LiteralPath $key -Recurse}}
 $oldLink=Join-Path ([Environment]::GetFolderPath('Programs')) 'Qualcomm ISP Camera Drivers.lnk'
 if(Test-Path -LiteralPath $oldLink){if($shell.CreateShortcut($oldLink).TargetPath -ieq $exe){Remove-Item -LiteralPath $oldLink}}
 $result.status='PASS';Save 100
}catch{$result.status='ERROR';$result.errors+=@($_.Exception.Message);Save $result.progress;exit 1}
exit 0
