﻿param([ValidateSet('Register','Clear')][string]$Mode,[Parameter(Mandatory=$true)][string]$AppRoot,[string]$UserSid=[Security.Principal.WindowsIdentity]::GetCurrent().User.Value)
$ErrorActionPreference='Stop';Set-StrictMode -Version Latest
if($PSVersionTable.PSEdition -eq 'Desktop'){$env:PSModulePath=(Join-Path $PSHOME 'Modules')+';'+[Environment]::GetEnvironmentVariable('PSModulePath',[EnvironmentVariableTarget]::Machine)}
$sid=[Security.Principal.SecurityIdentifier]::new($UserSid)
$name='xiaomi-pad5-windows11-camera-resume-'+$sid.Value
$exe=Join-Path ([IO.Path]::GetFullPath($AppRoot)) 'xiaomi-pad5-windows11-camera.exe'
$existing=Get-ScheduledTask -TaskName $name -ErrorAction SilentlyContinue
if($existing){
 if($existing.Actions.Count -ne 1 -or $existing.Actions[0].Execute -ine $exe -or $existing.Actions[0].Arguments -ne '--resume'){throw 'An unrelated task uses the reserved camera resume name'}
}
if($Mode -eq 'Clear'){
 if($existing){Unregister-ScheduledTask -TaskName $name -Confirm:$false}
 return
}
if(-not(Test-Path -LiteralPath $exe)){throw 'The desktop application is missing; resume task was not registered'}
$action=New-ScheduledTaskAction -Execute $exe -Argument '--resume' -WorkingDirectory ([IO.Path]::GetFullPath($AppRoot))
$trigger=New-ScheduledTaskTrigger -AtLogOn -User $sid.Value
$trigger.Delay='PT15S'
$principal=New-ScheduledTaskPrincipal -UserId $sid.Value -LogonType Interactive -RunLevel Limited
$settings=New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -StartWhenAvailable -MultipleInstances IgnoreNew -ExecutionTimeLimit ([TimeSpan]::Zero)
Register-ScheduledTask -TaskName $name -Action $action -Trigger $trigger -Principal $principal -Settings $settings -Description 'Temporary camera installation continuation. Removed after both cameras pass or application uninstall.' -Force|Out-Null
$verified=Get-ScheduledTask -TaskName $name
$verifiedSid=if($verified.Principal.UserId -like 'S-1-*'){$verified.Principal.UserId}else{([Security.Principal.NTAccount]::new($verified.Principal.UserId).Translate([Security.Principal.SecurityIdentifier])).Value}
if($verified.Actions[0].Execute -ine $exe -or $verifiedSid -ne $sid.Value -or $verified.Principal.LogonType -ne 'Interactive'){throw 'Camera resume task verification failed'}
Write-Output $name
