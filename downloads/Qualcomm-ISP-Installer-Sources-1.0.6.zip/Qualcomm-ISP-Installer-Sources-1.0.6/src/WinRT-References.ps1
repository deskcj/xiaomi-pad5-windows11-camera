﻿function Get-CameraWinRTReferences {
 $references=@()
 foreach($name in 'Windows.Foundation','Windows.Media','Windows.Devices','Windows.Graphics','Windows.Storage','Windows.System','Windows.ApplicationModel'){
  $path=Join-Path $env:windir ('System32\WinMetadata\'+$name+'.winmd')
  if(-not(Test-Path -LiteralPath $path)){throw ('Windows camera metadata missing: '+$name)}
  $references+=('/reference:'+$path)
 }
 foreach($name in 'System.Runtime','System.Runtime.InteropServices','System.Runtime.InteropServices.WindowsRuntime','System.Runtime.Extensions','System.Threading.Tasks'){
  $assembly=Get-ChildItem -LiteralPath (Join-Path $env:windir ('Microsoft.NET\assembly\GAC_MSIL\'+$name)) -Filter '*.dll' -Recurse|Select-Object -First 1
  if(-not $assembly){throw ('Windows .NET camera projection missing: '+$name)}
  $references+=('/reference:'+$assembly.FullName)
 }
 return $references
}
