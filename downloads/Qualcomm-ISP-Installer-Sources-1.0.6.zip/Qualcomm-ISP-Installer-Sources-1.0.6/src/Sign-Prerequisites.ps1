﻿param([string]$Ewdk='H:\Vlad\EWDK',[string]$Thumbprint='F38EDD5C105095C8342556158CE66253F045965D')
$ErrorActionPreference='Stop'
$driver=Join-Path (Split-Path -Parent $PSScriptRoot) 'release\Driver'
$sign=Join-Path $Ewdk 'Program Files\Windows Kits\10\bin\10.0.26100.0\arm64\signtool.exe'
foreach($cat in @(Get-ChildItem -LiteralPath (Join-Path $driver 'Prerequisites') -Recurse -File -Filter '*.cat')){
 # Keep the original catalog membership/INF/SYS/data bytes; replace only its
 # test signature with the same development certificate used by ISP253.
 & $sign sign /fd SHA256 /sha1 $Thumbprint /s My $cat.FullName
 if($LASTEXITCODE -ne 0){throw ('Prerequisite catalog signing failed: '+$cat.Name)}
 foreach($file in @(Get-ChildItem -LiteralPath $cat.DirectoryName -File|Where-Object Extension -ne '.cat')){
  & $sign verify /pa /c $cat.FullName $file.FullName
  if($LASTEXITCODE -ne 0){throw ('Catalog membership verification failed: '+$file.Name)}
 }
}
