#define NOMINMAX
#include <windows.h>
#include <MemoryBuffer.h>
#include <winrt/Windows.Foundation.h>
#include <winrt/Windows.Foundation.Collections.h>
#include <winrt/Windows.Media.MediaProperties.h>
#include <winrt/Windows.Devices.Enumeration.h>
#include <winrt/Windows.Media.Capture.h>
#include <winrt/Windows.Media.Capture.Frames.h>
#include <winrt/Windows.Graphics.Imaging.h>
#include <winrt/Windows.Storage.Streams.h>
#include <cstdio>
#include <string>
#include <vector>
#include <fstream>
#include <sstream>
using namespace winrt;
using namespace winrt::Windows::Foundation;
using namespace winrt::Windows::Devices::Enumeration;
using namespace winrt::Windows::Media::Capture;
using namespace winrt::Windows::Media::Capture::Frames;
using namespace winrt::Windows::Graphics::Imaging;
using namespace winrt::Windows::Storage::Streams;
struct ApartmentGuard{~ApartmentGuard(){uninit_apartment();}};
static void Mark(char const* s){LARGE_INTEGER q;QueryPerformanceCounter(&q);printf("STEP256 %s qpc=%lld\n",s,q.QuadPart);}
static std::string Json(std::wstring const& value){
 int size=WideCharToMultiByte(CP_UTF8,0,value.c_str(),int(value.size()),nullptr,0,nullptr,nullptr);std::string bytes(size,'\0');
 if(size)WideCharToMultiByte(CP_UTF8,0,value.c_str(),int(value.size()),bytes.data(),size,nullptr,nullptr);
 std::ostringstream out;out<<'"';for(unsigned char c:bytes){if(c=='"'||c=='\\')out<<'\\'<<c;else if(c<32){char escaped[7];sprintf_s(escaped,"\\u%04x",c);out<<escaped;}else out<<c;}out<<'"';return out.str();
}
static std::string DeviceRecord(DeviceInformation const& d){
 std::wstring instance;auto properties=d.Properties();auto key=L"System.Devices.DeviceInstanceId";
 if(properties.HasKey(key)){auto v=properties.Lookup(key).try_as<IPropertyValue>();if(v&&v.Type()==PropertyType::String)instance=v.GetString();}
 auto location=d.EnclosureLocation();int panel=location?int(location.Panel()):-1;
 return "{\"id\":"+Json(d.Id().c_str())+",\"name\":"+Json(d.Name().c_str())+",\"instanceId\":"+Json(instance)+",\"enabled\":"+(d.IsEnabled()?"true":"false")+",\"panel\":"+std::to_string(panel)+"}";
}
static void Save(std::wstring const& dir,SoftwareBitmap const& bitmap){
 bool rgb=bitmap.BitmapPixelFormat()==BitmapPixelFormat::Bgra8;Buffer buffer(uint32_t(bitmap.PixelWidth()*bitmap.PixelHeight()*(rgb?4:1)* (rgb?2:3)/2));bitmap.CopyToBuffer(buffer);auto data=DataReader::FromBuffer(buffer);std::vector<uint8_t> bytes(buffer.Length());data.ReadBytes(bytes);data.Close();
 std::wstring p=dir+(rgb?L"\\preview.bgra":L"\\preview.nv12");if(GetFileAttributesW(p.c_str())!=INVALID_FILE_ATTRIBUTES)throw hresult_error(E_UNEXPECTED,L"Preserve existing image");
 std::ofstream f(p,std::ios::binary);f.write(reinterpret_cast<char const*>(bytes.data()),bytes.size());f.close();if(!f)throw hresult_error(E_FAIL,L"Image save failed");
 std::ofstream meta(dir+L"\\layout.json");meta<<"{\"width\":"<<bitmap.PixelWidth()<<",\"height\":"<<bitmap.PixelHeight()<<",\"format\":\""<<(rgb?"BGRA8":"NV12")<<"\",\"bytes\":"<<bytes.size()<<"}";meta.close();if(!meta)throw hresult_error(E_FAIL,L"Layout save failed");
}
// Optional display channel. Native frame evidence and camera controls are unchanged.
struct PreviewChannel{
 HANDLE mapping=nullptr;BYTE* view=nullptr;unsigned side=0;
 PreviewChannel(std::wstring const& name,unsigned cameraSide):side(cameraSide){
  if(!name.empty()){mapping=OpenFileMappingW(FILE_MAP_WRITE,FALSE,name.c_str());if(mapping)view=(BYTE*)MapViewOfFile(mapping,FILE_MAP_WRITE,0,0,64+960*540*4);if(!view)fprintf(stderr,"PREVIEW_WARNING shared memory unavailable; using BMP fallback\n");else State(0);}
 }
 ~PreviewChannel(){if(view)UnmapViewOfFile(view);if(mapping)CloseHandle(mapping);}
 void State(unsigned state){if(!view)return;InterlockedIncrement((volatile LONG*)view);*(unsigned*)(view+28)=state;InterlockedIncrement((volatile LONG*)view);}
 void Publish(std::vector<uint8_t> const& pixels,int w,int h,int cw,int ch,unsigned frames,double fps,double elapsed,unsigned seconds){
  if(!view||w<=0||h<=0||w>960||h>540)return;
  InterlockedIncrement((volatile LONG*)view);
  *(unsigned*)(view+4)=0x51323533;*(int*)(view+8)=w;*(int*)(view+12)=h;*(unsigned*)(view+16)=frames;
  *(int*)(view+20)=cw;*(int*)(view+24)=ch;*(unsigned*)(view+28)=1;*(double*)(view+32)=fps;
  *(double*)(view+40)=elapsed;*(unsigned*)(view+48)=seconds;*(unsigned*)(view+52)=side;
  memcpy(view+64,pixels.data(),pixels.size());InterlockedIncrement((volatile LONG*)view);
 }
};
static void Preview(std::wstring const& dir,SoftwareBitmap const& bitmap,PreviewChannel& channel,unsigned frames,double fps,double elapsed,unsigned seconds){
 if(dir.empty())return;
 const int w=bitmap.PixelWidth(),h=bitmap.PixelHeight(),ow=w/2,oh=h/2;
 const bool rgb=bitmap.BitmapPixelFormat()==BitmapPixelFormat::Bgra8;
 Buffer buffer(uint32_t(w*h*(rgb?4:3.0/2)));bitmap.CopyToBuffer(buffer);
 auto reader=DataReader::FromBuffer(buffer);std::vector<uint8_t> src(buffer.Length());reader.ReadBytes(src);reader.Close();
 std::vector<uint8_t> dst(size_t(ow)*oh*4);
 auto clip=[](double v){return uint8_t(v<0?0:v>255?255:v+0.5);};
 for(int y=0;y<oh;++y)for(int x=0;x<ow;++x){auto p=&dst[(size_t(y)*ow+x)*4];int sx=x*2,sy=y*2;
  if(rgb){auto q=&src[(size_t(sy)*w+sx)*4];p[0]=q[0];p[1]=q[1];p[2]=q[2];}
  else{double yy=1.164383*(int(src[size_t(sy)*w+sx])-16);size_t uv=size_t(w)*h+size_t(sy/2)*w+(sx&~1);double u=int(src[uv])-128,v=int(src[uv+1])-128;p[2]=clip(yy+1.792741*v);p[1]=clip(yy-0.213249*u-0.532909*v);p[0]=clip(yy+2.112402*u);}
  p[3]=255;
 }
 channel.Publish(dst,ow,oh,w,h,frames,fps,elapsed,seconds);
 static ULONGLONG diskTime=0;if(channel.view&&GetTickCount64()-diskTime<1000)return;diskTime=GetTickCount64();
 BITMAPFILEHEADER fh{};BITMAPINFOHEADER ih{};fh.bfType=0x4d42;fh.bfOffBits=sizeof(fh)+sizeof(ih);fh.bfSize=fh.bfOffBits+DWORD(dst.size());ih.biSize=sizeof(ih);ih.biWidth=ow;ih.biHeight=-oh;ih.biPlanes=1;ih.biBitCount=32;ih.biSizeImage=DWORD(dst.size());
 auto path=dir+L"\\live.bmp",tmp=dir+L"\\live.tmp";std::ofstream f(tmp,std::ios::binary);f.write((char*)&fh,sizeof(fh));f.write((char*)&ih,sizeof(ih));f.write((char*)dst.data(),dst.size());f.close();
 if(!f){fprintf(stderr,"PREVIEW_WARNING write failed; native frame validation continues\n");return;}
 for(int retry=0;retry<20;++retry){if(MoveFileExW(tmp.c_str(),path.c_str(),MOVEFILE_REPLACE_EXISTING))return;DWORD error=GetLastError();if(retry==19)fprintf(stderr,"PREVIEW_WARNING replace error=%lu; native frame validation continues\n",error);else Sleep(10);}
}
static void Metrics(std::wstring const& dir,unsigned frames,long long first,long long last,int width,int height){
 if(dir.empty())return;double fps=frames>1&&last>first?(frames-1)*10000000.0/(last-first):0;
 char text[256];sprintf_s(text,"{\"frames\":%u,\"fps\":%.2f,\"width\":%d,\"height\":%d,\"fpsKind\":\"observed unique frame delivery\"}",frames,fps,width,height);
 auto tmp=dir+L"\\metrics.tmp",path=dir+L"\\metrics.json";std::ofstream f(tmp,std::ios::binary);f<<text;f.close();if(f)MoveFileExW(tmp.c_str(),path.c_str(),MOVEFILE_REPLACE_EXISTING);
}
int wmain(int argc,wchar_t**argv){
 setvbuf(stdout,nullptr,_IONBF,0);
 if(argc==2&&(std::wstring(argv[1])==L"--help"||std::wstring(argv[1])==L"--config-only")){puts("CONFIG256 revision=R22 cameraOpened=false usage=CameraProbe.exe (--name NAME | --device-id ID) --seconds 4 [--save-dir DIR]; or --enumerate-json FILE");return 0;}
 std::wstring name,deviceId,dir,enumerateFile,previewName,stopName;unsigned seconds=4,previewSide=0,ownerPid=0;
 for(int i=1;i<argc;++i){std::wstring arg=argv[i];if((arg==L"--name"||arg==L"--device-id"||arg==L"--enumerate-json"||arg==L"--seconds"||arg==L"--save-dir"||arg==L"--preview-map"||arg==L"--preview-side"||arg==L"--stop-event"||arg==L"--preview-owner")&&i+1<argc){auto v=argv[++i];if(arg==L"--name")name=v;else if(arg==L"--device-id")deviceId=v;else if(arg==L"--enumerate-json")enumerateFile=v;else if(arg==L"--save-dir")dir=v;else if(arg==L"--preview-map")previewName=v;else if(arg==L"--preview-side")previewSide=std::wstring(v)==L"front"?1:0;else if(arg==L"--stop-event")stopName=v;else if(arg==L"--preview-owner")ownerPid=wcstoul(v,nullptr,10);else seconds=wcstoul(v,nullptr,10);}else return 2;}
 if((name.empty()&&deviceId.empty()&&enumerateFile.empty())||(!name.empty()&&!deviceId.empty())||(!enumerateFile.empty()&&(!name.empty()||!deviceId.empty()||!dir.empty()))||(seconds<3&&(seconds!=0||stopName.empty()||!ownerPid))||seconds>15||(!dir.empty()&&GetFileAttributesW(dir.c_str())==INVALID_FILE_ATTRIBUTES))return 2;
 struct LiveHandles{HANDLE stop=nullptr,owner=nullptr;~LiveHandles(){if(stop)CloseHandle(stop);if(owner)CloseHandle(owner);}}live;
 if(seconds==0){live.stop=OpenEventW(SYNCHRONIZE,FALSE,stopName.c_str());live.owner=OpenProcess(SYNCHRONIZE,FALSE,ownerPid);if(!live.stop||!live.owner){puts("ERROR256 hr=80070006 message=Preview lifetime handles unavailable");return 5;}}
 PreviewChannel channel(previewName,previewSide);
 init_apartment(apartment_type::multi_threaded);ApartmentGuard apartmentGuard;MediaCapture capture{nullptr};MediaFrameReader reader{nullptr};bool started=false,saved=false,captureCreated=false,initializeAttempted=false,readerCreated=false,startAttempted=false,readerStopped=true,readerClosed=true,captureClosed=true;hresult result=S_OK;unsigned frames=0,duplicates=0;long long last=-1;double sum=0;unsigned minY=255,maxY=0;uint64_t sampled=0;uint32_t fnv=2166136261u;int width=0,height=0;
 try{
  LARGE_INTEGER freq;QueryPerformanceFrequency(&freq);printf("CLOCK256 frequency=%lld\n",freq.QuadPart);auto devices=DeviceInformation::FindAllAsync(DeviceInformation::GetAqsFilterFromDeviceClass(DeviceClass::VideoCapture),{L"System.Devices.DeviceInstanceId"}).get();hstring id;unsigned matches=0;
  std::string records;for(auto const& d:devices){auto record=DeviceRecord(d);printf("DEVICE256 %s\n",record.c_str());if(!records.empty())records+=",";records+=record;if((!deviceId.empty()&&d.Id()==deviceId)||(!name.empty()&&d.Name()==name)){id=d.Id();++matches;}}
  if(!enumerateFile.empty()){
   if(GetFileAttributesW(enumerateFile.c_str())!=INVALID_FILE_ATTRIBUTES)throw hresult_error(E_UNEXPECTED,L"Preserve existing enumeration");
   std::ofstream f(enumerateFile,std::ios::binary);f<<"{\"schema\":1,\"revision\":\"R22\",\"enumerationComplete\":true,\"cameraOpened\":false,\"devices\":["<<records<<"]}";f.close();if(!f)throw hresult_error(E_FAIL,L"Enumeration save failed");
   puts("ENUM256 complete=true cameraOpened=false");return 0;
  }
  printf("SELECT256 matches=%u\n",matches);if(matches!=1)throw hresult_error(E_UNEXPECTED,L"Exactly one selected camera required; see DEVICE256 list");
  MediaCaptureInitializationSettings settings;settings.VideoDeviceId(id);settings.StreamingCaptureMode(StreamingCaptureMode::Video);settings.MemoryPreference(MediaCaptureMemoryPreference::Cpu);settings.SharingMode(MediaCaptureSharingMode::ExclusiveControl);
  capture=MediaCapture();captureCreated=true;captureClosed=false;initializeAttempted=true;Mark("initialize_begin");capture.InitializeAsync(settings).get();Mark("initialize_complete");
  MediaFrameSource source{nullptr};MediaFrameFormat chosen{nullptr};int best=-1;
  for(auto const& kv:capture.FrameSources()){auto s=kv.Value();if(s.Info().SourceKind()!=MediaFrameSourceKind::Color)continue;for(auto const& f:s.SupportedFormats()){
   auto v=f.VideoFormat();wprintf(L"SOURCE256 subtype=%s width=%u height=%u stream=%u\n",f.Subtype().c_str(),v.Width(),v.Height(),unsigned(s.Info().MediaStreamType()));if(v.Width()>1920||v.Height()>1080||v.Width()<320||v.Height()<240)continue;
   int score=int(v.Width()*v.Height())+(f.Subtype()==L"NV12"?6000000:0)+(s.Info().MediaStreamType()==MediaStreamType::VideoPreview?3000000:0);if(score>best){best=score;source=s;chosen=f;}
  }}if(!source||!chosen)throw hresult_error(E_NOTIMPL,L"Color frame source unavailable");
  source.SetFormatAsync(chosen).get();width=int(chosen.VideoFormat().Width());height=int(chosen.VideoFormat().Height());wprintf(L"FORMAT256 width=%d height=%d subtype=%s stream=%u\n",width,height,chosen.Subtype().c_str(),unsigned(source.Info().MediaStreamType()));
  reader=capture.CreateFrameReaderAsync(source,chosen.Subtype()==L"NV12"?L"NV12":L"BGRA8").get();readerCreated=true;readerClosed=false;reader.AcquisitionMode(MediaFrameReaderAcquisitionMode::Realtime);startAttempted=true;readerStopped=false;Mark("reader_start_begin");if(reader.StartAsync().get()!=MediaFrameReaderStartStatus::Success)throw hresult_error(E_FAIL,L"Frame reader did not start");started=true;Mark("reader_started");
  ULONGLONG begin=GetTickCount64(),previewTime=0,metricsTime=0;long long firstStamp=-1;while(seconds?GetTickCount64()-begin<seconds*1000ull:(WaitForSingleObject(live.owner,0)==WAIT_TIMEOUT&&(GetTickCount64()-begin<3000||WaitForSingleObject(live.stop,0)==WAIT_TIMEOUT))){
   auto frame=reader.TryAcquireLatestFrame();if(!frame){Sleep(5);continue;}
   try{auto stamp=frame.SystemRelativeTime();if(stamp&&stamp.Value().count()==last){++duplicates;frame.Close();Sleep(5);continue;}if(stamp)last=stamp.Value().count();auto media=frame.VideoMediaFrame();auto bitmap=media?media.SoftwareBitmap():SoftwareBitmap{nullptr};
    if(bitmap){bool rgb=bitmap.BitmapPixelFormat()==BitmapPixelFormat::Bgra8;if((!rgb&&bitmap.BitmapPixelFormat()!=BitmapPixelFormat::Nv12)||bitmap.PixelWidth()!=width||bitmap.PixelHeight()!=height)throw hresult_error(E_UNEXPECTED,L"Unexpected NV12 shape");
     auto lock=bitmap.LockBuffer(BitmapBufferAccessMode::Read);auto ref=lock.CreateReference();auto access=ref.as<::Windows::Foundation::IMemoryBufferByteAccess>();BYTE* bytes=nullptr;UINT32 extent=0;check_hresult(access->GetBuffer(&bytes,&extent));auto p=lock.GetPlaneDescription(0);
     if(p.StartIndex<0||p.Stride<width*(rgb?4:1)||uint64_t(p.StartIndex)+uint64_t(height-1)*p.Stride+width*(rgb?4:1)>extent)throw hresult_error(E_UNEXPECTED,L"Plane extent rejected");
     for(int y=0;y<height;y+=32)for(int x=0;x<width;x+=32){auto pixel=bytes+p.StartIndex+size_t(y)*p.Stride+x*(rgb?4:1);unsigned v=rgb?(29*pixel[0]+150*pixel[1]+77*pixel[2]+128)/256:pixel[0];sum+=v;++sampled;if(v<minY)minY=v;if(v>maxY)maxY=v;fnv=(fnv^v)*16777619u;}
     access=nullptr;ref.Close();lock.Close();++frames;if(firstStamp<0)firstStamp=last;if(!dir.empty()&&GetTickCount64()-previewTime>=(channel.view?30:200)){double fps=frames>1&&last>firstStamp?(frames-1)*10000000.0/(last-firstStamp):0;Preview(dir,bitmap,channel,frames,fps,double(GetTickCount64()-begin),seconds);previewTime=GetTickCount64();}if(!dir.empty()&&GetTickCount64()-metricsTime>=200){Metrics(dir,frames,firstStamp,last,width,height);metricsTime=GetTickCount64();}if(!dir.empty()&&!saved&&GetTickCount64()-begin>=2500){Save(dir,bitmap);saved=true;}bitmap.Close();
    }frame.Close();
   }catch(...){frame.Close();throw;}Sleep(5);
  }
 }catch(hresult_error const& e){result=e.code();wprintf(L"ERROR256 hr=%08x message=%s\n",unsigned(result),e.message().c_str());}catch(...){result=E_UNEXPECTED;puts("ERROR256 unexpected");}
 channel.State(2);
 printf("STATE256 captureCreated=%u initializeAttempted=%u readerCreated=%u startAttempted=%u readerStarted=%u\n",captureCreated,initializeAttempted,readerCreated,startAttempted,started);
 auto close=[&](char const* label,auto f){try{f();printf("CLOSE256 %s hr=00000000\n",label);}catch(hresult_error const&e){result=e.code();printf("CLOSE256 %s hr=%08x\n",label,unsigned(e.code()));}catch(...){result=E_UNEXPECTED;printf("CLOSE256 %s hr=8000ffff\n",label);}};
 if(reader&&startAttempted)close("reader_stop",[&]{reader.StopAsync().get();started=false;readerStopped=true;});if(reader)close("reader_close",[&]{reader.Close();reader=nullptr;readerClosed=true;});if(capture)close("capture_close",[&]{capture.Close();capture=nullptr;captureClosed=true;});
 channel.State(3);
 printf("RETIRE256 neverOpened=%u readerStopped=%u readerClosed=%u captureClosed=%u\n",!captureCreated&&!initializeAttempted,readerStopped,readerClosed,captureClosed);
 bool signal=sampled&&maxY>0;printf("RESULT256 hr=%08x frames=%u duplicatePolls=%u width=%d height=%d meanY=%.6f minY=%u maxY=%u hash=%08x signal=%s saved=%s controlsChanged=false\n",unsigned(result),frames,duplicates,width,height,sampled?sum/sampled:0.,minY,maxY,fnv,signal?"true":"false",saved?"true":"false");return result.value>=0&&frames>=15&&signal&&(dir.empty()||saved)?0:5;
}
