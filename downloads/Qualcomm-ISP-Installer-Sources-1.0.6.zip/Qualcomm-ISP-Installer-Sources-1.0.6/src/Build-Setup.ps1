﻿$ErrorActionPreference='Stop'
$project=Split-Path -Parent $PSScriptRoot
New-Item -ItemType Directory -Path (Join-Path $project 'work') -Force|Out-Null
foreach($name in 'Install-App.ps1','Uninstall-App.ps1','Resume-Task.ps1'){$source=Join-Path $PSScriptRoot $name;$dest=Join-Path $project ('release\Scripts\'+$name);[IO.File]::WriteAllText($dest,[IO.File]::ReadAllText($source),[Text.UTF8Encoding]::new($true))}
& (Join-Path $PSScriptRoot 'Seal.ps1')
$zip=Join-Path $project 'work\payload.zip';Compress-Archive -Path (Join-Path $project 'release\*') -DestinationPath $zip -Force
$arguments=@('/nologo','/target:winexe','/platform:anycpu','/optimize+','/reference:System.Windows.Forms.dll','/reference:System.Drawing.dll','/reference:System.Web.Extensions.dll','/reference:System.IO.Compression.dll','/reference:System.IO.Compression.FileSystem.dll',('/win32manifest:'+(Join-Path $PSScriptRoot 'setup.manifest')),('/resource:'+$zip+',payload.zip'),('/out:'+(Join-Path $project 'Qualcomm-ISP-Drivers-Setup.exe')),(Join-Path $PSScriptRoot 'Bootstrap.cs'))
& "$env:windir\Microsoft.NET\Framework64\v4.0.30319\csc.exe" @arguments
if($LASTEXITCODE -ne 0){throw 'Setup build failed'}
