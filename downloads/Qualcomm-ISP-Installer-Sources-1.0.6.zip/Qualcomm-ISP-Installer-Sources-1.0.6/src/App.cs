﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.IO.Compression;
using System.IO.MemoryMappedFiles;
using System.Drawing.Imaging;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Runtime.InteropServices;
using System.Threading;
using System.Threading.Tasks;
using System.Web.Script.Serialization;
using System.Windows.Forms;
using Microsoft.Win32;

static class Program {
 [STAThread] static void Main(string[] args) {
  bool created;using(var mutex=new Mutex(true,"Local\\xiaomi-pad5-windows11-camera-UI",out created)) {
   if(!created){if(args.Contains("--resume"))return;MessageBox.Show("xiaomi-pad5-windows11-camera уже открыт. Дождитесь текущей операции.");return;}
   Application.EnableVisualStyles();Application.SetCompatibleTextRenderingDefault(false);
   Application.Run(new CameraApp(args.Contains("--resume"),args.Contains("--verify-install")));
  }
 }
}
sealed class InstallProgress : Control {
 public event EventHandler ValueChanged;
 int value;public int Value{get{return value;}set{int next=Math.Max(0,Math.Min(100,value));if(this.value==next)return;this.value=next;Invalidate();if(ValueChanged!=null)ValueChanged(this,EventArgs.Empty);}}
 public InstallProgress(){DoubleBuffered=true;ResizeRedraw=true;Font=new Font("Segoe UI",10,FontStyle.Bold);AccessibleName="Installation progress";}
 protected override void OnPaint(PaintEventArgs e){base.OnPaint(e);e.Graphics.Clear(Color.FromArgb(223,231,242));int fill=Width*value/100;using(var brush=new SolidBrush(Color.FromArgb(45,99,227)))e.Graphics.FillRectangle(brush,0,0,fill,Height);}
}
sealed class CameraApp : Form {
 [DllImport("psapi.dll")] static extern bool EmptyWorkingSet(IntPtr process);
 readonly string appRoot=AppDomain.CurrentDomain.BaseDirectory.TrimEnd('\\');
 readonly string dataRoot=Path.Combine(AppDomain.CurrentDomain.BaseDirectory,"Data");
 readonly JavaScriptSerializer json=new JavaScriptSerializer {MaxJsonLength=16*1024*1024};
 readonly Label status=new Label(),detail=new Label(),rearLabel=new Label(),frontLabel=new Label();
 readonly PictureBox rear=new PictureBox(),front=new PictureBox();
 readonly Panel cameraViewer=new Panel();Control rearCard,frontCard;string displayedSide="";
 readonly DataGridView devices=new DataGridView();
 readonly TextBox log=new TextBox();
 readonly Button install=new Button(),test=new Button(),previewButton=new Button(),scan=new Button(),export=new Button(),folder=new Button(),reboot=new Button(),later=new Button(),contact=new Button();
 readonly Label measurementLabel=new Label();readonly SemaphoreSlim liveGate=new SemaphoreSlim(1,1);
 readonly Stopwatch liveTextClock=Stopwatch.StartNew();
 NativeLivePreview nativeLive;CameraMeasurement measurement;LiveFrameInfo lastLiveFrame;long renderedSequence=-1;
 bool previewDesired,liveChanging,liveBlocked,changingLanguage,allowClose;string nativeSide="",previewBoot="",installationStatus="",installationDetail="";
 readonly string previewJournal=Path.Combine(AppDomain.CurrentDomain.BaseDirectory,"Data","LivePreviewSession.json");
 readonly ComboBox language=new ComboBox();bool russian=false;
 readonly ComboBox cameraChoice=new ComboBox();readonly TabControl pages=new TabControl();readonly TabPage installationPage=new TabPage("Установка"),cameraPage=new TabPage("Камеры");
 string selectedSide="both";
 readonly InstallProgress progress=new InstallProgress();
 readonly System.Windows.Forms.Timer timer=new System.Windows.Forms.Timer {Interval=500};
 readonly System.Windows.Forms.Timer previewTimer=new System.Windows.Forms.Timer {Interval=33};
 MemoryMappedFile previewMap;MemoryMappedViewAccessor previewView;byte[] previewBytes;
 EventWaitHandle previewStop;bool livePreview=false,stoppingPreview=false,closeAfterPreview=false;string nextCamera="";
 readonly Label rearError=new Label(),frontError=new Label();
 string previewName="";int previewSequence=-1,previewState=0;double previewElapsed=0;
 readonly string[] previewDirs=new string[2];
 readonly Dictionary<Control,string> textSources=new Dictionary<Control,string>();
 readonly HashSet<string> verifiedSides=new HashSet<string>();
 readonly Stopwatch operationTime=new Stopwatch();
 readonly int[] displayedFrames=new int[2];readonly long[] firstDisplay=new long[2],lastDisplay=new long[2];
 readonly Dictionary<string,DateTime> imageTimes=new Dictionary<string,DateTime>();
 string runRoot="",engineRoot="",mode="",lastStatus="",resumeBoot="";
 bool busy=false,resuming=false,installedCurrent=false,installVerificationPending=false;int rebootCycles=0;
 Process worker;
 Dictionary<string,object> result;
 Color ink=Color.FromArgb(28,39,57),blue=Color.FromArgb(45,99,227);
 static string Q(string s){return "\""+s.TrimEnd('\\')+"\"";}
 static object V(Dictionary<string,object> d,string key){object value;return d!=null&&d.TryGetValue(key,out value)?value:null;}
 static string S(Dictionary<string,object> d,string key){return Convert.ToString(V(d,key));}
 static bool B(Dictionary<string,object> d,string key){return V(d,key) is bool&&(bool)V(d,key);}
 static Dictionary<string,object> D(object value){return value as Dictionary<string,object>;}
 static IEnumerable<Dictionary<string,object>> Rows(object value){var arr=value as IEnumerable;if(arr!=null)foreach(var item in arr){var d=D(item);if(d!=null)yield return d;}}
 public CameraApp(bool resume,bool verifyInstall=false) {
  SuspendLayout();AutoScaleDimensions=new SizeF(96,96);AutoScaleMode=AutoScaleMode.Dpi;
  Text="Qualcomm ISP drivers for Xiaomi Pad 5 on Windows 11";StartPosition=FormStartPosition.CenterScreen;MinimumSize=new Size(800,620);Size=new Size(1180,760);
  Font=new Font("Segoe UI",10);BackColor=Color.FromArgb(242,245,250);ForeColor=ink;
  var layout=new TableLayoutPanel {Dock=DockStyle.Fill,Padding=new Padding(18),ColumnCount=1,RowCount=5};
  layout.RowStyles.Add(new RowStyle(SizeType.Absolute,58));layout.RowStyles.Add(new RowStyle(SizeType.AutoSize));layout.RowStyles.Add(new RowStyle(SizeType.Absolute,96));layout.RowStyles.Add(new RowStyle(SizeType.Percent,100));layout.RowStyles.Add(new RowStyle(SizeType.Absolute,32));
  Controls.Add(layout);
  var header=new TableLayoutPanel {Dock=DockStyle.Fill,ColumnCount=2,RowCount=2};header.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,100));header.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute,125));header.RowStyles.Add(new RowStyle(SizeType.Absolute,30));header.RowStyles.Add(new RowStyle(SizeType.Percent,100));
  var titleLabel=new Label {Text="Qualcomm ISP drivers for Xiaomi Pad 5 on Windows 11",Font=new Font("Segoe UI",14,FontStyle.Bold),Dock=DockStyle.Fill,ForeColor=ink,AutoEllipsis=true};header.Controls.Add(titleLabel,0,0);
  header.Controls.Add(new Label {Text="Xiaomi Pad 5 · nabu · ISP 253 / SYS080 / MFT075b · Test Mode required (test-signed)",Font=new Font("Segoe UI",9),Dock=DockStyle.Fill,ForeColor=Color.FromArgb(100,85,55)},0,1);
  language.DropDownStyle=ComboBoxStyle.DropDownList;language.Items.AddRange(new object[]{"English","Русский"});language.Width=116;language.Margin=new Padding(10,0,0,0);header.Controls.Add(language,1,0);header.SetRowSpan(language,2);layout.Controls.Add(header,0,0);
  var actions=new FlowLayoutPanel {Dock=DockStyle.Fill,WrapContents=true,AutoSize=true,AutoSizeMode=AutoSizeMode.GrowAndShrink,Padding=new Padding(0,0,0,10)};
  SetupButton(install,"Install",true,170);install.Visible=false;SetupButton(test,"Тест (10 с)",true,160);SetupButton(previewButton,"Остановить поток",false,190);SetupButton(scan,"Повторить проверку",false,193);SetupButton(export,"Сохранить отчёт",false,164);SetupButton(folder,"Журналы",false,108);
  SetupButton(contact,"Написать разработчику",false,220);actions.Controls.AddRange(new Control[]{scan,export,folder,contact});layout.Controls.Add(actions,0,1);
  pages.Dock=DockStyle.Fill;pages.TabPages.AddRange(new[]{installationPage,cameraPage});installationPage.BackColor=cameraPage.BackColor=BackColor;layout.Controls.Add(pages,0,3);
  var installBody=new TableLayoutPanel {Dock=DockStyle.Fill,RowCount=2,ColumnCount=1,Padding=new Padding(8)};installBody.RowStyles.Add(new RowStyle(SizeType.Percent,60));installBody.RowStyles.Add(new RowStyle(SizeType.Percent,40));installationPage.Controls.Add(installBody);
  var statePanel=new TableLayoutPanel {Dock=DockStyle.Fill,ColumnCount=1,RowCount=2};statePanel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,100));statePanel.RowStyles.Add(new RowStyle(SizeType.Absolute,48));statePanel.RowStyles.Add(new RowStyle(SizeType.Percent,100));
  SetText(status,"Готово к проверке");status.Font=new Font("Segoe UI",15,FontStyle.Bold);status.Dock=DockStyle.Fill;status.TextAlign=ContentAlignment.MiddleLeft;
  SetText(detail,"Установка завершается только после получения кадров с обеих камер.");detail.Dock=DockStyle.Fill;detail.ForeColor=Color.FromArgb(80,96,116);
  var primaryState=new TableLayoutPanel{Dock=DockStyle.Fill,ColumnCount=3,RowCount=1};primaryState.RowStyles.Add(new RowStyle(SizeType.Percent,100));primaryState.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute,0));primaryState.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute,0));primaryState.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,100));primaryState.Controls.Add(status,2,0);
  var primaryAction=new Panel{Dock=DockStyle.Fill,Margin=new Padding(0,0,10,0)};primaryState.Controls.Add(primaryAction,0,0);install.Dock=DockStyle.Fill;install.Margin=Padding.Empty;primaryAction.Controls.Add(install);
  SetupButton(reboot,"Перезагрузить систему",true,220);reboot.Dock=DockStyle.Fill;reboot.Margin=Padding.Empty;primaryAction.Controls.Add(reboot);reboot.Visible=false;
  SetupButton(later,"Отложить перезагрузку",false,220);later.Dock=DockStyle.Fill;later.Margin=new Padding(0,0,10,0);later.Visible=false;primaryState.Controls.Add(later,1,0);
  EventHandler updatePrimaryAction=(s,e)=>{float scale=CurrentAutoScaleDimensions.Width/96f;primaryState.ColumnStyles[0].Width=(install.Visible||reboot.Visible)?230*scale:0;primaryState.ColumnStyles[1].Width=later.Visible?230*scale:0;if(reboot.Visible)reboot.BringToFront();};install.VisibleChanged+=updatePrimaryAction;reboot.VisibleChanged+=updatePrimaryAction;later.VisibleChanged+=updatePrimaryAction;
  statePanel.Controls.Add(primaryState,0,0);statePanel.Controls.Add(detail,0,1);layout.Controls.Add(statePanel,0,2);
  devices.Dock=DockStyle.Fill;devices.BackgroundColor=Color.White;devices.BorderStyle=BorderStyle.None;devices.ReadOnly=true;devices.AllowUserToAddRows=false;devices.AllowUserToDeleteRows=false;devices.AllowUserToResizeRows=false;devices.RowHeadersVisible=false;devices.SelectionMode=DataGridViewSelectionMode.FullRowSelect;devices.AutoSizeColumnsMode=DataGridViewAutoSizeColumnsMode.Fill;devices.AutoSizeRowsMode=DataGridViewAutoSizeRowsMode.AllCells;devices.EnableHeadersVisualStyles=false;devices.ColumnHeadersDefaultCellStyle.BackColor=Color.FromArgb(230,236,245);devices.ColumnHeadersDefaultCellStyle.ForeColor=ink;devices.DefaultCellStyle.SelectionBackColor=Color.FromArgb(222,233,255);devices.DefaultCellStyle.SelectionForeColor=ink;
  devices.ColumnHeadersHeightSizeMode=DataGridViewColumnHeadersHeightSizeMode.AutoSize;devices.ColumnHeadersDefaultCellStyle.Padding=new Padding(3,6,3,6);devices.DefaultCellStyle.Padding=new Padding(3,3,3,3);devices.DefaultCellStyle.WrapMode=DataGridViewTriState.True;
  devices.Columns.Add("name","Устройство");devices.Columns.Add("state","Состояние");devices.Columns.Add("version","Драйвер");devices.Columns.Add("id","Идентификатор");devices.Columns[0].FillWeight=145;devices.Columns[1].FillWeight=60;devices.Columns[2].FillWeight=70;devices.Columns[3].FillWeight=115;installBody.Controls.Add(devices,0,0);
  var testBody=new TableLayoutPanel {Dock=DockStyle.Fill,ColumnCount=1,RowCount=3,Padding=new Padding(8)};testBody.RowStyles.Add(new RowStyle(SizeType.AutoSize));testBody.RowStyles.Add(new RowStyle(SizeType.Percent,100));testBody.RowStyles.Add(new RowStyle(SizeType.AutoSize));cameraPage.Controls.Add(testBody);
  var testActions=new FlowLayoutPanel {Dock=DockStyle.Fill,WrapContents=true,AutoSize=true,AutoSizeMode=AutoSizeMode.GrowAndShrink,Padding=new Padding(0,0,0,8)};cameraChoice.DropDownStyle=ComboBoxStyle.DropDownList;cameraChoice.Items.AddRange(new object[]{"Rear camera","Front camera"});cameraChoice.SelectedIndex=0;cameraChoice.Width=210;testActions.Controls.Add(cameraChoice);testActions.Controls.Add(previewButton);testActions.Controls.Add(test);testBody.Controls.Add(testActions,0,0);
  measurementLabel.AutoSize=true;measurementLabel.Dock=DockStyle.Fill;measurementLabel.Padding=new Padding(8,8,8,4);SetText(measurementLabel,"Поток запускается автоматически. «Тест» измеряет FPS и кадры за 10 секунд.");testBody.Controls.Add(measurementLabel,0,2);
  cameraViewer.Dock=DockStyle.Fill;cameraViewer.Padding=new Padding(8);cameraViewer.BackColor=Color.White;rearCard=CameraPanel(rear,rearLabel,"Задняя камера");frontCard=CameraPanel(front,frontLabel,"Фронтальная камера");cameraViewer.Controls.Add(frontCard);cameraViewer.Controls.Add(rearCard);testBody.Controls.Add(cameraViewer,0,1);ShowCamera("rear");
  log.Dock=DockStyle.Fill;log.Multiline=true;log.ReadOnly=true;log.ScrollBars=ScrollBars.Vertical;log.BorderStyle=BorderStyle.None;log.BackColor=Color.White;log.ForeColor=ink;log.Font=new Font("Consolas",9);log.Margin=new Padding(0,12,0,0);installBody.Controls.Add(log,0,1);
  var footer=new TableLayoutPanel {Dock=DockStyle.Fill,ColumnCount=2,RowCount=1};footer.RowStyles.Add(new RowStyle(SizeType.Percent,100));footer.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,65));footer.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,35));footer.Controls.Add(new Label {Text="Камеры тестируются по очереди · Кадры и отчёт сохраняются локально",Dock=DockStyle.Fill,Font=new Font("Segoe UI",9),ForeColor=Color.FromArgb(99,114,136)},0,0);var progressArea=new TableLayoutPanel{Dock=DockStyle.Fill,ColumnCount=2,RowCount=1,Margin=Padding.Empty};progressArea.RowStyles.Add(new RowStyle(SizeType.Percent,100));progressArea.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute,55));progressArea.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,100));var progressNumber=new Label{Text="0%",BackColor=Color.FromArgb(242,245,250),ForeColor=ink,Dock=DockStyle.Fill,TextAlign=ContentAlignment.MiddleCenter,Font=new Font("Segoe UI",10,FontStyle.Bold),Margin=Padding.Empty};progress.ValueChanged+=(s,e)=>progressNumber.Text=progress.Value+"%";progressArea.Controls.Add(progressNumber,0,0);progress.Dock=DockStyle.Fill;progressArea.Controls.Add(progress,1,0);footer.Controls.Add(progressArea,1,0);layout.Controls.Add(footer,0,4);
  install.Click+=async(s,e)=>{if(pages.SelectedTab!=installationPage)return;previewDesired=false;await ReconcileLive();if(liveBlocked)return;Start("Install");};test.Click+=(s,e)=>BeginMeasurement();previewButton.Click+=async(s,e)=>{previewDesired=!previewDesired;await ReconcileLive();};scan.Click+=async(s,e)=>{previewDesired=false;await ReconcileLive();if(!liveBlocked)Start("Scan");};folder.Click+=(s,e)=>{if(Directory.Exists(runRoot))Process.Start("explorer.exe",Q(runRoot));};export.Click+=(s,e)=>Export();
  cameraChoice.SelectedIndexChanged+=async(s,e)=>{if(changingLanguage||cameraChoice.SelectedIndex<0)return;string side=cameraChoice.SelectedIndex==1?"front":"rear";if(LiveAllowed&&pages.SelectedTab==cameraPage){previewDesired=true;await ReconcileLive();}else if(!busy)ShowCamera(side);};
  pages.SelectedIndexChanged+=async(s,e)=>{bool cameras=pages.SelectedTab==cameraPage;float dpi=CurrentAutoScaleDimensions.Width/96f;actions.Visible=!cameras;progressArea.Visible=!cameras;layout.RowStyles[2].Height=(cameras?74:96)*dpi;statePanel.RowStyles[0].Height=(cameras?38:48)*dpi;if(cameras){install.Visible=false;reboot.Visible=later.Visible=false;if(LiveAllowed){RememberInstallation();previewDesired=true;await ReconcileLive();}}else{previewDesired=false;await ReconcileLive();if(!busy&&!liveBlocked){RestoreInstallation();install.Visible=(!installedCurrent||installVerificationPending)&&(mode=="Scan"||mode=="Diagnose");reboot.Visible=later.Visible=result!=null&&B(result,"rebootRequired");}}};
  contact.Click+=(s,e)=>Process.Start("https://t.me/deskcj");
  language.SelectedIndexChanged+=(s,e)=>{russian=language.SelectedIndex==1;int index=cameraChoice.SelectedIndex;changingLanguage=true;try{cameraChoice.Items.Clear();cameraChoice.Items.AddRange(russian?new object[]{"Задняя камера","Фронтальная камера"}:new object[]{"Rear camera","Front camera"});cameraChoice.SelectedIndex=index;}finally{changingLanguage=false;}ApplyLanguage(this);UpdateLiveControls();progressNumber.Text=progress.Value+"%";log.Text=Tr(log.Text);foreach(DataGridViewColumn column in devices.Columns)column.HeaderText=Tr(column.HeaderText);Directory.CreateDirectory(dataRoot);File.WriteAllText(Path.Combine(dataRoot,"language.txt"),russian?"ru":"en");};
  language.SelectedIndex=File.Exists(Path.Combine(dataRoot,"language.txt"))&&File.ReadAllText(Path.Combine(dataRoot,"language.txt")).Trim()=="ru"?1:0;
  reboot.Click+=(s,e)=>RestartNow();later.Click+=(s,e)=>{SetText(status,"Перезагрузка отложена");SetText(detail,"Продолжение сохранено. После следующего входа установка возобновится.");later.Enabled=false;};
  FormClosing+=async(s,e)=>{if(allowClose)return;if(busy){e.Cancel=true;MessageBox.Show(this,Tr("Идёт проверка или установка. Дождитесь завершения; камеры должны закрыться штатно."),Tr("Операция выполняется"));return;}if(nativeLive!=null||liveChanging){e.Cancel=true;previewDesired=false;await ReconcileLive();allowClose=true;Close();}};
  timer.Tick+=(s,e)=>{try{if(busy&&worker!=null&&worker.HasExited){Finished(worker.ExitCode);if(pages.SelectedTab==cameraPage){install.Visible=false;RememberInstallation();if(!busy&&nativeLive==null)BeginPreview();}}else if(busy)Poll();}catch(Exception ex){SetText(detail,ex.Message);Directory.CreateDirectory(dataRoot);File.AppendAllText(Path.Combine(dataRoot,"app-errors.log"),DateTime.Now+" "+ex+Environment.NewLine);}};timer.Start();
  previewTimer.Tick+=(s,e)=>{if(nativeLive!=null)ReadLiveFrame();else if(busy)ReadPreview();};previewTimer.Start();
  FormClosed+=(s,e)=>{timer.Stop();previewTimer.Stop();ClosePreview();};
  ResumeLayout(true);
  Shown+=(s,e)=>{var area=Screen.FromControl(this).WorkingArea;Size=new Size(Math.Min(Width,area.Width-24),Math.Min(Height,area.Height-24));Location=new Point(area.X+(area.Width-Width)/2,area.Y+(area.Height-Height)/2);resuming=resume||verifyInstall;if(resume)ReadResume();Start("Scan");};
 }
 void SetupButton(Button b,string text,bool primary,int width){b.Text=text;b.Width=width;b.Height=44;b.Margin=new Padding(0,0,9,8);b.Padding=new Padding(9,4,9,4);b.FlatStyle=FlatStyle.Flat;b.FlatAppearance.BorderSize=primary?0:1;b.FlatAppearance.BorderColor=Color.FromArgb(202,213,228);b.BackColor=primary?blue:Color.White;b.ForeColor=primary?Color.White:ink;b.Cursor=Cursors.Hand;}
 Control CameraPanel(PictureBox picture,Label label,string title){
  var panel=new TableLayoutPanel {Dock=DockStyle.Fill,RowCount=2,Margin=new Padding(0,0,10,0),BackColor=Color.White};panel.RowStyles.Add(new RowStyle(SizeType.Absolute,38));panel.RowStyles.Add(new RowStyle(SizeType.Percent,100));label.Text=title+" · ещё не проверена";label.Font=new Font("Segoe UI",10,FontStyle.Bold);label.Dock=DockStyle.Fill;label.TextAlign=ContentAlignment.MiddleLeft;label.Padding=new Padding(10,0,0,0);picture.SizeMode=PictureBoxSizeMode.Zoom;picture.BackColor=Color.FromArgb(235,240,247);var viewport=new Panel{Dock=DockStyle.Fill,BackColor=Color.White};viewport.Controls.Add(picture);var error=picture==rear?rearError:frontError;error.Dock=DockStyle.Fill;error.TextAlign=ContentAlignment.MiddleCenter;error.Font=new Font("Segoe UI",13);error.Padding=new Padding(24);error.BackColor=Color.FromArgb(235,240,247);viewport.Controls.Add(error);error.BringToFront();SetText(error,"Камера готова к запуску");viewport.Resize+=(s,e)=>FitImage(picture);panel.Controls.Add(label,0,0);panel.Controls.Add(viewport,0,1);return panel;
 }
 void FitImage(PictureBox picture){if(picture.Parent==null)return;var area=picture.Parent.DisplayRectangle;double aspect=picture.Image==null?16.0/9:picture.Image.Width/(double)picture.Image.Height;int width=Math.Max(0,Math.Min(area.Width,(int)(area.Height*aspect)));int height=Math.Max(0,Math.Min(area.Height,(int)(width/aspect)));picture.Bounds=new Rectangle(area.X+(area.Width-width)/2,area.Y+(area.Height-height)/2,width,height);}
 void ShowCamera(string side){if(rearCard==null||frontCard==null)return;bool showFront=side=="front";if(cameraChoice.Items.Count==2)cameraChoice.SelectedIndex=showFront?1:0;if(displayedSide==side&&(showFront?frontCard:rearCard).Visible)return;displayedSide=side;cameraViewer.SuspendLayout();rearCard.Visible=!showFront;frontCard.Visible=showFront;(showFront?frontCard:rearCard).BringToFront();cameraViewer.ResumeLayout(true);FitImage(showFront?front:rear);}
 static readonly string[][] Words={
  new[]{"Старая виртуальная камера отключена","Old virtual camera disabled"},
  new[]{"Восстановление базовых драйверов","Restore base camera drivers"},
  new[]{"Нажмите «Установить»: программа восстановит Qualcomm Camera Platform, JPEG и Flash, затем установит ISP253.","Click Install: the app restores Qualcomm Camera Platform, JPEG and Flash, then installs ISP253."},
  new[]{"Кадры получены; закрытие камеры Windows проверено.","Frames received; Windows camera closure verified."},
  new[]{"Служебные отметки драйвера недоступны; проверка кадров и закрытия Windows выполнена.","Native debug markers are unavailable; frames and Windows camera closure were verified."},
  new[]{"Ошибка сохраняется после нескольких перезагрузок. Автоматическое продолжение остановлено. Сохраните отчёт; повторная перезагрузка сама по себе не исправит причину.","The error persists after several restarts. Automatic resume has stopped. Save a report; another restart alone will not fix the cause."},
  new[]{"Драйверы установлены. Нажмите «Продолжить проверку», чтобы сохранить данные камер в системной папке Windows и проверить камеры.","Drivers are installed. Click Continue verification to move permanent camera data to the Windows driver directory and check the cameras."},
  new[]{"Драйверы 253 проверены. Обе камеры передают кадры и закрылись без ошибок.","Driver 253 verified. Both cameras delivered frames and closed without errors."},
  new[]{"Тест (10 с)","Test (10 s)"},new[]{"Измерение…","Measuring…"},new[]{"Подключение…","Connecting…"},new[]{"Остановить поток","Stop stream"},new[]{"Запустить поток","Start stream"},new[]{"Поток остановлен","Stream stopped"},new[]{"Нет потока камеры","No camera stream"},new[]{"Измерение потока","Measuring stream"},new[]{"Измерение: ","Measuring: "},new[]{"поток продолжается","stream continues"},new[]{"Яркость ","Brightness "},
  new[]{"Поток запускается автоматически. «Тест» измеряет FPS и кадры за 10 секунд.","Preview starts automatically. Test measures FPS and frames over 10 seconds."},
  new[]{"Непрерывный поток · выберите заднюю или фронтальную камеру","Live stream · select the rear or front camera"},
  new[]{"Нажмите «Запустить поток», чтобы снова включить выбранную камеру.","Click Start stream to open the selected camera again."},
  new[]{"Закрытие камеры не подтверждено. Перезагрузите Windows перед следующим запуском или установкой.","Camera closure was not confirmed. Restart Windows before another preview or installation."},
  new[]{"Установить","Install"},new[]{"Проверка камеры…","Testing camera…"},new[]{"Установка завершена","Installation complete"},new[]{"Тест завершён","Test complete"},
  new[]{"Захват кадров","Capturing frames"},new[]{"Закрытие камеры","Closing camera"},new[]{"Ожидание завершения службы камеры","Waiting for the camera service to close"},new[]{"Проверка журналов драйвера","Verifying driver logs"},new[]{"Подготовка камеры","Preparing camera"},
  new[]{"Прошло","Elapsed"},new[]{"Изображение остановлено. Проверка продолжается.","Picture stopped. Verification is continuing."},new[]{"Кадры получены; закрытие камеры Windows проверено.","Frames received; camera closure and driver logs verified."},
  new[]{"15 с живого изображения, затем проверка закрытия и журналов","15 s live picture, then camera closure and log checks"},
  new[]{"Запустить камеру","Start camera"},new[]{"Остановить камеру","Stop camera"},new[]{"Закрытие камеры…","Closing camera…"},new[]{"Запуск камеры…","Starting camera…"},new[]{"Живой поток камеры","Live camera stream"},new[]{"Камера готова к запуску","Camera is ready"},new[]{"Камера включена","Camera is live"},new[]{"Поток камеры остановлен","Camera preview stopped"},new[]{"Живой поток камеры · выберите Rear или Front","Live camera preview · select Rear or Front"},
  new[]{"Перезагрузить систему","Restart system"},new[]{"Продолжение сохранено. Нажмите «Перезагрузить систему». После входа установка и проверка камер продолжатся.","Resume is saved. Click Restart system. Installation and camera verification continue after Windows sign-in."},
  new[]{"Отложить перезагрузку","Restart later"},
  new[]{"Драйверы уже установлены","Drivers already installed"},new[]{"Продолжить проверку","Continue verification"},new[]{"Драйверы установлены · нужна проверка","Drivers installed · verification needed"},
  new[]{"Установлен актуальный комплект Qualcomm ISP253. Повторная установка не требуется. Для проверки изображения откройте «Камеры».","The current Qualcomm ISP253 package is already installed. No reinstall is needed. Open Cameras to check the live image."},
  new[]{"Драйверы установлены. Повторная установка не требуется; проверка камер ещё не завершена. Нажмите «Продолжить проверку».","Drivers are installed. No reinstall is needed; camera verification is incomplete. Click Continue verification."},
  new[]{"Обнаружены старые или неполные драйверы. Нажмите «Установить», чтобы обновить или исправить комплект.","Older or incomplete drivers detected. Click Install to update or repair the package."},
  new[]{"Не удалось подтвердить установленный комплект. Подробности — в журналах.","The installed package could not be confirmed. See Logs for details."},
  new[]{"Драйверы установлены и кадры получены. Журнал не подтвердил закрытие камеры; проверка не завершена. Перезагрузите Windows для продолжения.","Drivers are installed and frames received. Camera closure is unconfirmed in the log; verification is incomplete. Restart Windows to continue."},
  new[]{"Нужен Test Mode (тестовая подпись)","Test Mode required (test-signed)"},new[]{"Требуется Test Mode","Test Mode required"},new[]{"Драйверы имеют тестовую подпись. Включите Test Mode, перезагрузите Windows и нажмите «Повторить проверку».","These drivers are test-signed. Enable Test Mode, restart Windows, then click Rescan devices."},
  new[]{"Проверить камеру (15 с)","Test camera (15 s)"},new[]{"Повторить проверку","Rescan devices"},new[]{"Показывает изображение камеры и измеряет FPS","Shows the camera picture and measures FPS"},new[]{"Установка…","Installing…"},new[]{"Проверка камеры","Testing camera"},
  new[]{"Установка","Installation"},new[]{"Камеры","Cameras"},new[]{"Начать тест камеры","Start camera test"},new[]{"Обе камеры (по очереди)","Both cameras (sequential)"},new[]{"Тест 15 секунд · одна камера за раз","15-second test · one camera at a time"},new[]{"Выбранная камера работает","Selected camera works"},
  new[]{"Установить / исправить","Install / repair"},new[]{"Тест обеих камер","Test both cameras"},new[]{"Проверить устройства","Scan devices"},new[]{"Сохранить отчёт","Save report"},new[]{"Журналы","Logs"},new[]{"Написать разработчику","Contact developer"},new[]{"Перезагрузить","Restart now"},new[]{"Отложить","Later"},
  new[]{"Готово к проверке","Ready"},new[]{"Установка завершается только после получения кадров с обеих камер.","Installation completes only after both cameras deliver frames."},new[]{"Камеры тестируются по очереди · Кадры и отчёт сохраняются локально","Cameras are tested in sequence · Frames and reports stay on this device"},
  new[]{"Задняя камера","Rear camera"},new[]{"Фронтальная камера","Front camera"},new[]{"ещё не проверена","not tested yet"},new[]{"тест идёт, живое изображение","testing, live image"},new[]{"кадров","frames"},
  new[]{"Устройство","Device"},new[]{"Состояние","Status"},new[]{"Драйвер","Driver"},new[]{"Идентификатор","Device ID"},new[]{"Код ","Code "},
  new[]{"Проверка устройств","Scanning devices"},new[]{"Ожидание установки","Starting installation"},new[]{"Проверка файлов и конфигурации Windows","Checking files and Windows configuration"},new[]{"Подтвердите запрос Windows на права администратора.","Approve the Windows administrator prompt to continue."},
  new[]{"Устройства проверены","Devices checked"},new[]{"Устройства и условия установки проверены","Devices and installation requirements checked"},new[]{"Проверка устройства и комплекта","Checking the tablet and package"},new[]{"Установка и исправление конфигурации камер","Installing and repairing camera configuration"},new[]{"Проверка кадров обеих камер","Testing frames from both cameras"},
  new[]{"Проверка Secure Boot","Secure Boot check"},
  new[]{"Secure Boot включён. Отключите его в UEFI и перезагрузите Windows.","Secure Boot is enabled. Disable it in UEFI and restart Windows."},
  new[]{"UEFI не сообщает состояние Secure Boot; ядро Windows разрешает тестовые драйверы.","UEFI does not report Secure Boot; the current Windows kernel permits test-signed drivers."},
  new[]{"Не удалось определить Secure Boot. Подтвердите его отключение в UEFI и повторите установку с правами администратора.","Secure Boot could not be determined. Check that it is disabled in UEFI and retry installation with administrator rights."},
  new[]{"Перед установкой нужно исправить: ","Before installation, resolve: "},
  new[]{"Драйверы имеют тестовую подпись. Включите Test Mode, перезагрузите Windows и нажмите «Повторить проверку».","These drivers are test-signed. Enable Test Mode, restart Windows, then click Rescan devices."},
  new[]{"Нажмите «Установить», чтобы установить или исправить драйверы камер.","Click Install to install or repair the camera drivers."},
  new[]{"Установка и проверка","Installing and verifying"},new[]{"Обе камеры работают","Both cameras work"},new[]{"Нужна перезагрузка","Restart required"},new[]{"Нужно исправление","Repair required"},new[]{"Проверка конфигурации","Checking configuration"},new[]{"Подготовка перезагрузки","Preparing restart"},
  new[]{"Драйверы 253 проверены. Обе камеры передают кадры и закрылись без ошибок.","Driver 253 verified. Both cameras delivered frames and closed successfully."},new[]{"Есть условия для исправления","Some requirements need attention"},new[]{"Смотрите проверки ниже. После исправления повторите установку.","Review the checks below, then run Install / repair again."},
  new[]{"Определение физических камер по идентификаторам","Identifying physical cameras"},new[]{"Получение кадров: ","Capturing frames: "},new[]{"фронтальная камера","front camera"},new[]{"задняя камера","rear camera"},new[]{"Проверка завершения захвата и журналов драйвера","Checking capture closure and driver logs"},new[]{"Установка камерного драйвера: ","Installing camera driver: "},new[]{"Сохранение резервной копии текущих камерных драйверов","Backing up current camera drivers"},new[]{"Проверка файлов, устройств и конфигурации","Checking files, devices and configuration"},
  new[]{"Перезагрузка через ","Restarting in "},new[]{"После входа в Windows установка продолжится. Сохраните открытые документы; можно отложить.","Setup resumes after Windows sign-in. Save open documents, or choose Later."},new[]{"Перезагрузка отложена","Restart postponed"},new[]{"Продолжение сохранено. После следующего входа установка возобновится.","Progress is saved. Setup resumes after the next Windows sign-in."},new[]{"Нужна перезагрузка Windows","Windows restart required"},new[]{"Сеанс ядра ещё не изменился. Перезапустите Windows обычной перезагрузкой.","The kernel session has not changed. Use a normal Windows restart."},
  new[]{"Повторная перезагрузка остановлена","Automatic restarts paused"},new[]{"Три этапа перезагрузки не завершили установку. Сохраните отчёт для разбора причины.","Three restart stages did not complete setup. Save the report to investigate."},new[]{"Продолжение не сохранено","Resume was not saved"},new[]{"Перезагрузка Windows","Restarting Windows"},new[]{"Запуск не выполнен","Could not start"},new[]{"Нет результата","No result"},new[]{"Нужен разбор отчёта","Report review required"},
  new[]{"Целостность комплекта","Package integrity"},new[]{"Обнаружено: ","Found: "},new[]{"Штатный компонент ","Base component "},new[]{"найдено: ","found: "},new[]{"Secure Boot выключен","Secure Boot disabled"},new[]{"Тестовый режим драйверов","Driver test mode"},new[]{"Доступ Windows к камере","Windows camera access"},new[]{"Место на системном диске","System drive space"},new[]{" свободно"," free"},new[]{" файлов"," files"},
  new[]{"Нужна перезагрузка. Продолжение сохранено; после входа приложение откроется снова.","A restart is needed. Progress is saved; the app reopens after sign-in."},new[]{"Проверка не завершена: ","Verification incomplete: "}
 };
 string Tr(string text){if(string.IsNullOrEmpty(text))return text;foreach(var pair in Words.OrderByDescending(p=>russian?p[1].Length:p[0].Length))text=text.Replace(russian?pair[1]:pair[0],russian?pair[0]:pair[1]);return text;}
 void SetText(Control control,string source){textSources[control]=source;string translated=Tr(source);if(control.Text!=translated)control.Text=translated;}
 void ApplyLanguage(Control parent){if(parent==install)SetText(parent,installedCurrent&&installVerificationPending?"Продолжить проверку":"Установить");else if(parent!=language&&parent!=cameraChoice&&parent!=log&&parent!=devices){string source;if(!textSources.TryGetValue(parent,out source))source=parent.Text;SetText(parent,source);}foreach(Control child in parent.Controls)ApplyLanguage(child);}
 void SetBusy(bool value){busy=value;install.Enabled=scan.Enabled=export.Enabled=!value;install.Visible=pages.SelectedTab==installationPage&&!value&&(mode=="Scan"||mode=="Diagnose")&&(!installedCurrent||installVerificationPending);status.Visible=true;language.Enabled=!value;if(value){progress.Value=0;operationTime.Restart();}else operationTime.Stop();UpdateLiveControls();}
 void RememberInstallation(){string source;if(textSources.TryGetValue(status,out source))installationStatus=source;if(textSources.TryGetValue(detail,out source))installationDetail=source;}
 void RestoreInstallation(){if(installationStatus.Length>0)SetText(status,installationStatus);if(installationDetail.Length>0)SetText(detail,installationDetail);status.ForeColor=installedCurrent?Color.FromArgb(20,132,85):ink;}
 bool LiveAllowed{get{return !busy||mode=="Scan";}}
 void UpdateLiveControls(){cameraChoice.Enabled=LiveAllowed&&!liveChanging&&!liveBlocked;previewButton.Enabled=LiveAllowed&&!liveChanging&&!liveBlocked;test.Enabled=LiveAllowed&&!liveChanging&&!liveBlocked&&measurement==null&&lastLiveFrame!=null&&lastLiveFrame.HasImage;SetText(previewButton,liveChanging?"Подключение…":nativeLive!=null?"Остановить поток":"Запустить поток");SetText(test,measurement!=null?"Измерение…":"Тест (10 с)");}
 async void BeginPreview(){if(!LiveAllowed||liveBlocked)return;RememberInstallation();previewDesired=true;await ReconcileLive();}
 void WritePreviewJournal(bool closed,string message){Directory.CreateDirectory(dataRoot);string temp=previewJournal+".tmp";File.WriteAllText(temp,json.Serialize(new{schema=1,boot=previewBoot,captureClosed=closed,side=nativeSide,updated=DateTime.UtcNow.ToString("o"),message=message}),Encoding.UTF8);if(File.Exists(previewJournal))File.Replace(temp,previewJournal,null);else File.Move(temp,previewJournal);}
 async Task ReconcileLive(){
  await liveGate.WaitAsync();liveChanging=true;UpdateLiveControls();
  try{
   string target=cameraChoice.SelectedIndex==1?"front":"rear";bool wanted=previewDesired&&LiveAllowed&&pages.SelectedTab==cameraPage&&!allowClose;
   if(nativeLive!=null&&(!wanted||nativeSide!=target)){
    measurement=null;lastLiveFrame=null;Exception closeError=null;try{await nativeLive.StopAsync();WritePreviewJournal(true,"MediaCapture stopped and disposed");}catch(Exception e){closeError=e;}nativeLive=null;
    if(closeError!=null){liveBlocked=true;previewDesired=false;ShowLiveError(closeError);SetText(detail,"Закрытие камеры не подтверждено. Перезагрузите Windows перед следующим запуском или установкой.");return;}
    if(!wanted){SetText(status,"Поток остановлен");SetText(detail,"Нажмите «Запустить поток», чтобы снова включить выбранную камеру.");}
   }
   if(wanted&&nativeLive==null&&!liveBlocked){
    Exception failure=null;try{
     previewBoot=XiaomiPad5.PreviewBoot.Read();var journal=ReadJson(previewJournal);if(File.Exists(previewJournal)&&(journal==null||S(journal,"boot").Length==0||!(V(journal,"captureClosed") is bool)||(!B(journal,"captureClosed")&&S(journal,"boot")==previewBoot))){liveBlocked=true;throw new InvalidOperationException("The previous preview did not close. Restart Windows before opening a camera or installing drivers.");}
     string nativeStatePath=Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Windows),"System32","drivers","XiaomiPad5Camera","state.json");if(!File.Exists(nativeStatePath))nativeStatePath=Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData),"XiaomiPad5Camera","state.json");var nativeState=ReadJson(nativeStatePath);var identity=D(V(nativeState,"bootIdentity"));string nativeBoot=S(identity,"bootId")+":"+S(identity,"bootCounter");if(nativeState!=null&&nativeBoot==previewBoot&&(B(nativeState,"unsafeToContinue")||B(nativeState,"rebootRequired")||V(nativeState,"captureClosed") is bool&&!B(nativeState,"captureClosed"))){liveBlocked=true;throw new InvalidOperationException("The installation camera check has an unfinished capture in this kernel session. Restart Windows before opening the camera again.");}
     nativeSide=target;renderedSequence=-1;lastLiveFrame=null;measurement=null;ClearImages();ShowCamera(target);SetText(measurementLabel,"Поток запускается автоматически. «Тест» измеряет FPS и кадры за 10 секунд.");SetText(status,"Запуск камеры…");SetText(detail,"Непрерывный поток · выберите заднюю или фронтальную камеру");SetText(target=="rear"?rearError:frontError,"Запуск камеры…");(target=="rear"?rearError:frontError).Visible=true;
     WritePreviewJournal(false,"Opening MediaCapture");nativeLive=new NativeLivePreview();await nativeLive.StartAsync(target);
    }catch(Exception e){failure=e;}
    if(failure!=null){
     if(nativeLive!=null){try{await nativeLive.StopAsync();WritePreviewJournal(true,"Start failed; MediaCapture disposed");}catch(Exception e){liveBlocked=true;failure=new InvalidOperationException(failure.Message+"; "+e.Message,e);}nativeLive=null;}
     previewDesired=false;ShowLiveError(failure);
    }
   }
  }catch(Exception e){previewDesired=false;ShowLiveError(e);}finally{liveChanging=false;UpdateLiveControls();if(pages.SelectedTab==cameraPage&&LiveAllowed&&cameraChoice.Enabled)cameraChoice.Focus();liveGate.Release();}
 }
 void ShowLiveError(Exception error){string message=error.Message+"\n0x"+error.HResult.ToString("X8");var label=nativeSide=="front"?frontError:rearError;SetText(label,CameraFailure(message));label.Visible=true;label.BringToFront();SetText(status,"Нет потока камеры");SetText(detail,CameraFailure(message));Directory.CreateDirectory(Path.Combine(dataRoot,"Logs"));File.AppendAllText(Path.Combine(dataRoot,"Logs","live-preview-errors.log"),DateTime.UtcNow.ToString("o")+" "+error+Environment.NewLine);}
 async void ReadLiveFrame(){
  if(nativeLive==null||liveChanging)return;Exception failure=null;
  try{
   var frame=nativeLive.Snapshot();lastLiveFrame=frame;
   if(nativeLive.SecondsSinceFrame>5)throw new InvalidOperationException(frame.HasImage?"The camera stopped delivering frames. Close other camera apps and try Start stream again.":"No camera frames arrived. Check Windows camera access and close other camera apps, then try Start stream again.");
   if(!frame.HasImage)return;
   var box=frame.Side=="front"?front:rear;var label=frame.Side=="front"?frontLabel:rearLabel;
   if(renderedSequence!=frame.Sequence){var bitmap=box.Image as Bitmap;if(bitmap==null||bitmap.Width!=frame.PreviewWidth||bitmap.Height!=frame.PreviewHeight){bitmap=new Bitmap(frame.PreviewWidth,frame.PreviewHeight,PixelFormat.Format32bppRgb);var old=box.Image;box.Image=bitmap;if(old!=null)old.Dispose();FitImage(box);}nativeLive.Render(bitmap);box.Invalidate();renderedSequence=frame.Sequence;}
   (frame.Side=="front"?frontError:rearError).Visible=false;
   if(liveTextClock.ElapsedMilliseconds<250)return;liveTextClock.Restart();
   SetText(label,(frame.Side=="front"?"Фронтальная камера":"Задняя камера")+" · "+frame.Width+"×"+frame.Height+" · "+frame.Fps.ToString("0.0")+" FPS · "+frame.Frames+" кадров · "+frame.Format);
   if(measurement!=null){SetText(measurementLabel,"Измерение: "+Math.Min(10,measurement.Elapsed).ToString("0.0")+" / 10 s · "+measurement.Frames(frame)+" кадров · "+measurement.Fps(frame).ToString("0.0")+" FPS");if(measurement.Elapsed>=10)FinishMeasurement(frame);}
   SetText(status,measurement==null?"Камера включена":"Измерение потока");SetText(detail,"Непрерывный поток · выберите заднюю или фронтальную камеру");status.ForeColor=Color.FromArgb(20,132,85);UpdateLiveControls();
  }catch(Exception e){failure=e;}
  if(failure!=null){measurement=null;previewDesired=false;await ReconcileLive();ShowLiveError(failure);}
 }
 void BeginMeasurement(){if(nativeLive==null||liveChanging||lastLiveFrame==null||!lastLiveFrame.HasImage||measurement!=null)return;measurement=new CameraMeasurement(nativeLive.Snapshot());SetText(measurementLabel,"Измерение: 0 / 10 s · поток продолжается");UpdateLiveControls();}
 void FinishMeasurement(LiveFrameInfo frame){
  var sample=measurement;measurement=null;long count=sample.Frames(frame);double fps=sample.Fps(frame);
  SetText(measurementLabel,"Тест завершён · "+fps.ToString("0.00")+" FPS · "+count+" кадров · "+frame.Width+"×"+frame.Height+" · "+frame.Format+" · Яркость "+frame.Brightness.ToString("0")+" / 255");
  try{string directory=Path.Combine(Directory.Exists(runRoot)?runRoot:Path.Combine(dataRoot,"Logs"),"LiveTests");Directory.CreateDirectory(directory);File.WriteAllText(Path.Combine(directory,DateTime.Now.ToString("yyyyMMdd-HHmmss")+"-"+frame.Side+".json"),json.Serialize(new{schema=1,appVersion="1.0.6",side=frame.Side,elapsedSeconds=sample.Elapsed,frames=count,fps=fps,width=frame.Width,height=frame.Height,format=frame.Format,nominalFps=frame.NominalFps,displayWidth=frame.PreviewWidth,displayHeight=frame.PreviewHeight,meanBrightness=frame.Brightness,completed=count>0,streamContinues=true}),Encoding.UTF8);}catch(Exception e){SetText(measurementLabel,measurementLabel.Text+" · "+e.Message);}UpdateLiveControls();
 }
 void ClearImages(){foreach(var p in new[]{rear,front}){var old=p.Image;p.Image=null;if(old!=null)old.Dispose();}SetText(rearLabel,"Задняя камера · ещё не проверена");SetText(frontLabel,"Фронтальная камера · ещё не проверена");imageTimes.Clear();}
 void Start(string requested) {
  if(nativeLive!=null||liveChanging||liveBlocked)return;
  if(requested=="Scan"){installedCurrent=false;installVerificationPending=false;status.ForeColor=ink;}
  if(busy)return;ClosePreview();if(requested!="Diagnose")livePreview=false;previewDirs[0]=previewDirs[1]=null;Array.Clear(displayedFrames,0,2);Array.Clear(firstDisplay,0,2);Array.Clear(lastDisplay,0,2);verifiedSides.Clear();reboot.Visible=later.Visible=false;mode=requested;engineRoot="";lastStatus="";result=null;
  if(requested=="Install"){selectedSide="both";cameraChoice.SelectedIndex=0;}
  Directory.CreateDirectory(Path.Combine(dataRoot,"Logs"));runRoot=Path.Combine(dataRoot,"Logs",DateTime.Now.ToString("yyyyMMdd-HHmmss")+"-"+Guid.NewGuid().ToString("N").Substring(0,6));Directory.CreateDirectory(runRoot);
  if(requested!="Scan"){ClearImages();ShowCamera(requested=="Diagnose"&&selectedSide=="front"?"front":"rear");previewName="Local\\xiaomi-pad5-camera-preview-"+Guid.NewGuid().ToString("N");previewMap=MemoryMappedFile.CreateNew(previewName,64+960*540*4);previewView=previewMap.CreateViewAccessor();}else install.Visible=false;log.Clear();status.ForeColor=ink;SetText(status,requested=="Scan"?"Проверка устройств":requested=="Install"?"Установка…":"Проверка камеры");SetText(detail,requested=="Scan"?"Проверка файлов и конфигурации Windows":"Подтвердите запрос Windows на права администратора.");SetBusy(true);
  try {
   var psi=new ProcessStartInfo(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Windows),"System32\\WindowsPowerShell\\v1.0\\powershell.exe"),"-NoProfile -ExecutionPolicy Bypass -File "+Q(Path.Combine(appRoot,"Scripts\\Worker.ps1"))+" -Mode "+requested+" -RunRoot "+Q(runRoot)+" -CameraSide "+(requested=="Diagnose"?selectedSide:"both")+" -CaptureSeconds "+(requested=="Diagnose"?"15":"8")+" -ResumeUserSid "+System.Security.Principal.WindowsIdentity.GetCurrent().User.Value);
   psi.WorkingDirectory=appRoot;psi.WindowStyle=ProcessWindowStyle.Hidden;psi.UseShellExecute=requested!="Scan";psi.CreateNoWindow=requested=="Scan";if(requested!="Scan")psi.Verb="runas";
   if(requested!="Scan")psi.Arguments+=" -PreviewMap "+Q(previewName);if(livePreview){previewStop=new EventWaitHandle(false,EventResetMode.ManualReset,previewName+"-stop");psi.Arguments+=" -LivePreview -PreviewStopEvent "+Q(previewName+"-stop")+" -PreviewOwnerPid "+Process.GetCurrentProcess().Id;SetText(selectedSide=="rear"?rearError:frontError,"Запуск камеры…");(selectedSide=="rear"?rearError:frontError).Visible=true;}worker=Process.Start(psi);var retainedHandle=worker.Handle;GC.Collect();EmptyWorkingSet(Process.GetCurrentProcess().Handle);
  }catch(Exception ex){SetBusy(false);ClosePreview();SetText(status,"Запуск не выполнен");SetText(detail,ex.Message);log.Text=ex.ToString();}
 }
 Dictionary<string,object> ReadJson(string path){try {if(!File.Exists(path))return null;using(var file=new FileStream(path,FileMode.Open,FileAccess.Read,FileShare.ReadWrite|FileShare.Delete))using(var reader=new StreamReader(file,Encoding.UTF8))return json.Deserialize<Dictionary<string,object>>(reader.ReadToEnd());}catch(IOException){return null;}catch(ArgumentException){return null;}}
 string ReadShared(string path){try{using(var f=new FileStream(path,FileMode.Open,FileAccess.Read,FileShare.ReadWrite|FileShare.Delete))using(var r=new StreamReader(f,Encoding.UTF8))return r.ReadToEnd();}catch(IOException){return "";}}
 void Poll() {
  if(string.IsNullOrEmpty(runRoot))return;var r=ReadJson(Path.Combine(runRoot,"app-result.json"));if(r!=null){result=r;int pct;if(int.TryParse(S(r,"progress"),out pct))progress.Value=busy?Math.Max(progress.Value,Math.Min(99,pct)):pct;string s=S(r,"status");if(s!=lastStatus){lastStatus=s;if(busy){SetText(status,Friendly(s));SetText(detail,S(r,"message"));}}}
  if(string.IsNullOrEmpty(engineRoot)) {string root=Path.Combine(runRoot,"Engine");if(Directory.Exists(root)){var dirs=Directory.GetDirectories(root);if(dirs.Length==1)engineRoot=dirs[0];}}
  if(!string.IsNullOrEmpty(engineRoot)) {
   var state=ReadJson(Path.Combine(engineRoot,"result.json"));if(state!=null&&busy){int pct;if(int.TryParse(S(state,"progress"),out pct))progress.Value=Math.Max(progress.Value,Math.Min(99,15+CameraProgress(state,pct)*85/100));string pending=S(state,"pendingKind");SetText(detail,Stage(state)+" · Прошло "+operationTime.Elapsed.ToString(@"mm\:ss"));if(pending.StartsWith("verify-front"))ShowCamera("front");else if(pending.StartsWith("verify-rear"))ShowCamera("rear");if(B(state,"rebootRequired"))SetText(status,"Подготовка перезагрузки");foreach(var c in Rows(V(state,"captures")))verifiedSides.Add(S(c,"side"));}
   foreach(string side in new[]{"rear","front"}) {
    var candidates=Directory.GetDirectories(engineRoot,"verify-"+side+"*").OrderByDescending(d=>d).ToArray();if(candidates.Length==0)continue;string dir=candidates[0],image=Path.Combine(dir,"live.bmp");
    previewDirs[side=="rear"?0:1]=dir;if(previewState!=1)LoadImage(image,side=="rear"?rear:front);var label=side=="rear"?rearLabel:frontLabel;string title=side=="rear"?"Задняя камера":"Фронтальная камера";
    string probe=ReadShared(Path.Combine(engineRoot,Path.GetFileName(dir)+"-probe.out.log"));var match=Regex.Match(probe,@"RESULT256 hr=(\w+) frames=(\d+).*width=(\d+) height=(\d+)");
    var metrics=ReadJson(Path.Combine(dir,"metrics.json"));if(previewState==1&&displayedSide==side)continue;if(metrics!=null)SetText(label,title+" · "+S(metrics,"fps")+" FPS · "+S(metrics,"frames")+" кадров · "+S(metrics,"width")+"×"+S(metrics,"height")+(verifiedSides.Contains(side)?" · OK":""));
    else if(match.Success)SetText(label,title+" · "+match.Groups[2].Value+" кадров · "+match.Groups[3].Value+"×"+match.Groups[4].Value);
    else if(File.Exists(image))SetText(label,title+" · тест идёт, живое изображение");
   }
  }
  string content=ReadShared(Path.Combine(engineRoot,"setup.log"));if(content.Length==0)content=ReadShared(Path.Combine(runRoot,"engine.out.log"));if(content.Length>16000)content=content.Substring(content.Length-16000);content=Tr(content);if(content.Length>0&&content!=log.Text){log.Text=content;log.SelectionStart=log.TextLength;log.ScrollToCaret();}
 }
 void ClosePreview(){if(previewStop!=null){previewStop.Dispose();previewStop=null;}if(previewView!=null){previewView.Dispose();previewView=null;}if(previewMap!=null){previewMap.Dispose();previewMap=null;}previewName="";previewSequence=-1;previewState=0;previewElapsed=0;previewBytes=null;}
 void ReadPreview(){
  if(previewView==null)return;int seq=previewView.ReadInt32(0);if((seq&1)!=0||seq==previewSequence||previewView.ReadInt32(4)!=0x51323533)return;
  Thread.MemoryBarrier();int w=previewView.ReadInt32(8),h=previewView.ReadInt32(12),frames=previewView.ReadInt32(16),cw=previewView.ReadInt32(20),ch=previewView.ReadInt32(24),state=previewView.ReadInt32(28),side=previewView.ReadInt32(52);
  double fps=previewView.ReadDouble(32),elapsed=previewView.ReadDouble(40);if(w<=0||h<=0||w>960||h>540||side<0||side>1)return;
  int size=w*h*4;if(previewBytes==null||previewBytes.Length!=size)previewBytes=new byte[size];previewView.ReadArray(64,previewBytes,0,size);Thread.MemoryBarrier();if(previewView.ReadInt32(0)!=seq)return;
  previewSequence=seq;previewState=state;previewElapsed=elapsed;var box=side==0?rear:front;var bitmap=box.Image as Bitmap;
  if(state==1){(side==0?rearError:frontError).Visible=false;if(livePreview&&!stoppingPreview)SetText(status,"Камера включена");}
  if(state==1){long tick=Stopwatch.GetTimestamp();if(firstDisplay[side]==0)firstDisplay[side]=tick;lastDisplay[side]=tick;displayedFrames[side]++;}
  if(bitmap==null||bitmap.Width!=w||bitmap.Height!=h){bitmap=new Bitmap(w,h,PixelFormat.Format32bppRgb);var old=box.Image;box.Image=bitmap;if(old!=null)old.Dispose();FitImage(box);}
  var data=bitmap.LockBits(new Rectangle(0,0,w,h),ImageLockMode.WriteOnly,PixelFormat.Format32bppRgb);try{Marshal.Copy(previewBytes,0,data.Scan0,size);}finally{bitmap.UnlockBits(data);}box.Invalidate();
  if(state==1)SetText(side==0?rearLabel:frontLabel,(side==0?"Задняя камера":"Фронтальная камера")+" · "+fps.ToString("0.00",System.Globalization.CultureInfo.InvariantCulture)+" FPS · "+frames+" кадров · "+cw+"×"+ch);
 }
 void LoadImage(string path,PictureBox box) {try{if(!File.Exists(path))return;DateTime time=File.GetLastWriteTimeUtc(path);DateTime oldTime;if(imageTimes.TryGetValue(path,out oldTime)&&oldTime==time)return;byte[] bytes;using(var f=new FileStream(path,FileMode.Open,FileAccess.Read,FileShare.ReadWrite|FileShare.Delete)){bytes=new byte[f.Length];int n=0;while(n<bytes.Length){int read=f.Read(bytes,n,bytes.Length-n);if(read==0)return;n+=read;}}using(var ms=new MemoryStream(bytes))using(var im=Image.FromStream(ms)){var copy=new Bitmap(im);var old=box.Image;box.Image=copy;if(old!=null)old.Dispose();}FitImage(box);(box==rear?rearError:frontError).Visible=false;imageTimes[path]=time;}catch(IOException){}catch(ArgumentException){}}
 string Friendly(string state){if(state=="SCAN_COMPLETE")return "Устройства проверены";if(state=="RUNNING"||state=="PREPARING")return mode=="Install"?"Установка…":mode=="Diagnose"?(livePreview?"Запуск камеры…":"Проверка камеры"):"Проверка устройств";if(state.StartsWith("PASS"))return "Обе камеры работают";if(state.StartsWith("PENDING"))return "Нужна перезагрузка";if(state=="ERROR"||state=="RECOVERY_STOPPED"||state.StartsWith("FAILED")||state.StartsWith("INSTALLED253_VERIFICATION_INCOMPLETE"))return "Нужно исправление";return "Проверка конфигурации";}
 int CameraProgress(Dictionary<string,object> state,int baseline){if(baseline!=65&&baseline!=80)return baseline;int span=mode=="Diagnose"&&selectedSide!="both"?30:15;string phase=S(state,"captureStage");if(phase=="Capturing"&&previewState==1)return livePreview?baseline:baseline+(int)(span*0.6*Math.Min(1,previewElapsed/(mode=="Diagnose"?15000:8000)));if(phase=="Retiring")return baseline+(int)(span*0.65);if(phase=="Decoding")return baseline+(int)(span*0.8);return baseline;}
 string Stage(Dictionary<string,object> state){string pending=S(state,"pendingKind"),phase=S(state,"captureStage");if(pending.Contains("enumerate"))return "Определение физических камер по идентификаторам";if(pending.Contains("probe")){if(previewState==1&&livePreview)return "Живой поток камеры";if(previewState==1)return "Захват кадров · "+Math.Min(mode=="Diagnose"?15:8,(int)(previewElapsed/1000))+" / "+(mode=="Diagnose"?15:8)+" s";if(previewState>=2)return "Закрытие камеры · Изображение остановлено. Проверка продолжается.";return "Подготовка камеры";}if(phase=="Decoding"||pending.Contains("decode")||pending.Contains("close"))return "Проверка журналов драйвера";if(phase=="Retiring")return "Ожидание завершения службы камеры · Изображение остановлено. Проверка продолжается.";if(pending.Contains("bind"))return "Установка камерного драйвера: "+pending;if(pending.Contains("backup"))return "Сохранение резервной копии текущих камерных драйверов";return pending.Length>0?pending:S(state,"phase").Length>0?S(state,"phase"):"Проверка файлов, устройств и конфигурации";}
 void Finished(int code) {
  Poll();SetBusy(false);if(worker!=null){worker.Dispose();worker=null;}
  if(displayedFrames.Sum()>0){var previewReport=new List<object>();for(int side=0;side<2;side++)if(displayedFrames[side]>0)previewReport.Add(new{side=side==0?"rear":"front",framesDisplayed=displayedFrames[side],fps=lastDisplay[side]>firstDisplay[side]?(displayedFrames[side]-1)*(double)Stopwatch.Frequency/(lastDisplay[side]-firstDisplay[side]):0});File.WriteAllText(Path.Combine(runRoot,"ui-preview.json"),json.Serialize(previewReport));}
  if(result==null){install.Visible=false;status.Visible=true;SetText(status,"Нет результата");SetText(detail,"Процесс завершился с кодом "+code+". Откройте журналы.");return;}
  devices.Rows.Clear();foreach(var row in Rows(V(result,"devices"))){string problem=S(row,"problem");bool oldGpu=problem=="22"&&S(row,"id").StartsWith("ROOT\\CAMERA\\",StringComparison.OrdinalIgnoreCase);int index=devices.Rows.Add(S(row,"name"),problem=="0"?"OK":oldGpu?Tr("Старая виртуальная камера отключена"):"Код "+problem,S(row,"version"),S(row,"id"));if(problem!="0")devices.Rows[index].DefaultCellStyle.ForeColor=oldGpu?Color.FromArgb(99,114,136):Color.FromArgb(190,60,40);}
  SetText(status,Friendly(S(result,"status")));SetText(detail,S(result,"message"));
  if(mode=="Scan") {
   install.Visible=true;
   if(code!=0||S(result,"status")!="SCAN_COMPLETE"){install.Visible=false;status.Visible=true;install.Enabled=false;log.Text=Tr(string.Join(Environment.NewLine,Rows(V(result,"checks")).Select(c=>(B(c,"ok")?"[OK] ":"[!] ")+S(c,"name")+": "+S(c,"detail")))+Environment.NewLine+S(result,"message"));return;}
   var checks=Rows(V(result,"checks")).ToArray();log.Text=Tr(string.Join(Environment.NewLine,checks.Select(c=>(B(c,"ok")?"[OK] ":"[!] ")+S(c,"name")+": "+S(c,"detail"))));
   var installedPackage=D(V(result,"installedPackage"));installedCurrent=B(installedPackage,"installed")&&S(installedPackage,"state")=="CURRENT";installVerificationPending=installedCurrent&&B(installedPackage,"continuationRequired");
   log.AppendText(Environment.NewLine+"["+(installedCurrent?"OK":"!")+"] Installed package: "+S(installedPackage,"state")+" · "+S(installedPackage,"detail"));
   if(installedCurrent&&!installVerificationPending){install.Visible=false;status.ForeColor=Color.FromArgb(20,132,85);SetText(status,"Драйверы уже установлены");SetText(detail,"Установлен актуальный комплект Qualcomm ISP253. Повторная установка не требуется. Для проверки изображения откройте «Камеры».");progress.Value=100;resuming=false;ClearResume();if(pages.SelectedTab==cameraPage&&!busy)BeginPreview();return;}
   SetText(install,installVerificationPending?"Продолжить проверку":"Установить");
   var signing=checks.FirstOrDefault(c=>S(c,"name")=="Тестовый режим драйверов");if(signing==null||!B(signing,"ok")){install.Enabled=false;install.Visible=false;status.Visible=true;SetText(status,"Требуется Test Mode");SetText(detail,"Драйверы имеют тестовую подпись. Включите Test Mode, перезагрузите Windows и нажмите «Повторить проверку».");progress.Value=100;resuming=false;return;}
   if(checks.Any(c=>!B(c,"ok"))){var prereq=D(V(result,"prerequisites"));bool canRepair=B(prereq,"eligible")&&checks.Where(c=>!B(c,"ok")).All(c=>S(c,"name").StartsWith("Устройство ")||S(c,"name").StartsWith("Штатный компонент "));SetText(status,canRepair?"Восстановление базовых драйверов":"Есть условия для исправления");SetText(detail,canRepair?"Нажмите «Установить»: программа восстановит Qualcomm Camera Platform, JPEG и Flash, затем установит ISP253.":"Смотрите проверки ниже. После исправления повторите установку.");}
   else if(installVerificationPending){SetText(status,"Драйверы установлены · нужна проверка");SetText(detail,"Драйверы установлены. Повторная установка не требуется; проверка камер ещё не завершена. Нажмите «Продолжить проверку».");}
   else SetText(detail,S(installedPackage,"state")=="REPAIR_REQUIRED"?"Обнаружены старые или неполные драйверы. Нажмите «Установить», чтобы обновить или исправить комплект.":"Не удалось подтвердить установленный комплект. Подробности — в журналах.");
   if(B(installedPackage,"storageMigrationRequired"))SetText(detail,"Драйверы установлены. Нажмите «Продолжить проверку», чтобы сохранить данные камер в системной папке Windows и проверить камеры.");
   progress.Value=100;if(resuming){resuming=false;var host=D(V(result,"host"));if(S(host,"boot")==resumeBoot){SetText(status,"Нужна перезагрузка Windows");SetText(detail,"Сеанс ядра ещё не изменился. Перезапустите Windows обычной перезагрузкой.");}else Start("Install");}else if(pages.SelectedTab==cameraPage&&!busy)BeginPreview();return;
  }
  if(B(result,"rebootRequired")) {
   try{ArmResume();reboot.Visible=later.Visible=true;later.Enabled=true;SetText(status,"Нужна перезагрузка");var nativeVerification=D(V(result,"nativeVerification"));SetText(detail,B(result,"installedPackageVerified")&&S(nativeVerification,"evidence")=="MISSING_DRIVER_LOG_MARKERS"&&B(nativeVerification,"framesReceived")&&B(nativeVerification,"probeClosed")?S(result,"message"):"Продолжение сохранено. Нажмите «Перезагрузить систему». После входа установка и проверка камер продолжатся.");}
   catch(Exception ex){SetText(status,"Продолжение не сохранено");SetText(detail,ex.Message);log.AppendText(Environment.NewLine+ex.ToString());}return;
  }
  if(B(result,"autoResumeStopped"))ClearResume();if(code==0&&S(result,"status").StartsWith("PASS")&&Rows(V(result,"captures")).Count()==(mode=="Diagnose"&&selectedSide!="both"?1:2)){progress.Value=100;status.ForeColor=Color.FromArgb(20,132,85);ClearResume();SetText(status,mode=="Install"?"Установка завершена":"Тест завершён");SetText(detail,S(result,"message")+" · "+operationTime.Elapsed.ToString(@"mm\:ss"));foreach(var c in Rows(V(result,"captures"))){string side=S(c,"side");var label=side=="rear"?rearLabel:frontLabel;string source;if(textSources.TryGetValue(label,out source)&&!source.EndsWith(" · OK"))SetText(label,source+" · OK");}}
  else{status.ForeColor=Color.FromArgb(190,60,40);log.AppendText(Environment.NewLine+S(result,"message"));if(mode=="Diagnose"){var error=selectedSide=="rear"?rearError:frontError;SetText(error,CameraFailure(S(result,"message")+"\n"+string.Join("\n",Rows(V(result,"errors")).Select(c=>S(c,"message")))));error.Visible=true;error.BringToFront();}}
  var cleanup=D(V(result,"packageCleanup"));if(cleanup!=null&&S(cleanup,"status")!="COMPLETE")SetText(detail,S(result,"message")+" · "+(russian?"Windows сохранила используемые пакеты; см. журналы.":"Windows retained in-use packages; see Logs."));
  if(livePreview){bool ok=code==0&&S(result,"status").StartsWith("PASS");livePreview=false;stoppingPreview=false;SetText(test,"Запустить камеру");if(ok)SetText(status,"Поток камеры остановлен");string queued=nextCamera;nextCamera="";if(closeAfterPreview){closeAfterPreview=false;Close();}else if(ok&&queued.Length>0&&pages.SelectedTab==cameraPage){cameraChoice.SelectedIndex=queued=="front"?1:0;BeginPreview();}}
 }
 string CameraFailure(string message){string code=Regex.Match(message,@"(?i)(?:hr=|0x)([0-9a-f]{8})").Groups[1].Value;string heading=russian?"Не удалось запустить камеру":"Couldn't start your camera";if(code.Equals("80070005",StringComparison.OrdinalIgnoreCase))heading=russian?"Нет доступа к камере. Проверьте разрешения Windows.":"Camera access was denied. Check Windows camera permissions.";else if(code.Equals("c00d36d5",StringComparison.OrdinalIgnoreCase)||message.IndexOf("not exposed",StringComparison.OrdinalIgnoreCase)>=0)heading=russian?"Не удаётся найти камеру":"We can't find your camera";else if(code.Equals("800700aa",StringComparison.OrdinalIgnoreCase)||code.Equals("c00d3704",StringComparison.OrdinalIgnoreCase))heading=russian?"Камеру использует другое приложение":"Another app is using your camera";return heading+"\n\n"+(code.Length>0?"0x"+code.ToUpperInvariant()+"\n\n":"")+Tr(message);}
 void ArmResume() {
  string exe=S(result,"resumeExe");string allowed=Path.Combine(appRoot,"xiaomi-pad5-windows11-camera.exe");if(!string.Equals(exe,allowed,StringComparison.OrdinalIgnoreCase)||!File.Exists(exe))throw new IOException("Не найден сохранённый комплект для продолжения");
  if(string.IsNullOrEmpty(S(result,"resumeTask")))throw new IOException("The logon resume task was not saved. Check the installation log.");Directory.CreateDirectory(dataRoot);rebootCycles++;var host=D(V(result,"host"));resumeBoot=S(host,"boot");File.WriteAllText(Path.Combine(dataRoot,"resume.json"),json.Serialize(new Dictionary<string,object>{{"boot",resumeBoot},{"cycles",rebootCycles},{"runRoot",runRoot},{"exe",exe}}),Encoding.UTF8);
  using(var key=Registry.CurrentUser.CreateSubKey("Software\\Microsoft\\Windows\\CurrentVersion\\RunOnce"))key.SetValue("xiaomi-pad5-windows11-camera",Q(exe)+" --resume",RegistryValueKind.String);
 }
 void ReadResume(){var r=ReadJson(Path.Combine(dataRoot,"resume.json"));if(r==null){resuming=false;return;}resumeBoot=S(r,"boot");int.TryParse(S(r,"cycles"),out rebootCycles);}
 void ClearResume(){using(var key=Registry.CurrentUser.OpenSubKey("Software\\Microsoft\\Windows\\CurrentVersion\\RunOnce",true)){if(key!=null)key.DeleteValue("xiaomi-pad5-windows11-camera",false);}string path=Path.Combine(dataRoot,"resume.json");if(File.Exists(path))File.Delete(path);rebootCycles=0;}
 void RestartNow(){if(busy)return;try{var psi=new ProcessStartInfo(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Windows),"System32\\shutdown.exe"),"/r /t 0 /d p:2:4 /c \"xiaomi-pad5-windows11-camera: продолжение установки камер\""){UseShellExecute=false,CreateNoWindow=true};using(var p=Process.Start(psi)){p.WaitForExit();if(p.ExitCode!=0)throw new IOException("Windows не выполнила запрос перезагрузки. Перезагрузите через меню Пуск.");}SetText(status,"Перезагрузка Windows");Close();}catch(Exception ex){SetText(detail,ex.Message);}}
 void Export(){if(!Directory.Exists(runRoot))return;using(var dialog=new SaveFileDialog {Title="Сохранить отчёт без изображений",Filter="ZIP отчёт|*.zip",FileName="xiaomi-pad5-windows11-camera-Report-"+DateTime.Now.ToString("yyyyMMdd-HHmmss")+".zip"})if(dialog.ShowDialog(this)==DialogResult.OK){try{using(var zip=ZipFile.Open(dialog.FileName,ZipArchiveMode.Create)){foreach(string file in Directory.GetFiles(runRoot,"*",SearchOption.AllDirectories)){string name=Path.GetFileName(file),ext=Path.GetExtension(file).ToLowerInvariant();if(name.StartsWith("preview.")||name=="live.bmp"||name=="live.tmp"||ext==".etl"||ext==".jsonl")continue;zip.CreateEntryFromFile(file,file.Substring(runRoot.Length+1),CompressionLevel.Optimal);}}MessageBox.Show(this,"Отчёт сохранён. Изображения камер в ZIP не включены.","Готово");}catch(Exception ex){MessageBox.Show(this,ex.Message,"Не удалось сохранить отчёт");}}}
}
