﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Imaging;
using System.Linq;
using System.Runtime.InteropServices;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Win32;
using Windows.Devices.Enumeration;
using Windows.Foundation;
using Windows.Graphics.Imaging;
using Windows.Media.Capture;
using Windows.Media.Capture.Frames;
using Windows.Storage.Streams;

namespace XiaomiPad5 {
 public static class PreviewBoot {
  [DllImport("ntdll.dll")] static extern int NtQuerySystemInformation(int kind,IntPtr data,int size,out int returned);
  public static string Read(){IntPtr data=Marshal.AllocHGlobal(32);try{int returned;int code=NtQuerySystemInformation(90,data,32,out returned);if(code!=0)throw new InvalidOperationException("Cannot read kernel boot identity: "+code.ToString("X8"));byte[] bytes=new byte[16];Marshal.Copy(data,bytes,0,16);using(var key=Registry.LocalMachine.OpenSubKey(@"SYSTEM\CurrentControlSet\Control\Session Manager\Memory Management\PrefetchParameters")){return new Guid(bytes).ToString()+":"+(key==null?"":Convert.ToString(key.GetValue("BootId","")));}}finally{Marshal.FreeHGlobal(data);}}
 }
}

sealed class LiveFrameInfo {
 public long Sequence,Frames,Timestamp;public int Width,Height,PreviewWidth,PreviewHeight;
 public double Fps,NominalFps,Brightness;public string Format,Side;public bool HasImage;
}
sealed class CameraMeasurement {
 readonly long firstFrames,firstTimestamp;readonly Stopwatch clock=Stopwatch.StartNew();
 public CameraMeasurement(LiveFrameInfo frame){firstFrames=frame.Frames;firstTimestamp=frame.Timestamp;}
 public double Elapsed{get{return clock.Elapsed.TotalSeconds;}}
 public long Frames(LiveFrameInfo frame){return Math.Max(0,frame.Frames-firstFrames);}
 public double Fps(LiveFrameInfo frame){double seconds=(frame.Timestamp-firstTimestamp)/10000000.0;return seconds>0?Frames(frame)/seconds:0;}
}
sealed class NativeLivePreview {
 readonly object sync=new object();readonly SemaphoreSlim lifetime=new SemaphoreSlim(1,1);
 MediaCapture capture;MediaFrameReader reader;bool started;volatile bool closing;
 byte[] pixels;Windows.Storage.Streams.Buffer buffer;long sequence,frames,lastStamp=-1,firstStamp=-1;
 int width,height,previewWidth,previewHeight;double nominal,brightness;string format="",side="";
 Exception frameError;int handlingFrame;readonly Stopwatch arrival=Stopwatch.StartNew();
 static Task<T> Await<T>(IAsyncOperation<T> operation){var completion=new TaskCompletionSource<T>();operation.Completed=(op,status)=>{try{completion.TrySetResult(op.GetResults());}catch(Exception e){completion.TrySetException(e);}};return completion.Task;}
 static Task Await(IAsyncAction operation){var completion=new TaskCompletionSource<bool>();operation.Completed=(op,status)=>{try{op.GetResults();completion.TrySetResult(true);}catch(Exception e){completion.TrySetException(e);}};return completion.Task;}
 public static DeviceInformation SelectDevice(IEnumerable<DeviceInformation> devices,string selectedSide){
  string guid=selectedSide=="front"?"{4FAEAFD4-041B-4E46-85FD-400473891182}":"{5584F823-3830-4CFD-947F-78DE17A8B14C}";
  var matches=devices.Where(d=>d.IsEnabled&&d.Id.IndexOf("DISPLAY#QCOM_AVStream_8150#",StringComparison.OrdinalIgnoreCase)>=0&&d.Id.EndsWith("\\"+guid,StringComparison.OrdinalIgnoreCase)).ToArray();
  if(matches.Length!=1)throw new InvalidOperationException("Expected one native "+selectedSide+" camera; found "+matches.Length);
  return matches[0];
 }
 public async Task StartAsync(string selectedSide){
  await lifetime.WaitAsync();
  try{
   if(capture!=null||reader!=null)throw new InvalidOperationException("The previous camera has not closed");
   side=selectedSide;closing=false;frameError=null;sequence=frames=0;lastStamp=firstStamp=-1;pixels=null;buffer=null;
   var devices=await Await(DeviceInformation.FindAllAsync(DeviceClass.VideoCapture));var device=SelectDevice(devices,selectedSide);
   capture=new MediaCapture();
   var settings=new MediaCaptureInitializationSettings{VideoDeviceId=device.Id,StreamingCaptureMode=StreamingCaptureMode.Video,MemoryPreference=MediaCaptureMemoryPreference.Cpu,SharingMode=MediaCaptureSharingMode.SharedReadOnly};
   await Await(capture.InitializeAsync(settings));
   var sources=capture.FrameSources.Values.Where(s=>s.Info.SourceKind==MediaFrameSourceKind.Color).ToArray();
   var source=sources.FirstOrDefault(s=>s.Info.MediaStreamType==Windows.Media.Capture.MediaStreamType.VideoPreview)??sources.FirstOrDefault();
   if(source==null||source.CurrentFormat==null||source.CurrentFormat.VideoFormat==null)throw new InvalidOperationException("No color preview source is available");
   var sourceFormat=source.CurrentFormat;width=(int)sourceFormat.VideoFormat.Width;height=(int)sourceFormat.VideoFormat.Height;format=sourceFormat.Subtype;
   nominal=sourceFormat.FrameRate.Denominator==0?0:sourceFormat.FrameRate.Numerator/(double)sourceFormat.FrameRate.Denominator;
   double scale=Math.Min(1,Math.Min(960.0/Math.Max(1,width),540.0/Math.Max(1,height)));
   uint outputWidth=(uint)Math.Max(2,((int)(width*scale)/2)*2),outputHeight=(uint)Math.Max(2,((int)(height*scale)/2)*2);
   reader=await Await(capture.CreateFrameReaderAsync(source,"BGRA8",new BitmapSize{Width=outputWidth,Height=outputHeight}));
   reader.AcquisitionMode=MediaFrameReaderAcquisitionMode.Realtime;reader.FrameArrived+=FrameArrived;
   var status=await Await(reader.StartAsync());if(status!=MediaFrameReaderStartStatus.Success)throw new InvalidOperationException("Camera reader start: "+status);
   started=true;arrival.Restart();
  }finally{lifetime.Release();}
 }
 void FrameArrived(MediaFrameReader sender,MediaFrameArrivedEventArgs args){
  if(closing||Interlocked.Exchange(ref handlingFrame,1)!=0)return;
  try{
   using(var frame=sender.TryAcquireLatestFrame()){
    if(frame==null||frame.VideoMediaFrame==null)return;
    using(var image=frame.VideoMediaFrame.SoftwareBitmap){
     if(image==null)return;
     var time=frame.SystemRelativeTime;long stamp=time.HasValue?time.Value.Ticks:(long)(Stopwatch.GetTimestamp()*(10000000.0/Stopwatch.Frequency));
     lock(sync){
      if(stamp==lastStamp)return;
      if(image.BitmapPixelFormat!=BitmapPixelFormat.Bgra8)throw new InvalidOperationException("Expected BGRA8 preview frames");
      int w=image.PixelWidth,h=image.PixelHeight,bytes=checked(w*h*4);
      if(w>960||h>540||w<1||h<1)throw new InvalidOperationException("Unexpected preview dimensions");
      if(pixels==null||pixels.Length!=bytes){pixels=new byte[bytes];buffer=new Windows.Storage.Streams.Buffer((uint)bytes);}
      image.CopyToBuffer(buffer);using(var data=DataReader.FromBuffer(buffer))data.ReadBytes(pixels);
      double total=0;int samples=0;for(int y=0;y<h;y+=16)for(int x=0;x<w;x+=16){int p=(y*w+x)*4;total+=(29*pixels[p]+150*pixels[p+1]+77*pixels[p+2]+128)/256;samples++;}
      brightness=samples==0?0:total/samples;previewWidth=w;previewHeight=h;
      if(firstStamp<0)firstStamp=stamp;lastStamp=stamp;frames++;sequence++;arrival.Restart();
     }
    }
   }
  }catch(Exception e){lock(sync)frameError=e;}finally{Interlocked.Exchange(ref handlingFrame,0);}
 }
 public LiveFrameInfo Snapshot(){lock(sync){if(frameError!=null)throw frameError;return new LiveFrameInfo{Sequence=sequence,Frames=frames,Timestamp=lastStamp,Width=width,Height=height,PreviewWidth=previewWidth,PreviewHeight=previewHeight,Format=format,Side=side,NominalFps=nominal,Brightness=brightness,HasImage=pixels!=null,Fps=frames>1&&lastStamp>firstStamp?(frames-1)*10000000.0/(lastStamp-firstStamp):0};}}
 public double SecondsSinceFrame{get{lock(sync)return arrival.Elapsed.TotalSeconds;}}
 public void Render(Bitmap bitmap){lock(sync){if(pixels==null||bitmap.Width!=previewWidth||bitmap.Height!=previewHeight)return;var data=bitmap.LockBits(new Rectangle(0,0,previewWidth,previewHeight),ImageLockMode.WriteOnly,PixelFormat.Format32bppRgb);try{if(data.Stride!=previewWidth*4)throw new InvalidOperationException("Unexpected preview stride");Marshal.Copy(pixels,0,data.Scan0,pixels.Length);}finally{bitmap.UnlockBits(data);}}}
 public async Task StopAsync(){
  await lifetime.WaitAsync();Exception failure=null;
  try{
   closing=true;
   if(reader!=null){reader.FrameArrived-=FrameArrived;try{if(started)await Await(reader.StopAsync());}catch(Exception e){failure=e;}try{reader.Dispose();}catch(Exception e){failure=failure??e;}reader=null;started=false;}
   if(capture!=null){try{capture.Dispose();}catch(Exception e){failure=failure??e;}capture=null;}
   lock(sync){pixels=null;buffer=null;}
  }finally{lifetime.Release();}
  if(failure!=null)throw new InvalidOperationException("Camera closure was not confirmed",failure);
 }
}
