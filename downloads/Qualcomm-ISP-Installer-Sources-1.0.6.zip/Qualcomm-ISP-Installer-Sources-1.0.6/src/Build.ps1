﻿param([string]$Ewdk='H:\Vlad\EWDK',[switch]$SkipNative)
$ErrorActionPreference='Stop'
$project=Split-Path -Parent $PSScriptRoot
New-Item -ItemType Directory -Path (Join-Path $project 'work') -Force|Out-Null
if(-not $SkipNative){
$vc=Join-Path $Ewdk 'Program Files\Microsoft Visual Studio\2022\BuildTools\VC\Tools\MSVC\14.44.35207'
$sdk=Join-Path $Ewdk 'Program Files\Windows Kits\10';$version='10.0.26100.0'
$args=@('/nologo','/std:c++17','/EHsc','/O2','/MT','/DWIN32_LEAN_AND_MEAN',('/I'+$vc+'\include'))
foreach($include in 'ucrt','shared','um','winrt','cppwinrt'){$args+=('/I'+$sdk+'\Include\'+$version+'\'+$include)}
$args+=@((Join-Path $PSScriptRoot 'CameraProbe.cpp'),('/Fo'+$project+'\work\CameraProbe.obj'),('/Fe'+$project+'\release\Driver\Tools\CameraProbe256.exe'),'/link',('/LIBPATH:'+$vc+'\lib\arm64'),('/LIBPATH:'+$sdk+'\Lib\'+$version+'\um\arm64'),('/LIBPATH:'+$sdk+'\Lib\'+$version+'\ucrt\arm64'),'windowsapp.lib')
 & (Join-Path $vc 'bin\Hostarm64\arm64\cl.exe') @args
 if($LASTEXITCODE -ne 0){throw 'Native ARM64 probe compilation failed'}
}
Copy-Item -LiteralPath (Join-Path $PSScriptRoot 'Worker.ps1') -Destination (Join-Path $project 'release\Scripts\Worker.ps1') -Force
foreach($path in @((Join-Path $project 'release\Scripts\Worker.ps1'),(Join-Path $project 'release\Driver\Setup.ps1'))){[IO.File]::WriteAllText($path,[IO.File]::ReadAllText($path),[Text.UTF8Encoding]::new($true))}
. (Join-Path $PSScriptRoot 'WinRT-References.ps1')
$appArgs=@('/nologo','/target:winexe','/platform:anycpu','/optimize+','/reference:System.Core.dll','/reference:System.Windows.Forms.dll','/reference:System.Drawing.dll','/reference:System.Web.Extensions.dll','/reference:System.Management.dll','/reference:System.IO.Compression.dll','/reference:System.IO.Compression.FileSystem.dll',('/win32manifest:'+(Join-Path $PSScriptRoot 'app.manifest')),('/out:'+(Join-Path $project 'release\xiaomi-pad5-windows11-camera.exe')))+(Get-CameraWinRTReferences)+@((Join-Path $PSScriptRoot 'App.cs'),(Join-Path $PSScriptRoot 'BootSecurity.cs'),(Join-Path $PSScriptRoot 'NativePreview.cs'))
& "$env:windir\Microsoft.NET\Framework64\v4.0.30319\csc.exe" @appArgs
if($LASTEXITCODE -ne 0){throw 'Application compilation failed'}
$driver=Join-Path $project 'release\Driver';$manifestPath=Join-Path $driver 'MANIFEST-SHA256.json'
Copy-Item -LiteralPath (Join-Path $PSScriptRoot 'BootSecurity.cs') -Destination (Join-Path $driver 'Tools\BootSecurity.cs') -Force
$manifest=Get-Content -LiteralPath $manifestPath -Raw|ConvertFrom-Json
$manifest.installerRevision='Desktop 1.0.6 / R27';$manifest.payloadId='sk1-qisp253-20261106'
$manifest.files=@(Get-ChildItem -LiteralPath $driver -Recurse -File|Where-Object {$_.Name -ne 'MANIFEST-SHA256.json'}|ForEach-Object {[pscustomobject]@{path=$_.FullName.Substring($driver.Length+1).Replace('\','/');bytes=$_.Length;sha256=(Get-FileHash -LiteralPath $_.FullName).Hash.ToLowerInvariant()}})
$manifest|ConvertTo-Json -Depth 8|Set-Content -LiteralPath $manifestPath -Encoding UTF8
$release=Join-Path $project 'release'
$files=@(Get-ChildItem -LiteralPath $release -File -Recurse|Where-Object {$_.Name -ne 'APP-SHA256.json'}|ForEach-Object {[ordered]@{path=$_.FullName.Substring($release.Length+1).Replace('\','/');bytes=$_.Length;sha256=(Get-FileHash -LiteralPath $_.FullName).Hash.ToLowerInvariant()}})
[ordered]@{version='1.0.6';driver='QISP253 / SYS080 / MFT075b';files=$files}|ConvertTo-Json -Depth 5|Set-Content -LiteralPath (Join-Path $release 'APP-SHA256.json') -Encoding UTF8
