$ErrorActionPreference='Stop';Set-StrictMode -Version Latest
$driver=Join-Path (Split-Path -Parent $PSScriptRoot) 'release\Driver'
. (Join-Path $driver 'Tools\StandaloneResume.ps1')
. (Join-Path $driver 'Tools\CameraPackages.ps1')
$passed=[Collections.Generic.List[string]]::new()
function Assert([bool]$Ok,[string]$Name){if(-not $Ok){throw ('FAIL '+$Name)};$passed.Add($Name)}
$p=Get-StandaloneRecoveryPlan $null 'PENDING_A' 'boot1';Assert ($p.restartRequests -eq 1 -and -not $p.stop) 'First pending restart permits continuation'
$s=[pscustomobject]@{boot='boot1';pendingStatus='PENDING_A';restartRequests=1;sameStageRequests=1}
$p=Get-StandaloneRecoveryPlan $s 'PENDING_A' 'boot1';Assert ($p.restartRequests -eq 1 -and $p.sameStageRequests -eq 1) 'Retrying without restarting does not add a reboot attempt'
$p=Get-StandaloneRecoveryPlan $s 'PENDING_A' 'boot2';Assert ($p.sameStageRequests -eq 2 -and -not $p.stop) 'One retry in a new boot remains available'
$s.boot='boot2';$s.restartRequests=2;$s.sameStageRequests=2
$p=Get-StandaloneRecoveryPlan $s 'PENDING_A' 'boot3';Assert $p.stop 'Repeated identical restart stages stop instead of looping'
$p=Get-StandaloneRecoveryPlan $s 'PENDING_B' 'boot3';Assert (-not $p.stop -and $p.sameStageRequests -eq 1) 'New installation progress starts its own stage counter'
$s.restartRequests=3;$s.boot='boot3';$s.pendingStatus='PENDING_B'
$p=Get-StandaloneRecoveryPlan $s 'PENDING_C' 'boot4';Assert $p.stop 'Standalone recovery has a three restart ceiling'
$nodes=@([pscustomobject]@{id='ACPI\QCOM0506\old';hardware=@('ACPI\QCOM0506')},[pscustomobject]@{id='ACPI\QCOM0506\new';hardware=@('ACPI\QCOM0506')},[pscustomobject]@{id='ACPI\QCOM0535\old';hardware=@('ACPI\QCOM0535')},[pscustomobject]@{id='USB\VID_0001\old';hardware=@('ACPI\QCOM0506')},[pscustomobject]@{id='ROOT\CAMERA\old';hardware=@('ROOT\NABUCAMVIRTUALFRONT')},[pscustomobject]@{id='ROOT\CAMERA\usb';hardware=@('USB\VID_0001')})
$stale=@(Select-StaleCameraDevices $nodes @('ACPI\QCOM0506\new'))
Assert ($stale.Count -eq 2 -and $stale.id -contains 'ACPI\QCOM0506\old' -and $stale.id -contains 'ROOT\CAMERA\old') 'Cleanup selects only disconnected native/known virtual camera nodes'
Assert (-not(Test-CameraOnlyHardwareId 'ACPI\QCOM0535') -and -not(Test-CameraOnlyHardwareId 'USB\VID_0001')) 'Platform and other devices cannot enter camera-only package removal'
$sid=[Security.Principal.WindowsIdentity]::GetCurrent().User.Value;$root='H:\Vlad\Camera test folder';$args=Get-StandaloneResumeArguments $root $sid
Assert ($args.Contains(' -File "H:\Vlad\Camera test folder\Install-QualcommISP.ps1"') -and $args.Contains(' -Resume ')) 'Resume preserves paths with spaces and targets PowerShell installer'
foreach($path in @((Join-Path $driver 'Install-QualcommISP.ps1'),(Join-Path $driver 'Tools\StandaloneResume.ps1'),(Join-Path $driver 'Tools\CameraSigning.ps1'))){$tokens=$null;$errors=$null;[void][Management.Automation.Language.Parser]::ParseFile($path,[ref]$tokens,[ref]$errors);Assert ($errors.Count -eq 0) ('Windows PowerShell parse: '+(Split-Path -Leaf $path))}
[ordered]@{status='PASS';count=$passed.Count;tests=$passed;driverChanged=$false;tasksRegistered=$false;actualReboot=$false}|ConvertTo-Json -Depth 5|Set-Content -LiteralPath (Join-Path $PSScriptRoot 'standalone-resume-results.json') -Encoding UTF8
Write-Output ('PASS_STANDALONE_RESUME count='+$passed.Count)
