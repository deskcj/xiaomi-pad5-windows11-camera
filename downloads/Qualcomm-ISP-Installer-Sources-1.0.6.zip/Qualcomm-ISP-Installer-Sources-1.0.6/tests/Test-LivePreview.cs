using System;
using System.Reflection;
class LivePreviewTests {
 static int count;
 static void Check(bool ok,string label){if(!ok)throw new Exception(label);count++;Console.WriteLine("OK "+label);}
 static void Main(){
  var baseline=new LiveFrameInfo{Frames=120,Timestamp=50000000};var measurement=new CameraMeasurement(baseline);
  var current=new LiveFrameInfo{Frames=360,Timestamp=150000000};
  Check(measurement.Frames(current)==240,"Measurement excludes frames received before Test");
  Check(Math.Abs(measurement.Fps(current)-24)<0.00001,"FPS uses unique source frames and source timestamps");
  Check(measurement.Fps(baseline)==0,"An unchanged frame never creates a false FPS result");
  Check(measurement.Fps(new LiveFrameInfo{Frames=130,Timestamp=50000000})==0,"Missing source time does not divide by zero");
  Check(measurement.Frames(new LiveFrameInfo{Frames=0,Timestamp=50000000})==0,"Counter reset cannot produce a negative frame result");
  var preview=new NativeLivePreview();Check(!preview.Snapshot().HasImage&&preview.Snapshot().Frames==0,"An unopened camera is not reported as working");
  typeof(NativeLivePreview).GetField("frames",BindingFlags.NonPublic|BindingFlags.Instance).SetValue(preview,241L);
  typeof(NativeLivePreview).GetField("firstStamp",BindingFlags.NonPublic|BindingFlags.Instance).SetValue(preview,50000000L);
  typeof(NativeLivePreview).GetField("lastStamp",BindingFlags.NonPublic|BindingFlags.Instance).SetValue(preview,150000000L);
  Check(Math.Abs(preview.Snapshot().Fps-24)<0.00001,"Preview FPS excludes the first timestamp interval");
  bool rejected=false;try{NativeLivePreview.SelectDevice(new Windows.Devices.Enumeration.DeviceInformation[0],"rear");}catch(InvalidOperationException){rejected=true;}Check(rejected,"A missing physical camera fails rather than opening another interface");
  preview.StopAsync().GetAwaiter().GetResult();preview.StopAsync().GetAwaiter().GetResult();Check(true,"Stopping an unopened or already closed preview is safe");
  Console.WriteLine("PASS_LIVE_METRICS count="+count);
 }
}
