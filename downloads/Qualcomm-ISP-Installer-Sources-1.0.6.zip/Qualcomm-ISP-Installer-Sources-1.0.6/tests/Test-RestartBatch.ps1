﻿$ErrorActionPreference='Stop';Set-StrictMode -Version Latest
$project=Split-Path -Parent $PSScriptRoot;$path=Join-Path $project 'release\Driver\Setup.ps1'
$tokens=$null;$errors=$null;$ast=[Management.Automation.Language.Parser]::ParseFile($path,[ref]$tokens,[ref]$errors)
if($errors.Count){throw ($errors|Out-String)}
$node=$ast.FindAll({param($n)$n -is [Management.Automation.Language.FunctionDefinitionAst] -and $n.Name -eq 'Run-Child'},$true)[0]
. ([scriptblock]::Create($node.Extent.Text))
$passed=[Collections.Generic.List[string]]::new()
function Assert([bool]$ok,[string]$name){if(-not $ok){throw ('FAIL '+$name)};$passed.Add($name)}
function Note([string]$message) {}
function Save-State {}
$run=Join-Path $project ('work\restart-batch-'+[guid]::NewGuid().ToString('N'));New-Item -ItemType Directory -Path $run|Out-Null
$r=[ordered]@{rebootRequired=$false;unsafeToContinue=$false;pendingPid=0;pendingCreation='';pendingKind=''}
$script:mockCode=1;$script:calls=0
function Start-Process {
 param($FilePath,$ArgumentList,$WindowStyle,$RedirectStandardOutput,$RedirectStandardError,[switch]$PassThru)
 $script:calls++;[IO.File]::WriteAllText($RedirectStandardOutput,'Mock successful device update requiring restart');[IO.File]::WriteAllText($RedirectStandardError,'')
 $p=[pscustomobject]@{Handle=[IntPtr]::Zero;Id=123;StartTime=[datetime]::Now;ExitCode=$script:mockCode}
 $p|Add-Member ScriptMethod WaitForExit {param($milliseconds) return $true}
 $p|Add-Member ScriptMethod Refresh {}
 return $p
}
foreach($slot in 'isp','mipi','avs','front','rear'){$null=Run-Child ('bind-'+$slot) 'devcon.exe' @('update','mock.inf','mock-hardware') 90000 -DeferRestart}
Assert ($script:calls -eq 5 -and $r.restartSteps.Count -eq 5 -and $r.rebootRequired -and -not $r.pendingPid -and -not $r.unsafeToContinue) 'Five successful restart-returning updates complete as one batch'
$caught=$false;try{$null=Run-Child 'capture-owner' 'devcon.exe' @() 90000}catch{$caught=$true}
Assert $caught 'Restart deferral is explicit; other device/capture operations still stop at a restart'
$script:mockCode=5;$caught=$false;try{$null=Run-Child 'failed-binding' 'devcon.exe' @() 90000 -DeferRestart}catch{$caught=$true}
Assert ($caught -and 'failed-binding' -notin $r.restartSteps) 'An actual install error cannot be promoted to a deferred success'
$script:mockCode=3010;$null=Run-Child 'enable-after-binding' 'pnputil.exe' @() 90000 -DeferRestart
Assert ('enable-after-binding' -in $r.restartSteps) 'PnP restart-required status joins the same pending restart batch'
$guard=$ast.FindAll({param($n)$n -is [Management.Automation.Language.IfStatementAst] -and $n.Extent.Text.Contains("`$r.status='PENDING253_BINDING_RESTART'") -and $n.Extent.Text.StartsWith('if($r.rebootRequired)')},$true)[0]
$verify=$ast.FindAll({param($n)$n -is [Management.Automation.Language.CommandAst] -and $n.GetCommandName() -eq 'Capture-WithWarmStartRetry'},$true)[0]
Assert ($guard.Extent.EndOffset -lt $verify.Extent.StartOffset -and $guard.Extent.Text.Contains('exit $exitCode')) 'Pending binding restart exits before either camera is opened'
[ordered]@{status='PASS';count=$passed.Count;tests=$passed;driverChanged=$false;actualReboot=$false}|ConvertTo-Json -Depth 5|Set-Content -LiteralPath (Join-Path $PSScriptRoot 'restart-batch-results.json') -Encoding UTF8
Write-Output ('PASS_RESTART_BATCH count='+$passed.Count)
