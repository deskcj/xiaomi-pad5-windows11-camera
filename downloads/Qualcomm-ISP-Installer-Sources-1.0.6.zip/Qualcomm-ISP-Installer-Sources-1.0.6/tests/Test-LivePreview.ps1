﻿$ErrorActionPreference='Stop';Set-StrictMode -Version Latest
$project=Split-Path -Parent $PSScriptRoot
. (Join-Path $project 'src\WinRT-References.ps1')
$compiler=Join-Path $env:windir 'Microsoft.NET\Framework64\v4.0.30319\csc.exe'
$arguments=@('/nologo','/target:exe','/reference:System.Core.dll','/reference:System.Drawing.dll',('/out:'+(Join-Path $project 'work\Test-LivePreview.exe')))+(Get-CameraWinRTReferences)+@((Join-Path $project 'src\NativePreview.cs'),(Join-Path $PSScriptRoot 'Test-LivePreview.cs'))
& $compiler @arguments;if($LASTEXITCODE -ne 0){throw 'Live preview test compilation failed'}
& (Join-Path $project 'work\Test-LivePreview.exe');if($LASTEXITCODE -ne 0){throw 'Live preview metrics failed'}
$tokens=$null;$errors=$null;$ast=[Management.Automation.Language.Parser]::ParseFile((Join-Path $project 'src\Worker.ps1'),[ref]$tokens,[ref]$errors)
if($errors.Count){throw ($errors|Out-String)}
$node=$ast.FindAll({param($n)$n -is [Management.Automation.Language.FunctionDefinitionAst] -and $n.Name -eq 'Test-LivePreviewJournal'},$true)
. ([scriptblock]::Create($node[0].Extent.Text))
$passed=[Collections.Generic.List[string]]::new()
function Assert([bool]$ok,[string]$name){if(-not $ok){throw $name};$passed.Add($name)}
Assert (-not(Test-LivePreviewJournal ([pscustomobject]@{boot='boot-a';captureClosed=$false}) 'boot-a')) 'An unclosed preview blocks rebinding in the same kernel session'
Assert (Test-LivePreviewJournal ([pscustomobject]@{boot='boot-a';captureClosed=$false}) 'boot-b') 'A new kernel session clears a crashed preview requirement'
Assert (Test-LivePreviewJournal ([pscustomobject]@{boot='boot-a';captureClosed=$true}) 'boot-a') 'A штатно closed preview permits installation without a restart'
Assert (-not(Test-LivePreviewJournal $null 'boot-a')) 'Invalid JSON cannot prove a closed preview'
Assert (-not(Test-LivePreviewJournal ([pscustomobject]@{boot='boot-a';captureClosed='false'}) 'boot-a')) 'A string false is not treated as a successful close'
Assert (-not(Test-LivePreviewJournal ([pscustomobject]@{captureClosed=$true}) 'boot-a')) 'A malformed journal needs attention'
$app=Get-Content -LiteralPath (Join-Path $project 'src\App.cs') -Raw
Assert ($app -match 'await nativeLive.StopAsync\(\);WritePreviewJournal\(true' -and $app -match 'if\(nativeLive!=null\|\|liveChanging\|\|liveBlocked\)return') 'Installation waits for managed preview closure'
Assert ($app -match 'async void BeginPreview\(\).*await ReconcileLive\(\)' -and $app -match 'measurement=new CameraMeasurement\(nativeLive.Snapshot\(\)\)') 'Preview bypasses Worker diagnostics; Test measures the running source'
[ordered]@{status='PASS';metrics=9;journal=$passed.Count;tests=$passed}|ConvertTo-Json -Depth 5|Set-Content (Join-Path $PSScriptRoot 'live-preview-results.json') -Encoding UTF8
Write-Output ('PASS_LIVE_PREVIEW count='+(9+$passed.Count))
