$ErrorActionPreference='Stop';Set-StrictMode -Version Latest
$driver=Join-Path (Split-Path -Parent $PSScriptRoot) 'release\Driver'
. (Join-Path $driver 'Tools\CameraPrerequisites.ps1')
$passed=[Collections.Generic.List[string]]::new()
function Assert([bool]$Ok,[string]$Name){if(-not $Ok){throw ('FAIL '+$Name)};$passed.Add($Name)}
function Save-State {}
function Note([string]$Text) {}
function Progress([int]$Percent,[string]$Phase) {}
function Import-PackageCertificates {}
function Get-Service {return [pscustomobject]@{Status='Stopped'}}
function Get-Process {return @()}
function Get-ChildItem {return [pscustomobject]@{FullName='mock-trusted.cat'}}
function Get-AuthenticodeSignature {return [pscustomobject]@{Status='Valid'}}
function Get-PrerequisiteNodes {return $script:devices}
$script:scenario='pending';$script:calls=[Collections.Generic.List[string]]::new()
function Run-Child([string]$Label,[string]$Exe,[string[]]$Arguments,[int]$Timeout=60000,[switch]$DeferRestart){
 $script:calls.Add($Label)
 Assert ([bool]$DeferRestart) ('Batch deferral used for '+$Label)
 if($Label -eq 'prerequisite-platform'){
  if($script:scenario -eq 'error'){throw 'Simulated genuine install failure'}
  $r.rebootRequired=$true;$script:devices=@([pscustomobject]@{id='ACPI\QCOM0535\1';problem=14})
 }
 if($Label -like 'prerequisite-stage-*'){Assert ($Arguments[0] -eq '/add-driver' -and $Arguments.Count -eq 2) 'Missing child INF is staged without guessing or creating ACPI nodes'}
 return ''
}
$root=$driver;$r=[ordered]@{rebootRequired=$false;driverActions=$false}
$script:devices=@([pscustomobject]@{id='ACPI\QCOM0535\1';problem=28})
Repair-CameraPrerequisites
Assert ($r.prerequisiteRepair.status -eq 'PENDING_RESTART' -and $script:calls.Contains('prerequisite-stage-jpeg') -and $script:calls.Contains('prerequisite-stage-flash')) 'Platform restart does not abandon JPEG and Flash package staging'
Assert (-not $script:calls.Contains('prerequisite-jpeg') -and -not $script:calls.Contains('prerequisite-flash')) 'Absent child devices are not passed to devcon update'
$script:devices=@([pscustomobject]@{id='ACPI\QCOM0535\1';problem=14},[pscustomobject]@{id='ACPI\QCOM0536\2';problem=0},[pscustomobject]@{id='ACPI\QCOM052A\3';problem=0});$script:calls.Clear();$r=[ordered]@{rebootRequired=$false;driverActions=$false}
Repair-CameraPrerequisites
Assert ($r.rebootRequired -and $script:calls -notcontains 'prerequisite-platform') 'Existing Windows Code14 is handled as a restart without reinstalling the same parent'
$script:scenario='error';$script:devices=@([pscustomobject]@{id='ACPI\QCOM0535\1';problem=28});$r=[ordered]@{rebootRequired=$false;driverActions=$false};$failed=$false
try{Repair-CameraPrerequisites}catch{$failed=$true}
Assert ($failed -and -not $r.rebootRequired) 'Actual prerequisite install errors stay errors'
$report=[ordered]@{status='PASS';count=$passed.Count;tests=$passed;driverChanged=$false;actualReboot=$false}
$report|ConvertTo-Json -Depth 5|Set-Content -LiteralPath (Join-Path $PSScriptRoot 'prerequisite-restart-results.json') -Encoding UTF8
Write-Output ('PASS_PREREQUISITE_RESTART count='+$passed.Count)
