﻿$ErrorActionPreference='Stop';Set-StrictMode -Version Latest
$project=Split-Path -Parent $PSScriptRoot
$tokens=$null;$parseErrors=$null
$ast=[Management.Automation.Language.Parser]::ParseFile((Join-Path $project 'src\Worker.ps1'),[ref]$tokens,[ref]$parseErrors)
if($parseErrors.Count){throw ($parseErrors | Out-String)}
foreach($name in 'Test-CurrentBootTestSigning','Resolve-BootSecurity'){
 $node=$ast.FindAll({param($n)$n -is [Management.Automation.Language.FunctionDefinitionAst] -and $n.Name -eq $name},$true)
 . ([scriptblock]::Create($node[0].Extent.Text))
}
$passed=[Collections.Generic.List[string]]::new()
function Assert([bool]$Condition,[string]$Name){if(-not $Condition){throw ('FAIL: '+$Name)};$passed.Add($Name)}
function Native([bool]$SecureAvailable,[bool]$SecureEnabled,[bool]$CiAvailable,[uint32]$CiOptions){
 [pscustomobject]@{SecureBootAvailable=$SecureAvailable;SecureBootEnabled=$SecureEnabled;SecureBootCapable=$SecureAvailable;SecureBootStatus='mock';CodeIntegrityAvailable=$CiAvailable;CodeIntegrityOptions=$CiOptions;CodeIntegrityStatus='mock'}
}
$state=Resolve-BootSecurity (Native $true $false $true 3) $null -1 ' TESTSIGNING NOEXECUTE=OPTIN'
Assert ($state.compatible -and $state.secureBoot.state -eq 'Disabled' -and $state.testMode.enabled) 'Missing registry value does not block kernel-confirmed Secure Boot off and Test Mode on'
Assert ($state.secureBoot.source -eq 'Current kernel: SystemSecureBootInformation') 'The report identifies the actual Secure Boot evidence source'
$state=Resolve-BootSecurity (Native $false $false $true 3) $null -1 ' TESTSIGNING NOEXECUTE=OPTIN'
Assert ($state.compatible -and $state.secureBoot.state -eq 'Unknown' -and $state.testMode.enabled) 'Firmware without Secure Boot reporting permits installation only with kernel-confirmed test-signing support'
Assert ($state.detail -notmatch 'Secure Boot выключен|Secure Boot включён') 'Unknown firmware state is never displayed as enabled or disabled'
$state=Resolve-BootSecurity (Native $true $true $true 3) $false 0 ' TESTSIGNING'
Assert (-not $state.compatible -and $state.secureBoot.state -eq 'Enabled') 'Kernel-confirmed enabled Secure Boot blocks installation despite permissive registry or Test Mode flags'
$state=Resolve-BootSecurity (Native $false $false $true 3) $true 0 ' TESTSIGNING'
Assert (-not $state.compatible -and $state.secureBoot.state -eq 'Enabled') 'UEFI-confirmed enabled Secure Boot blocks installation'
$state=Resolve-BootSecurity (Native $false $false $true 3) $null 1 ' TESTSIGNING'
Assert (-not $state.compatible) 'Registry enabled Secure Boot remains a blocker when direct queries are unavailable'
$state=Resolve-BootSecurity (Native $true $false $true 1) $null -1 ' TESTSIGNING'
Assert (-not $state.testMode.enabled) 'An inactive kernel Test Mode cannot be overridden by boot configuration flags'
$state=Resolve-BootSecurity (Native $false $false $true 1) $null -1 ' TESTSIGNING'
Assert (-not $state.compatible -and -not $state.testMode.enabled) 'Unknown Secure Boot and inactive kernel Test Mode fail closed'
$state=Resolve-BootSecurity (Native $false $false $false 0) $null -1 ' TESTSIGNING'
Assert (-not $state.compatible) 'Boot flags alone cannot clear unknown Secure Boot without kernel evidence'
$state=Resolve-BootSecurity (Native $false $false $false 0) $false -1 ' TESTSIGNING'
Assert ($state.compatible -and $state.testMode.enabled -and $state.secureBoot.source -eq 'UEFI: Confirm-SecureBootUEFI') 'A direct UEFI disabled result supports systems without the native query'
$state=Resolve-BootSecurity (Native $false $false $false 0) $null 0 ' TESTSIGNING'
Assert ($state.compatible -and $state.testMode.enabled) 'Legacy registry and active boot options remain usable when native queries are unavailable'
$state=Resolve-BootSecurity (Native $true $false $false 0) $null -1 ' TESTSIGNING=OFF'
Assert (-not $state.testMode.enabled) 'An off flag is never accepted as active Test Mode'
$state=Resolve-BootSecurity (Native $true $false $true 3) $null 1 ''
Assert ($state.compatible -and $state.testMode.enabled) 'Direct kernel evidence takes precedence over a stale registry and missing boot flags'
$state=Resolve-BootSecurity (Native $false $false $true 3) $null -2 ''
Assert ($state.compatible -and $state.secureBoot.state -eq 'Unknown') 'Unexpected registry values retain Unknown status and require kernel test-signing evidence'
[ordered]@{status='PASS';count=$passed.Count;tests=$passed;driverChanged=$false;cameraOpened=$false;actualReboot=$false}|ConvertTo-Json -Depth 6|Set-Content -LiteralPath (Join-Path $PSScriptRoot 'boot-security-results.json') -Encoding UTF8
'PASS_BOOT_SECURITY count='+$passed.Count
