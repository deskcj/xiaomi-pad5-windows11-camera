﻿$ErrorActionPreference='Stop';Set-StrictMode -Version Latest
$project=Split-Path -Parent $PSScriptRoot;$setup=Join-Path $project 'release\Driver\Setup.ps1'
$tokens=$null;$parseErrors=$null;$ast=[Management.Automation.Language.Parser]::ParseFile($setup,[ref]$tokens,[ref]$parseErrors)
if($parseErrors.Count){throw ($parseErrors|Out-String)}
$node=$ast.FindAll({param($n)$n -is [Management.Automation.Language.FunctionDefinitionAst] -and $n.Name -eq 'Get-InstalledAuditSummary'},$true)
. ([scriptblock]::Create($node[0].Extent.Text))
$passed=[Collections.Generic.List[string]]::new()
function Assert([bool]$Condition,[string]$Name){if(-not $Condition){throw ('FAIL '+$Name)};$passed.Add($Name)}
$cache='C:\ProgramData\XiaomiPad5Camera\Packages\QISP253-test'
$record=[pscustomobject]@{cache=$cache;mode='Install';status='PASS253R2_INSTALLED_BOTH_CAMERAS_VERIFIED';unsafeToContinue=$false;rebootRequired=$false;pendingPid=0;captureClosed=$true;fullMftDecoded=$true;captures=@([pscustomobject]@{side='rear';signal=$true;closeVerified=$true},[pscustomobject]@{side='front';signal=$true;closeVerified=$true})}
$summary=Get-InstalledAuditSummary $true $record $cache
Assert ($summary.installed -and -not $summary.continuationRequired -and $summary.cameraVerification -eq 'PREVIOUSLY_PASSED_BOTH_CAMERAS') 'An exact installed package and successful two-camera record do not request installation again'
$summary=Get-InstalledAuditSummary $false $record $cache 'Active SYS differs'
Assert (-not $summary.installed -and $summary.state -eq 'REPAIR_REQUIRED' -and $summary.cameraVerification -ne 'PREVIOUSLY_PASSED_BOTH_CAMERAS') 'An old success record cannot override a mismatching active binary'
$record.status='INSTALLED253_VERIFICATION_INCOMPLETE';$record.unsafeToContinue=$true
$summary=Get-InstalledAuditSummary $true $record $cache
Assert ($summary.installed -and $summary.continuationRequired -and $summary.cameraVerification -eq 'NOT_COMPLETE') 'Installed files with an incomplete unsafe check request verification rather than reinstall'
$record.status='PASS253R2_INSTALLED_BOTH_CAMERAS_VERIFIED';$record.unsafeToContinue=$false;$record.rebootRequired=$true
Assert ((Get-InstalledAuditSummary $true $record $cache).continuationRequired) 'Outstanding reboot is not dismissed by a successful-looking record'
$record.rebootRequired=$false;$record.mode='Diagnose';$record.captures=@($record.captures[0])
$summary=Get-InstalledAuditSummary $true $record $cache
Assert ($summary.installed -and -not $summary.continuationRequired -and $summary.cameraVerification -eq 'NOT_COMPLETE') 'A completed one-camera preview does not cause a new driver install or claim a two-camera test'
$summary=Get-InstalledAuditSummary $true $null $cache
Assert ($summary.installed -and -not $summary.continuationRequired -and $summary.cameraVerification -eq 'NOT_COMPLETE') 'Exact installed files need no reinstall even when historical camera test logs are absent'
$record.cache='other-package'
Assert ((Get-InstalledAuditSummary $true $record $cache).cameraVerification -eq 'NOT_COMPLETE') 'Camera proof from a different package is not presented as current proof'
$summary=Get-InstalledAuditSummary $true ([pscustomobject]@{rebootRequired=$true}) $cache
Assert ($summary.installed -and $summary.continuationRequired) 'Incomplete older journals still preserve an explicit restart requirement'
$check=$ast.FindAll({param($n)$n -is [Management.Automation.Language.IfStatementAst] -and $n.Extent.Text.StartsWith("if(`$Mode -eq 'Check')")},$true)
$mutations=$ast.FindAll({param($n)$n -is [Management.Automation.Language.CommandAst] -and $n.GetCommandName() -eq 'New-Item' -and $n.Extent.Text -eq 'New-Item -ItemType Directory -Path $base -Force'},$true)
Assert ($check.Count -eq 1 -and $check[0].Extent.Text -notmatch 'Capture-One|Bind |Prepare-NativeLogging|Prepare-CameraDma|Set-NativeLogging|Stage-Resume') 'The startup installed-package audit opens no camera, changes no driver and schedules no restart'
[ordered]@{status='PASS';count=$passed.Count;tests=$passed;driverChanged=$false;cameraOpened=$false}|ConvertTo-Json -Depth 5|Set-Content (Join-Path $PSScriptRoot 'installed-status-results.json') -Encoding UTF8
Write-Output ('PASS_INSTALLED_STATUS count='+$passed.Count)
