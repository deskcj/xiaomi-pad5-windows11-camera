﻿$ErrorActionPreference='Stop';Set-StrictMode -Version Latest
$project=Split-Path -Parent $PSScriptRoot;$folder=Join-Path ([Environment]::GetFolderPath('Desktop')) 'Qualcomm ISP Drivers';$resultRoot=Join-Path $project 'work\app-lifecycle'
New-Item -ItemType Directory -Path $resultRoot -Force|Out-Null
$report=[ordered]@{status='RUNNING';started=(Get-Date -Format o);uninstallPassed=$false;reinstallPassed=$false;driversRetained=$false;errors=@()}
function Save{$report|ConvertTo-Json -Depth 7|Set-Content -LiteralPath (Join-Path $resultRoot 'result.json') -Encoding UTF8}
function Driver-Hashes {
 foreach($service in 'qcISP','qcCameraMipiCsi','QCCamAvs','CameraFrontSensor','CameraRearSensor'){
  $path=(Get-Item -LiteralPath ('HKLM:\SYSTEM\CurrentControlSet\Services\'+$service)).GetValue('ImagePath','');$path=[Environment]::ExpandEnvironmentVariables($path).Replace('\SystemRoot',$env:windir);if($path.StartsWith('\??\')){$path=$path.Substring(4)}
  [ordered]@{service=$service;path=$path;sha256=(Get-FileHash -LiteralPath $path).Hash}
 }
}
try{
 Save;$before=@(Driver-Hashes);$report.before=$before;Save
 $p=Start-Process -FilePath (Join-Path $folder 'Uninstall.exe') -ArgumentList @('--uninstall','--quiet') -PassThru;$null=$p.Handle;$p.WaitForExit()
 $until=[datetime]::UtcNow.AddSeconds(45);while((Test-Path -LiteralPath $folder) -and [datetime]::UtcNow -lt $until){Start-Sleep -Milliseconds 500}
 if(Test-Path -LiteralPath $folder){throw 'Installed application folder remained after uninstall'}
 if(Test-Path -LiteralPath 'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\XiaomiPad5QualcommISP'){throw 'Uninstall registration remained'}
 if(Test-Path -LiteralPath (Join-Path ([Environment]::GetFolderPath('Desktop')) 'Qualcomm ISP Camera Drivers.lnk')){throw 'Desktop shortcut remained'}
 $report.uninstallPassed=$true;$after=@(Driver-Hashes);$report.driversRetained=($before|ConvertTo-Json -Compress) -ceq ($after|ConvertTo-Json -Compress);if(-not $report.driversRetained){throw 'Driver identities changed during application removal'};Save
 $p=Start-Process -FilePath (Join-Path $project 'Qualcomm-ISP-Drivers-Setup.exe') -ArgumentList '--quiet' -PassThru;$null=$p.Handle;$p.WaitForExit();$p.Refresh();if($p.ExitCode -ne 0){throw 'Setup did not exit successfully'}
 if(-not(Test-Path -LiteralPath (Join-Path $folder 'APP-SHA256.json'))){throw 'Fresh install did not produce the application manifest'}
 if(Test-Path -LiteralPath 'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\XiaomiPad5QualcommISP'){throw 'Portable application unexpectedly registered in Windows Apps'}
 $manifest=Get-Content -LiteralPath (Join-Path $folder 'APP-SHA256.json') -Raw|ConvertFrom-Json
 foreach($file in $manifest.files){if((Get-FileHash -LiteralPath (Join-Path $folder $file.path)).Hash -ine $file.sha256){throw ('Freshly installed file differs: '+$file.path)}}
 $report.reinstallPassed=$true;$report.status='PASS';Save
 if($env:XIAOMI_CAMERA_TEST_NO_LAUNCH -ne '1'){Start-Process -FilePath (Join-Path $folder 'xiaomi-pad5-windows11-camera.exe') -ArgumentList '--install'|Out-Null}
}catch{$report.status='ERROR';$report.errors+=@($_.Exception.Message);Save;exit 1}
exit 0
