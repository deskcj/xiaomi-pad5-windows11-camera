﻿$ErrorActionPreference='Stop';Set-StrictMode -Version Latest
$project=Split-Path -Parent $PSScriptRoot;$root=Join-Path $project 'release\Driver'
. (Join-Path $root 'Tools\CameraDma.ps1')
. (Join-Path $root 'Tools\CameraSelection.ps1')
$passed=[Collections.Generic.List[string]]::new()
function Assert([bool]$Condition,[string]$Name){if(-not $Condition){throw ('FAIL '+$Name)};$passed.Add($Name)}
function Reject([scriptblock]$Action,[string]$Name){$caught=$false;try{& $Action|Out-Null}catch{$caught=$true};Assert $caught $Name}
$boot=[pscustomobject]@{recordId=100;timeUtc='2026-11-06T01:00:00Z'};$new=[pscustomobject]@{recordId=101;timeUtc='2026-11-06T02:00:00Z'}
$unsafe=[pscustomobject]@{pendingPid=0;unsafeToContinue=$true;captureClosed=$false;fullMftDecoded=$false;rebootRequired=$false;bootIdentity=$boot}
Assert ((Get-CameraRecoveryAction $unsafe $boot '') -eq 'RESTART_REQUIRED') 'An unclosed capture cannot be retried in the same kernel boot'
Assert ((Get-CameraRecoveryAction $unsafe $new '') -eq 'NEW_BOOT') 'An actual new boot permits fresh qualification'
Assert ((Get-CameraRecoveryAction $null $boot '') -eq 'NONE') 'First install has no stale capture journal'
$safe=[pscustomobject]@{pendingPid=0;unsafeToContinue=$false;captureClosed=$true;fullMftDecoded=$true;rebootRequired=$false}
Assert ((Get-CameraRecoveryAction $safe $boot '') -eq 'NONE') 'Closed completed capture permits another test'
Assert (-not (Test-CameraNewBoot $boot $boot)) 'Opening the app again does not qualify as a restart'
Assert (Test-CameraNewBoot $boot $new) 'Kernel event identity distinguishes a real restart'
$kernelBefore=[pscustomobject]@{bootId='first-kernel';recordId=100;timeUtc='old-event'};$kernelAfter=[pscustomobject]@{bootId='second-kernel';recordId=100;timeUtc='old-event'}
Assert (Test-CameraNewBoot $kernelBefore $kernelAfter) 'Kernel boot GUID detects a restart even when the Windows event log is stale'
$kernelAfter.bootId='first-kernel';$kernelAfter.recordId=101
Assert (-not(Test-CameraNewBoot $kernelBefore $kernelAfter)) 'An event log change alone cannot qualify as a restart when kernel GUIDs match'
$counterBefore=[pscustomobject]@{bootId='firmware-guid';bootCounter=838;recordId=100;timeUtc='old-event'};$counterAfter=[pscustomobject]@{bootId='firmware-guid';bootCounter=839;recordId=100;timeUtc='old-event'}
Assert (Test-CameraNewBoot $counterBefore $counterAfter) 'The Windows boot counter supports firmware that reuses its boot GUID'
$snapshot=[pscustomobject]@{service='qcsmmu';sha256='2fa1883f3252d2e50d63911fc9ff435f88e75210f429e86686e395e0827e1299';chipSetVersion=2;problem=0;device='mock';driverKey='mock';maps=@([pscustomobject]@{suffix='0\S2CB\0x01\0x04\0x16';hex='ff20800020'},[pscustomobject]@{suffix='0\S2CB\0x01\0x04\0x11';hex='ff20c00000'})}
Assert ((Get-CameraDmaPlanFromSnapshot $snapshot).updates.Count -eq 2) 'Known unpatched camera DMA maps have two exact startup updates'
$snapshot.sha256='unknown';Reject {Get-CameraDmaPlanFromSnapshot $snapshot} 'An unknown SMMU binary is rejected before a write'
$snapshot.sha256='2fa1883f3252d2e50d63911fc9ff435f88e75210f429e86686e395e0827e1299';$snapshot.maps[0].hex='0000000000';Reject {Get-CameraDmaPlanFromSnapshot $snapshot} 'An unknown camera DMA map is never guessed'
$snapshot.maps[0].hex='ff20800020ff21000020';$snapshot.maps[1].hex='ff20c00000ff21400000'
Assert ((Get-CameraDmaPlanFromSnapshot $snapshot).updates.Count -eq 0) 'Already prepared DMA maps require no update'
$tokens=$null;$errors=$null;$ast=[Management.Automation.Language.Parser]::ParseFile((Join-Path $root 'Setup.ps1'),[ref]$tokens,[ref]$errors)
Assert ($errors.Count -eq 0) 'Installer parses in Windows PowerShell 5.1'
foreach($name in 'Can-RetryNativeEmptyStart','Complete-CleanBootGate','Test-CleanBootGateAvailable','Test-CleanBootWindow'){
 $function=$ast.FindAll({param($n)$n -is [Management.Automation.Language.FunctionDefinitionAst] -and $n.Name -eq $name},$true)
 . ([scriptblock]::Create($function[0].Extent.Text))
}
$prepared='{"schema":1,"status":"PREPARED","packageId":"test","boot":{"bootCounter":839,"bootId":"firmware-guid","recordId":100,"timeUtc":"before"}}'|ConvertFrom-Json
$currentBoot=[pscustomobject]@{bootCounter=840;bootId='firmware-guid';recordId=200;timeUtc='after'}
$consumed=Complete-CleanBootGate $prepared $currentBoot
$roundtrip=$consumed|ConvertTo-Json -Depth 5|ConvertFrom-Json
Assert ($roundtrip.status -eq 'CONSUMED' -and $roundtrip.boot.bootCounter -eq 839 -and $roundtrip.consumedBoot.bootCounter -eq 840) 'Resume adds the consumed boot to a deserialized prepared journal and retains the original boot'
$beforeBinding=[pscustomobject]@{cleanBootGate='PASS';driverActions=$false;rebootRequired=$false;pendingPid=0;unsafeToContinue=$false;captureClosed=$true;fullMftDecoded=$true;captures=@()}
Assert (Test-CleanBootGateAvailable $roundtrip $currentBoot $beforeBinding) 'Failure before binding permits retry in the already qualified clean boot'
$beforeBinding.driverActions=$true
Assert (-not(Test-CleanBootGateAvailable $roundtrip $currentBoot $beforeBinding)) 'A failed driver change cannot reuse a consumed clean boot'
$beforeBinding.driverActions=$false;$beforeBinding.rebootRequired=$true
Assert (-not(Test-CleanBootGateAvailable $roundtrip $currentBoot $beforeBinding)) 'A requested restart blocks same-boot gate reuse'
$gpuStops=$ast.FindAll({param($n)$n -is [Management.Automation.Language.CommandAst] -and $n.GetCommandName() -eq 'Stop-Gpu'},$true)
Assert ($gpuStops.Count -eq 1) 'GPU shutdown is executed once per install so evidence labels cannot repeat'
Assert (Test-CleanBootWindow '2026-11-06T10:00:00Z' ([datetimeoffset]'2026-11-06T10:05:00Z')) 'Driver replacement starts within a fresh boot window'
Assert (-not(Test-CleanBootWindow '2026-11-06T10:00:00Z' ([datetimeoffset]'2026-11-06T10:20:00Z'))) 'An old unconsumed gate cannot qualify a late camera replacement'
Assert (-not(Test-CleanBootWindow 'invalid' ([datetimeoffset]'2026-11-06T10:05:00Z'))) 'Invalid boot timestamps fail closed'
$text="STATE256 captureCreated=1 initializeAttempted=1 readerCreated=1 startAttempted=1 readerStarted=1`nCLOSE256 reader_stop hr=00000000`nCLOSE256 reader_close hr=00000000`nCLOSE256 capture_close hr=00000000`nRETIRE256 neverOpened=0 readerStopped=1 readerClosed=1 captureClosed=1`nRESULT256 hr=00000000 frames=0 duplicatePolls=0 width=1920 height=1080 meanY=0 minY=255 maxY=0 hash=12345678 signal=false saved=false controlsChanged=false"
$close=[pscustomobject]@{status='PASS';eventsLost=0};$decode=[pscustomobject]@{status='PASS';eventsLost=0}
Assert (Can-RetryNativeEmptyStart $text $close $decode $safe) 'Zero-frame first startup permits one retry only with complete closure evidence'
$decode.eventsLost=1;Assert (-not(Can-RetryNativeEmptyStart $text $close $decode $safe)) 'Lost trace events block automatic retry';$decode.eventsLost=0
Assert (-not(Can-RetryNativeEmptyStart ($text.Replace('hr=00000000 frames=0','hr=80070005 frames=0')) $close $decode $safe)) 'Access denied is not treated as the known warm-start condition'
Assert (-not(Can-RetryNativeEmptyStart $text $close $decode $unsafe)) 'Unclosed state blocks retry even if a result line looks successful'
$workerAst=[Management.Automation.Language.Parser]::ParseFile((Join-Path $project 'release\Scripts\Worker.ps1'),[ref]$tokens,[ref]$errors)
Assert ($errors.Count -eq 0) 'Worker parses in Windows PowerShell 5.1'
$resumeFunction=$workerAst.FindAll({param($n)$n -is [Management.Automation.Language.FunctionDefinitionAst] -and $n.Name -eq 'Stage-Resume'},$true)
Assert ($resumeFunction[0].Extent.Text.Contains("`$result.resumeExe=Join-Path `$appRoot 'xiaomi-pad5-windows11-camera.exe'")) 'Resume targets the existing application in its own folder'
Assert ($resumeFunction[0].Extent.Text -notmatch 'ProgramData|Copy-Item') 'Resume does not duplicate the application in ProgramData'
$signingFunction=$workerAst.FindAll({param($n)$n -is [Management.Automation.Language.FunctionDefinitionAst] -and $n.Name -eq 'Test-CurrentBootTestSigning'},$true)
. ([scriptblock]::Create($signingFunction[0].Extent.Text))
Assert (Test-CurrentBootTestSigning ' TESTSIGNING  NOEXECUTE=OPTIN') 'Test Mode is checked for the current kernel boot'
Assert (-not(Test-CurrentBootTestSigning ' NOEXECUTE=OPTIN')) 'Disabled Test Mode blocks test-signed driver installation'
Assert (-not(Test-CurrentBootTestSigning ' TESTSIGNING=OFF')) 'An off flag is never interpreted as enabled Test Mode'
Assert (-not(Test-CurrentBootTestSigning '')) 'Missing boot flags fail closed'
$guard=$workerAst.FindAll({param($n)$n -is [Management.Automation.Language.IfStatementAst] -and $n.Extent.Text.StartsWith('if(-not $testSigning)')},$true)
$launch=$workerAst.FindAll({param($n)$n -is [Management.Automation.Language.CommandAst] -and $n.GetCommandName() -eq 'Start-Process' -and $n.Extent.Text.StartsWith('Start-Process -FilePath $exe -ArgumentList $args')},$true)
Assert ($guard.Count -eq 1 -and $guard[0].Extent.StartOffset -lt $launch[0].Extent.StartOffset) 'Test Mode is required before launching the driver engine'
$bad=Join-Path $project 'work\incomplete-package-test';New-Item -ItemType Directory -Path (Join-Path $bad 'Scripts') -Force|Out-Null
Copy-Item -LiteralPath (Join-Path $project 'release\Scripts\Worker.ps1') -Destination (Join-Path $bad 'Scripts\Worker.ps1') -Force
Copy-Item -LiteralPath (Join-Path $project 'release\APP-SHA256.json') -Destination $bad -Force
$p=Start-Process -FilePath "$env:windir\System32\WindowsPowerShell\v1.0\powershell.exe" -ArgumentList @('-NoProfile','-ExecutionPolicy','Bypass','-File',('"'+(Join-Path $bad 'Scripts\Worker.ps1')+'"'),'-Mode','Scan','-RunRoot',('"'+(Join-Path $bad 'Result')+'"')) -WindowStyle Hidden -PassThru
$p.WaitForExit();$r=Get-Content -LiteralPath (Join-Path $bad 'Result\app-result.json') -Raw|ConvertFrom-Json
Assert ($p.ExitCode -ne 0 -and $r.status -eq 'ERROR' -and -not $r.driverChanges -and $r.devices.Count -eq 0) 'An incomplete archive stops before device operations and produces an error report'
[ordered]@{status='PASS';count=$passed.Count;tests=$passed;actualReboot=$false;cameraOpened=$false;driverChanged=$false}|ConvertTo-Json -Depth 8|Set-Content -LiteralPath (Join-Path $PSScriptRoot 'safety-results.json') -Encoding UTF8
Write-Output ('PASS_SAFETY count='+$passed.Count)
