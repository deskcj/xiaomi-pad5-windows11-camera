﻿$ErrorActionPreference='Stop';Set-StrictMode -Version Latest
$project=Split-Path -Parent $PSScriptRoot
$workspace=Split-Path -Parent (Split-Path -Parent $project)
$own=Join-Path $workspace 'work\Hardware-Test-1.0.1\GPU-Logs\GPUISP-20261106-232208-e8f3be'
$friend=Join-Path $project 'work\friend-report-010249\Engine\QISP253-20261107-010030-fee807'
$output=Join-Path $project 'work\trace-evidence-tests';New-Item -ItemType Directory -Path $output -Force|Out-Null
$tool=Join-Path $project 'release\Driver\Tools\Check-NativeClose.ps1'
$passed=[Collections.Generic.List[string]]::new()
function Assert([bool]$Condition,[string]$Name){if(-not $Condition){throw ('FAIL '+$Name)};$passed.Add($Name)}
function Read-Trace([string]$Xml,[string]$Name){
 $dest=Join-Path $output ($Name+'.json')
 $process=Start-Process -FilePath "$env:windir\System32\WindowsPowerShell\v1.0\powershell.exe" -ArgumentList @('-NoProfile','-ExecutionPolicy','Bypass','-File',('"'+$tool+'"'),'-XmlFile',('"'+$Xml+'"'),'-OutputFile',('"'+$dest+'"')) -WindowStyle Hidden -RedirectStandardError (Join-Path $output ($Name+'.err.log')) -Wait -PassThru
 if(-not(Test-Path -LiteralPath $dest)){throw ('No trace verdict: '+$Name)}
 return Get-Content -LiteralPath $dest -Raw|ConvertFrom-Json
}
$hold=Read-Trace (Join-Path $friend 'verify-rear\dbgprint.xml') 'friend'
Assert ($hold.status -eq 'HOLD' -and $hold.evidenceStatus -eq 'MISSING_DRIVER_LOG_MARKERS') 'Real user trace reports absent diagnostic evidence without inventing driver failure or success'
Assert ($hold.errors.Count -eq 0 -and $hold.eventsLost -eq 0 -and -not $hold.nativeCloseSucceeded) 'No fatal markers and no event loss do not bypass closure verification'
$probe=Get-Content (Join-Path $friend 'verify-rear-probe.out.log') -Raw
Assert ($probe -match 'RESULT256[^\r\n]*frames=133[^\r\n]*signal=true' -and $probe -match 'RETIRE256[^\r\n]*readerClosed=1 captureClosed=1') 'The actual reproduction supplies frames and WinRT closure yet remains an incomplete native check'
foreach($side in 'rear','front'){
 $good=Read-Trace (Join-Path $own ('pre-release-native-'+$side+'\dbgprint.xml')) ('own-'+$side)
 Assert ($good.status -eq 'PASS' -and $good.evidenceStatus -eq 'COMPLETE' -and $good.nativeCloseSucceeded) ('Known successful '+$side+' trace retains its complete ordered verdict')
}
$minimal=Join-Path $output 'explicit-failure.xml'
@'
<Events><Event><EventData>
<Data Name="Message">successfully initialized IFE0!</Data>
<Data Name="Message">CCaptureFilter::StopVideo state INITIALIZED</Data>
<Data Name="Message">ICP: device close failed</Data>
<Data Name="Message">successfully closed IFE!</Data>
</EventData></Event></Events>
'@|Set-Content -LiteralPath $minimal -Encoding UTF8
$failure=Read-Trace $minimal 'explicit-failure'
Assert ($failure.status -eq 'HOLD' -and $failure.evidenceStatus -eq 'EXPLICIT_DRIVER_FAILURE') 'An explicit native close failure is still rejected even after IFE close success'
[ordered]@{status='PASS';count=$passed.Count;tests=$passed;driverChanged=$false;cameraOpened=$false}|ConvertTo-Json -Depth 5|Set-Content (Join-Path $PSScriptRoot 'trace-evidence-results.json') -Encoding UTF8
Write-Output ('PASS_TRACE_EVIDENCE count='+$passed.Count)
