﻿param([string]$Release=(Join-Path (Split-Path -Parent $PSScriptRoot) 'release'))
$ErrorActionPreference='Stop'
$driver=Join-Path $Release 'Driver';$manifestPath=Join-Path $driver 'MANIFEST-SHA256.json'
$manifest=Get-Content -LiteralPath $manifestPath -Raw|ConvertFrom-Json
$manifest.installerRevision='Desktop 1.0.5 / R26';$manifest.payloadId='sk1-qisp253-20261106'
$manifest.files=@(Get-ChildItem -LiteralPath $driver -Recurse -File|Where-Object {$_.Name -ne 'MANIFEST-SHA256.json'}|ForEach-Object {[pscustomobject]@{path=$_.FullName.Substring($driver.Length+1).Replace('\','/');bytes=$_.Length;sha256=(Get-FileHash -LiteralPath $_.FullName).Hash.ToLowerInvariant()}})
$manifest|ConvertTo-Json -Depth 8|Set-Content -LiteralPath $manifestPath -Encoding UTF8
$files=@(Get-ChildItem -LiteralPath $Release -File -Recurse|Where-Object {$_.Name -ne 'APP-SHA256.json'}|ForEach-Object {[ordered]@{path=$_.FullName.Substring($Release.Length+1).Replace('\','/');bytes=$_.Length;sha256=(Get-FileHash -LiteralPath $_.FullName).Hash.ToLowerInvariant()}})
[ordered]@{version='1.0.5';driver='QISP253 / SYS080 / MFT075b';files=$files}|ConvertTo-Json -Depth 5|Set-Content -LiteralPath (Join-Path $Release 'APP-SHA256.json') -Encoding UTF8
