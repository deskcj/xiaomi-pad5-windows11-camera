﻿# Remove only OEM packages whose complete model list targets these camera devices.
# Platform/JPEG/flash/SMMU/display packages and packages referenced by any device are retained.
function Get-CameraPackageModels([string]$Text){
 $sections=@{};$section=''
 foreach($raw in ($Text -split '\r?\n')){$line=($raw -split ';',2)[0].Trim();if($line -match '^\[([^]]+)\]$'){$section=$Matches[1];if(-not $sections.ContainsKey($section)){$sections[$section]=@()}}elseif($line -and $section){$sections[$section]+=$line}}
 if(-not $sections.ContainsKey('Version') -or -not $sections.ContainsKey('Manufacturer')){return @()}
 $class=@($sections['Version']|Where-Object {$_ -match '^Class\s*=\s*"?(Camera|System|Extension)"?\s*$'});if(-not $class.Count){return @()}
 $modelSections=@();foreach($line in $sections['Manufacturer']){if($line -notmatch '=\s*([^,]+)'){return @()};$base=$Matches[1].Trim().Trim('"');$modelSections+=@($sections.Keys|Where-Object {$_ -ieq $base -or $_.StartsWith($base+'.',[StringComparison]::OrdinalIgnoreCase)})}
 $models=@();foreach($name in ($modelSections|Sort-Object -Unique)){foreach($line in $sections[$name]){if($line -notmatch '=\s*[^,]+,(.+)$'){return @()};foreach($value in ($Matches[1] -split ',')){$id=$value.Trim().Trim('"');if($id -notmatch '^(?i:ACPI\\(?:QCOM(?:0528|05A4|0506|0529)|VEN_QCOM&DEV_(?:0528|05A4|0506|0529))(?:&SUBSYS_[A-Z0-9]+)?|VIDEO\\QCOM_AVStream_8150|ROOT\\NABUCAMVIRTUAL(?:FRONT|REAR))$'){return @()};$models+=$id}}}
 return @($models|Sort-Object -Unique)
}
function Get-ReferencedDriverInfs {
 $referenced=@{};foreach($device in @(Get-PnpDevice -ErrorAction Stop)){$key=Get-Item -LiteralPath ('Registry::HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Enum\'+$device.InstanceId) -ErrorAction SilentlyContinue;if(-not $key){continue};$driver=$key.GetValue('Driver','');if($driver){$class=Get-Item -LiteralPath ('Registry::HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\Class\'+$driver) -ErrorAction SilentlyContinue;if($class){$inf=[string]$class.GetValue('InfPath','');if($inf){$referenced[$inf.ToLowerInvariant()]=$true}}}}
 return $referenced
}
function Get-UnusedCameraPackages {
 $referenced=Get-ReferencedDriverInfs
 foreach($inf in @(Get-ChildItem -LiteralPath (Join-Path $env:windir 'INF') -Filter 'oem*.inf' -File)){
  if($referenced.ContainsKey($inf.Name.ToLowerInvariant())){continue}
  $models=@(Get-CameraPackageModels ([IO.File]::ReadAllText($inf.FullName)));if($models.Count){[pscustomobject]@{inf=$inf.Name;models=$models;sha256=(Get-FileHash -LiteralPath $inf.FullName).Hash}}
 }
}
function Remove-UnusedCameraPackages([string]$LogRoot){
 New-Item -ItemType Directory -Path $LogRoot -Force|Out-Null;$report=[ordered]@{status='COMPLETE';removed=@();retained=@();rebootRequired=$false;forceUsed=$false}
 foreach($candidate in @(Get-UnusedCameraPackages)){
  $path=Join-Path (Join-Path $env:windir 'INF') $candidate.inf
  if(-not(Test-Path -LiteralPath $path) -or (Get-FileHash -LiteralPath $path).Hash -ne $candidate.sha256 -or (Get-ReferencedDriverInfs).ContainsKey($candidate.inf.ToLowerInvariant())){$report.retained+=@([ordered]@{inf=$candidate.inf;reason='Package changed or is referenced by a device'});continue}
  $out=Join-Path $LogRoot ($candidate.inf+'.out.log');$err=Join-Path $LogRoot ($candidate.inf+'.err.log')
  $p=Start-Process -FilePath (Join-Path $env:windir 'System32\pnputil.exe') -ArgumentList @('/delete-driver',$candidate.inf) -WindowStyle Hidden -PassThru -RedirectStandardOutput $out -RedirectStandardError $err;$null=$p.Handle;if(-not $p.WaitForExit(90000)){$report.status='PENDING_PROCESS';$report.pendingPid=$p.Id;$report.pendingCreation=$p.StartTime.ToString('o');break};$p.WaitForExit();$p.Refresh()
  if($p.ExitCode -in 3010,3011){$report.rebootRequired=$true}
  if(-not(Test-Path -LiteralPath $path)){$report.removed+=@($candidate.inf)}else{$report.retained+=@([ordered]@{inf=$candidate.inf;reason='Windows retained an in-use or protected package';code=$p.ExitCode});$report.status='RETAINED_BY_WINDOWS'}
 }
 [IO.File]::WriteAllText((Join-Path $LogRoot 'packages.json'),($report|ConvertTo-Json -Depth 6),[Text.UTF8Encoding]::new($false));return $report
}
