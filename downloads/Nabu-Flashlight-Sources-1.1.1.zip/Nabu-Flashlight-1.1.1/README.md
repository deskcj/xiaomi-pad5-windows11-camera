# Nabu Light 1.1.1

Portable flashlight for Xiaomi Pad 5 on Windows 11 ARM64.

Run `Nabu-Flashlight.exe` without administrator access. The app opens in a
compact window. Settings expands the window for Morse speed, message,
brightness and the automatic off timer. Choosing Morse opens these settings.

Modes: steady, blink, fast blink, SOS and a custom Russian/English Morse
message. Space switches the light on/off; Escape turns it off. Closing the
app also turns it off. Theme defaults to Windows; the theme button cycles
system/light/dark. EN/RU switches the interface language.

Brightness is available only if the installed camera driver supports it.
The current Qualcomm ISP driver exposes fixed torch brightness.

The Developer button opens https://t.me/deskcj. While a blinking or Morse mode
is running, the power button and running status stay steadily lit; the selected
mode remains visible. Only the physical LED follows the light pattern.

## 2026-11-07 — 1.1.1

- Added a Developer button to the top of the compact window.
- Kept the power icon and running status steady during blink, fast blink,
  SOS and Morse modes.
- Displayed the selected mode consistently without flashing pulse symbols.

## 2026-11-07 — 1.1

- Smaller default window and power button; no scrolling in the normal view.
- Advanced settings hidden by default and shown in the same window.
- Compact window has a fixed width and expands vertically for settings.
- Visible version in the window and EXE properties.
- Existing torch control and light patterns retained.

## Build

Extract the complete source ZIP, including the empty release folder, and run:

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File src\Build.ps1
```

Windows .NET Framework and the installed Windows WinRT metadata are used.
The output is `release\Nabu-Flashlight.exe`.

Developer: https://t.me/deskcj
