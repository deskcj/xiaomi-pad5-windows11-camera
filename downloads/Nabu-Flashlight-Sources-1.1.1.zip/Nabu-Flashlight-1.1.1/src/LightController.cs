using System;
using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Threading;
using System.Threading.Tasks;

namespace NabuLight {
 public sealed class LightController {
  readonly SemaphoreSlim commands=new SemaphoreSlim(1,1);
  CancellationTokenSource cancellation; Task run; readonly TorchSession session=new TorchSession();
  [DllImport("kernel32.dll")] static extern uint SetThreadExecutionState(uint flags);
  public event Action<bool,string> LightChanged;
  public event Action<Exception> Failed;
  public event Action Completed;
  public volatile bool Running;
  public bool PowerSupported { get { return session.PowerSupported; } }
  public long Frames { get { return session.Frames; } }
  public bool OffConfirmed { get { return session.OffConfirmed; } }
  public bool ClosedConfirmed { get { return session.ClosedConfirmed; } }
  public TimeSpan Elapsed { get { return elapsed.Elapsed; } }
  readonly Stopwatch elapsed=new Stopwatch();
  public async Task StartAsync(LightMode mode,int unit,string message,int power,int minutes) {
   Pulse[] pulses=Patterns.Get(mode,message);
   await commands.WaitAsync();
   try {
    Exception failure=null;
    try {
     await EndPatternAsync();
     if(!session.IsOpen) await Task.Run(()=>session.OpenAsync(power));
     else await Task.Run(()=>session.SetPower(power));
     cancellation=new CancellationTokenSource();Running=true;elapsed.Restart();
     var token=cancellation.Token;
     run=Task.Run(()=>RunAsync(mode,pulses,Math.Max(180,unit),minutes,token));
    } catch(Exception e) { failure=e; }
    if(failure!=null) {
     Running=false;
     try { await Task.Run(()=>session.CloseAsync()); } catch(Exception close) { throw new AggregateException(failure,close); }
     throw failure;
    }
   } finally { commands.Release(); }
  }
  async Task EndPatternAsync() {
   if(cancellation!=null) cancellation.Cancel();
   if(run!=null) { try { await run; } catch(OperationCanceledException) { } run=null; }
   if(cancellation!=null) { cancellation.Dispose();cancellation=null; }
   Running=false;elapsed.Stop();
  }
  async Task RunAsync(LightMode mode,Pulse[] pulses,int unit,int minutes,CancellationToken token) {
   Exception failure=null;bool expired=false;
   // The UI timer owns the keep-awake request while this asynchronous loop runs.
   try {
    if(mode==LightMode.Steady) {
     session.Set(true);Notify(true,"");
     while(true) { token.ThrowIfCancellationRequested(); if(minutes>0 && elapsed.Elapsed.TotalMinutes>=minutes) { expired=true;break; } await Task.Delay(100,token); }
    } else {
     int index=0;
     while(true) {
      token.ThrowIfCancellationRequested();
      if(minutes>0 && elapsed.Elapsed.TotalMinutes>=minutes) { expired=true;break; }
      Pulse pulse=pulses[index];session.Set(pulse.On);Notify(pulse.On,pulse.Symbol);
      int duration=(mode==LightMode.Blink?700:mode==LightMode.FastBlink?250:unit)*pulse.Units;
      await Task.Delay(duration,token); index=(index+1)%pulses.Length;
     }
    }
   } catch(OperationCanceledException) { }
     catch(Exception e) { failure=e; }
   finally {
    try { session.Set(false); } catch(Exception e) { failure=failure??e; }
    Notify(false,"");
   }
   if(expired || failure!=null) {
    try { await session.CloseAsync(); } catch(Exception e) { failure=failure??e; }
    Running=false;elapsed.Stop();
    if(failure!=null) { var handler=Failed;if(handler!=null) handler(failure); }
    else { var handler=Completed;if(handler!=null) handler(); }
   }
  }
  void Notify(bool on,string symbol) { var handler=LightChanged;if(handler!=null) handler(on,symbol); }
  public async Task StopAsync() {
   await commands.WaitAsync();
   try { await EndPatternAsync();await Task.Run(()=>session.CloseAsync()); }
   finally { commands.Release(); }
  }
  public async Task ChangePowerAsync(int power) {
   await commands.WaitAsync();try { if(session.IsOpen) await Task.Run(()=>session.SetPower(power)); } finally { commands.Release(); }
  }
  public static void KeepAwake(bool enabled) { SetThreadExecutionState(enabled?0x80000003:0x80000000); }
 }
}
