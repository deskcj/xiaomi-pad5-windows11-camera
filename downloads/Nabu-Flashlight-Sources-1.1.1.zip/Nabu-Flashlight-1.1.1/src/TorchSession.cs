using System;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Windows.Devices.Enumeration;
using Windows.Foundation;
using Windows.Graphics.Imaging;
using Windows.Media.Capture;
using Windows.Media.Capture.Frames;
using Windows.Media.Devices;

namespace NabuLight {
 public sealed class TorchSession {
  MediaCapture capture; MediaFrameReader reader; TorchControl torch;
  bool started,powerChanged; float originalPower; int handling; volatile bool closing;
  long frames; Exception frameError; public bool IsOpen { get { return torch!=null && started; } }
  public bool PowerSupported { get; private set; }
  public bool OffConfirmed { get; private set; }
  public bool ClosedConfirmed { get; private set; }
  public long Frames { get { return Interlocked.Read(ref frames); } }
  static Task<T> Await<T>(IAsyncOperation<T> op) {
   var t=new TaskCompletionSource<T>(); op.Completed=(a,s)=>{try{t.TrySetResult(a.GetResults());}catch(Exception e){t.TrySetException(e);}};return t.Task;
  }
  static Task Await(IAsyncAction op) {
   var t=new TaskCompletionSource<bool>();op.Completed=(a,s)=>{try{a.GetResults();t.TrySetResult(true);}catch(Exception e){t.TrySetException(e);}};return t.Task;
  }
  public async Task OpenAsync(int power) {
   if(capture!=null) throw new InvalidOperationException("PREVIOUS_OWNER_OPEN");
   closing=false;frames=0;frameError=null;OffConfirmed=false;ClosedConfirmed=false;PowerSupported=false;
   var cameras=await Await(DeviceInformation.FindAllAsync(DeviceClass.VideoCapture));
   var rear=cameras.Where(d=>d.IsEnabled && d.Id.IndexOf("DISPLAY#QCOM_AVStream_8150#",StringComparison.OrdinalIgnoreCase)>=0 && d.Id.EndsWith("\\{5584F823-3830-4CFD-947F-78DE17A8B14C}",StringComparison.OrdinalIgnoreCase)).ToArray();
   if(rear.Length!=1) throw new InvalidOperationException("NO_REAR_CAMERA");
   capture=new MediaCapture();
   var settings=new MediaCaptureInitializationSettings { VideoDeviceId=rear[0].Id,StreamingCaptureMode=StreamingCaptureMode.Video,SharingMode=MediaCaptureSharingMode.ExclusiveControl,MemoryPreference=MediaCaptureMemoryPreference.Cpu };
   await Await(capture.InitializeAsync(settings));
   torch=capture.VideoDeviceController.TorchControl;
   if(torch==null || !torch.Supported) throw new NotSupportedException("NO_TORCH_CONTROL");
   if(torch.Enabled) throw new InvalidOperationException("TORCH_ALREADY_OWNED");
   PowerSupported=torch.PowerSupported;
   if(PowerSupported) {
    originalPower=torch.PowerPercent;
    if(float.IsNaN(originalPower) || originalPower<0 || originalPower>100) throw new InvalidOperationException("INVALID_POWER");
    powerChanged=true; torch.PowerPercent=Math.Max(10,Math.Min(100,power));
   }
   var source=capture.FrameSources.Values.FirstOrDefault(s=>s.Info.SourceKind==MediaFrameSourceKind.Color && s.Info.MediaStreamType==MediaStreamType.VideoPreview)
    ?? capture.FrameSources.Values.FirstOrDefault(s=>s.Info.SourceKind==MediaFrameSourceKind.Color);
   if(source==null) throw new InvalidOperationException("NO_PREVIEW_SOURCE");
   reader=await Await(capture.CreateFrameReaderAsync(source,"NV12",new BitmapSize { Width=320,Height=180 }));
   reader.AcquisitionMode=MediaFrameReaderAcquisitionMode.Realtime; reader.FrameArrived+=OnFrame;
   var status=await Await(reader.StartAsync());
   if(status!=MediaFrameReaderStartStatus.Success) throw new InvalidOperationException("READER_START:"+status);
   started=true;
   for(int i=0;i<50 && Frames==0;i++) { await Task.Delay(100); if(frameError!=null) throw frameError; }
   if(Frames==0) throw new InvalidOperationException("NO_CAMERA_FRAMES");
   Set(false);
  }
  void OnFrame(MediaFrameReader sender,MediaFrameArrivedEventArgs args) {
   if(closing || Interlocked.Exchange(ref handling,1)!=0) return;
   try { using(var frame=sender.TryAcquireLatestFrame()) {
    if(frame!=null && frame.VideoMediaFrame!=null) {
     using(var image=frame.VideoMediaFrame.SoftwareBitmap) { if(image!=null) Interlocked.Increment(ref frames); }
    }
   }} catch(Exception e) { frameError=e; } finally { Interlocked.Exchange(ref handling,0); }
  }
  public bool Set(bool on) {
   if(torch==null) { if(on) throw new InvalidOperationException("TORCH_NOT_OPEN"); return false; }
   torch.Enabled=on; bool readback=torch.Enabled;
   if(readback!=on) throw new InvalidOperationException("TORCH_READBACK_MISMATCH");
   if(!on) OffConfirmed=true; else OffConfirmed=false;
   return readback;
  }
  public void SetPower(int value) { if(torch!=null && PowerSupported) torch.PowerPercent=Math.Max(10,Math.Min(100,value)); }
  public async Task CloseAsync() {
   closing=true;Exception error=null;
   if(torch!=null) {
    try { Set(false); } catch(Exception e) { error=e; }
    if(powerChanged) try { torch.PowerPercent=originalPower;powerChanged=false; } catch(Exception e) { error=error??e; }
   }
   if(reader!=null) {
    reader.FrameArrived-=OnFrame;
    try { if(started) { await Await(reader.StopAsync());started=false; } } catch(Exception e) { error=error??e; }
    try { reader.Dispose();reader=null; } catch(Exception e) { error=error??e; }
   }
   if(capture!=null) try { capture.Dispose();capture=null;torch=null; } catch(Exception e) { error=error??e; }
   ClosedConfirmed=capture==null && reader==null;
   if(error!=null) throw new InvalidOperationException("LIGHT_CLOSE_FAILED: "+error.Message,error);
  }
 }
}
