param([switch]$CopyToDesktop)
$ErrorActionPreference='Stop'
$project=Split-Path -Parent $PSScriptRoot
. (Join-Path $PSScriptRoot 'WinRT-References.ps1')
$arguments=@('/nologo','/target:winexe','/platform:anycpu','/optimize+','/reference:System.Core.dll','/reference:System.Windows.Forms.dll','/reference:System.Drawing.dll','/reference:System.Web.Extensions.dll',('/win32manifest:'+(Join-Path $PSScriptRoot 'app.manifest')),('/out:'+(Join-Path $project 'release\Nabu-Flashlight.exe')))+(Get-CameraWinRTReferences)+@(Get-ChildItem -LiteralPath $PSScriptRoot -Filter '*.cs' | ForEach-Object {$_.FullName})
if(Test-Path -LiteralPath (Join-Path $PSScriptRoot 'app.ico')) { $arguments+=('/win32icon:'+(Join-Path $PSScriptRoot 'app.ico'));$arguments+=('/resource:'+(Join-Path $PSScriptRoot 'app.ico')+',NabuLight.Icon') }
& "$env:windir\Microsoft.NET\Framework64\v4.0.30319\csc.exe" @arguments
if($LASTEXITCODE -ne 0) { throw 'Nabu Light compilation failed' }
if($CopyToDesktop) { Copy-Item -LiteralPath (Join-Path $project 'release\Nabu-Flashlight.exe') -Destination (Join-Path ([Environment]::GetFolderPath('Desktop')) 'Nabu-Flashlight.exe') -Force }
Get-FileHash -LiteralPath (Join-Path $project 'release\Nabu-Flashlight.exe') -Algorithm SHA256
