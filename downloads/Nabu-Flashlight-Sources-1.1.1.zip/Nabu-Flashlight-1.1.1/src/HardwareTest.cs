using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Web.Script.Serialization;

namespace NabuLight {
 static class HardwareTest {
  static void Save(string path,object value) { File.WriteAllText(Path.GetFullPath(path),new JavaScriptSerializer().Serialize(value)); }
  public static int TestPatterns(string output) {
   var checks=new List<string>();
   Action<bool,string> verify=(ok,name)=>{if(!ok)throw new Exception(name);checks.Add(name);};
   try {
    verify(Patterns.Encode("SOS")=="... --- ...","SOS encoding");
    var sos=Patterns.Morse("SOS");verify(sos.Count(p=>p.On)==9,"Nine SOS marks");
    verify(sos.Where(p=>p.On).Sum(p=>p.Units)==15,"SOS dot and dash lengths");
    verify(sos.Sum(p=>p.Units)==34,"SOS spacing: 1/3/7 units");
    verify(Patterns.Encode("ПРИВЕТ")==".--. .-. .. .-- . -","Russian Morse");
    verify(Patterns.Encode("ёЁ")==". .","Russian Yo normalized");
    verify(Patterns.Morse("A B").Count(p=>!p.On&&p.Units==7)==2,"Word and repeated-message gaps");
    verify(Patterns.Encode("A  B")==".- / -...","Whitespace normalization");
    verify(Patterns.Encode("123")==".---- ..--- ...--","Digits");
    foreach(LightMode mode in Enum.GetValues(typeof(LightMode))) {
     var pattern=Patterns.Get(mode,"OK");verify(mode==LightMode.Steady || (pattern.Length>0&&!pattern.Last().On),mode+" ends with OFF");
    }
    bool empty=false,invalid=false;try{Patterns.Morse(" ");}catch(ArgumentException){empty=true;}try{Patterns.Morse("🙂");}catch(ArgumentException){invalid=true;}
    verify(empty,"Empty text rejected");verify(invalid,"Unknown character rejected");
    Save(output,new {status="PASS",checks=checks,count=checks.Count});return 0;
   } catch(Exception e) {Save(output,new {status="FAIL",checks=checks,error=e.ToString()});return 1;}
  }
  public static int Run(string output) {
   bool owns;using(var mutex=new Mutex(true,@"Local\deskcj.NabuLight",out owns)) {
    if(!owns) {Save(output,new{status="FAIL",error="Nabu Light is already running"});return 2;}
    return Task.Run(async()=> {
     var controller=new LightController();var events=new List<object>();var errors=new List<string>();var sync=new object();
     controller.LightChanged+=(on,symbol)=>{lock(sync)events.Add(new{on=on,symbol=symbol,time=DateTime.UtcNow.ToString("o")});};
     controller.Failed+=e=>{lock(sync)errors.Add(e.ToString());};var started=DateTime.UtcNow;bool firstStop=false,reopenStop=false;long firstFrames=0,reopenFrames=0;
     try {
      foreach(LightMode mode in new[]{LightMode.Steady,LightMode.Blink,LightMode.FastBlink,LightMode.SOS,LightMode.Morse}) {
       await controller.StartAsync(mode,180,"OK",20,0);
       await Task.Delay(mode==LightMode.SOS?6200:mode==LightMode.Morse?2500:1600);
       if(!controller.Running)throw new Exception("Stopped unexpectedly in "+mode);
      }
      firstFrames=controller.Frames;await controller.StopAsync();firstStop=controller.OffConfirmed&&controller.ClosedConfirmed;
      if(!firstStop)throw new Exception("First OFF and close not confirmed");
      // A second complete owner detects leaked exclusive camera handles.
      await controller.StartAsync(LightMode.Steady,180,"SOS",20,0);await Task.Delay(700);reopenFrames=controller.Frames;
      var clock=Stopwatch.StartNew();await controller.StopAsync();clock.Stop();
      reopenStop=controller.OffConfirmed&&controller.ClosedConfirmed;
      if(!reopenStop || firstFrames==0 || reopenFrames==0)throw new Exception("Reopen/OFF/frame check failed");
      lock(sync) { if(errors.Count>0)throw new Exception(string.Join("; ",errors)); }
      Save(output,new {status="PASS",started=started.ToString("o"),completed=DateTime.UtcNow.ToString("o"),powerSupported=controller.PowerSupported,firstFrames=firstFrames,reopenFrames=reopenFrames,firstOffAndClose=firstStop,reopenOffAndClose=reopenStop,stopMs=clock.ElapsedMilliseconds,events=events,errors=errors,driverChanges=false,filesSaved="report only; no camera images"});return 0;
     } catch(Exception e) { errors.Add(e.ToString()); }
     try{await controller.StopAsync();}catch(Exception close){errors.Add(close.ToString());}
     Save(output,new {status="FAIL",started=started.ToString("o"),completed=DateTime.UtcNow.ToString("o"),firstFrames=firstFrames,offConfirmed=controller.OffConfirmed,closedConfirmed=controller.ClosedConfirmed,events=events,errors=errors});return 1;
    }).GetAwaiter().GetResult();
   }
  }
 }
}
