using System;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Threading;
using System.Threading.Tasks;
using System.Web.Script.Serialization;
using System.Windows.Forms;
using Microsoft.Win32;

[assembly: AssemblyTitle("Nabu Light — Xiaomi Pad 5 Flashlight")]
[assembly: AssemblyDescription("Portable torch, blinking and Morse light for Xiaomi Pad 5")]
[assembly: AssemblyCompany("deskcj")]
[assembly: AssemblyProduct("Nabu Light")]
[assembly: AssemblyVersion("1.1.1.0")]
[assembly: AssemblyFileVersion("1.1.1.0")]

namespace NabuLight {
 static class Theme {
  public static bool Dark=true;
  public static Color Background,Card,Text,Muted,Accent,Selected,Amber=Color.FromArgb(255,209,131),Border;
  static Theme() { Apply(true); }
  public static void Apply(bool dark) { Dark=dark;Background=dark?Color.FromArgb(13,20,30):Color.FromArgb(244,247,250);Card=dark?Color.FromArgb(23,34,48):Color.White;Text=dark?Color.FromArgb(241,246,251):Color.FromArgb(26,40,53);Muted=dark?Color.FromArgb(155,172,191):Color.FromArgb(94,111,128);Accent=dark?Color.FromArgb(113,227,195):Color.FromArgb(20,119,94);Selected=dark?Color.FromArgb(31,65,62):Color.FromArgb(227,245,237);Border=dark?Color.FromArgb(44,61,77):Color.FromArgb(209,221,231); }
  public static GraphicsPath Round(RectangleF r,float radius) { var path=new GraphicsPath();float d=radius*2;path.AddArc(r.X,r.Y,d,d,180,90);path.AddArc(r.Right-d,r.Y,d,d,270,90);path.AddArc(r.Right-d,r.Bottom-d,d,d,0,90);path.AddArc(r.X,r.Bottom-d,d,d,90,90);path.CloseFigure();return path; }
  public static Font Font(float size,FontStyle style) { return new Font("Segoe UI",size,style); }
 }
 sealed class FlatButton:Button {
  public bool Selected;
  public FlatButton() { SetStyle(ControlStyles.UserPaint|ControlStyles.AllPaintingInWmPaint|ControlStyles.OptimizedDoubleBuffer,true);FlatStyle=FlatStyle.Flat;FlatAppearance.BorderSize=0;Font=Theme.Font(10,FontStyle.Regular);ForeColor=Theme.Text;BackColor=Theme.Background;Cursor=Cursors.Hand; }
  protected override void OnPaint(PaintEventArgs e) {
   e.Graphics.Clear(BackColor);
   e.Graphics.SmoothingMode=SmoothingMode.AntiAlias;
   var bounds=new RectangleF(1,1,Width-3,Height-3);
   using(var shape=Theme.Round(bounds,10)) using(var brush=new SolidBrush(Selected?Theme.Selected:Theme.Card)) using(var pen=new Pen(Selected?Theme.Accent:Theme.Border,Selected?1.7f:1)) { e.Graphics.FillPath(brush,shape);e.Graphics.DrawPath(pen,shape); }
   TextRenderer.DrawText(e.Graphics,Text,Font,new Rectangle(8,3,Width-16,Height-6),Enabled?(Selected?Theme.Accent:Theme.Text):Theme.Muted,TextFormatFlags.HorizontalCenter|TextFormatFlags.VerticalCenter|TextFormatFlags.EndEllipsis);
   if(Focused) using(var pen=new Pen(Theme.Muted,1)) { pen.DashStyle=DashStyle.Dot;e.Graphics.DrawRectangle(pen,5,5,Width-11,Height-11); }
  }
  protected override void OnPaintBackground(PaintEventArgs e) { e.Graphics.Clear(BackColor); }
 }
 sealed class PowerButton:Button {
  public bool Lit;public string Caption="TURN ON";
  public PowerButton() { SetStyle(ControlStyles.UserPaint|ControlStyles.AllPaintingInWmPaint|ControlStyles.OptimizedDoubleBuffer,true);FlatStyle=FlatStyle.Flat;FlatAppearance.BorderSize=0;Cursor=Cursors.Hand;BackColor=Theme.Background;AccessibleRole=AccessibleRole.PushButton; }
  protected override void OnPaint(PaintEventArgs e) {
   e.Graphics.Clear(BackColor);
   var g=e.Graphics;g.SmoothingMode=SmoothingMode.AntiAlias;
   float scale=g.DpiX/96f;float diameter=Math.Min(Width,Height)-12*scale;var circle=new RectangleF((Width-diameter)/2,(Height-diameter)/2,diameter,diameter);
   using(var brush=new LinearGradientBrush(circle,Lit?Theme.Amber:Theme.Dark?Color.FromArgb(40,59,74):Color.FromArgb(234,246,242),Lit?Color.FromArgb(218,157,73):Theme.Dark?Color.FromArgb(23,36,49):Color.FromArgb(214,232,225),45))g.FillEllipse(brush,circle);
   using(var pen=new Pen(Lit?Color.FromArgb(255,227,178):Theme.Border,2))g.DrawEllipse(pen,circle);
   float x=Width/2f,y=Height/2f-10*scale;Color ink=Lit?Color.FromArgb(51,40,24):Theme.Accent;
   using(var pen=new Pen(ink,3*scale)) { pen.StartCap=pen.EndCap=LineCap.Round;g.DrawArc(pen,x-17*scale,y-17*scale,34*scale,34*scale,-48,276);g.DrawLine(pen,x,y-23*scale,x,y-5*scale); }
   using(var font=Theme.Font(8,FontStyle.Bold)) TextRenderer.DrawText(g,Caption,font,new Rectangle((int)(6*scale),(int)(y+23*scale),Width-(int)(12*scale),(int)(25*scale)),ink,TextFormatFlags.HorizontalCenter|TextFormatFlags.VerticalCenter|TextFormatFlags.EndEllipsis);
   if(Focused) using(var pen=new Pen(Theme.Text,1)) { pen.DashStyle=DashStyle.Dot;g.DrawEllipse(pen,circle.X+7,circle.Y+7,circle.Width-14,circle.Height-14); }
  }
  protected override void OnPaintBackground(PaintEventArgs e) { e.Graphics.Clear(BackColor); }
 }
 sealed class MainForm:Form {
  readonly LightController controller=new LightController();
  readonly TableLayoutPanel root=new TableLayoutPanel();
  readonly Label title=new Label(),subtitle=new Label(),state=new Label(),modeText=new Label(),elapsed=new Label(),hint=new Label(),modesTitle=new Label(),powerTitle=new Label(),speedTitle=new Label(),textTitle=new Label(),timerTitle=new Label(),footer=new Label(),powerValue=new Label(),speedValue=new Label();
  readonly FlatButton language=new FlatButton(),themeChoice=new FlatButton(),options=new FlatButton(),developer=new FlatButton();readonly PowerButton toggle=new PowerButton();
  readonly Panel scroll=new Panel();readonly TableLayoutPanel advanced=new TableLayoutPanel();
  readonly FlatButton[] modes=new FlatButton[5];
  readonly TrackBar power=new TrackBar(),speed=new TrackBar();readonly TextBox morse=new TextBox();readonly ComboBox timer=new ComboBox();
  readonly System.Windows.Forms.Timer refresh=new System.Windows.Forms.Timer();
  LightMode mode=LightMode.Steady;bool ru=CultureInfo.CurrentUICulture.TwoLetterISOLanguageName=="ru",busy,closing,closed;
  string error="";bool adjustableKnown,optionsExpanded;int themeMode,maxContentWidth,advancedRow;float uiScale=1;
  string L(string russian,string english) { return ru?russian:english; }
  public MainForm() {
   SuspendLayout();
   Text="Nabu Light 1.1.1";BackColor=Theme.Background;ForeColor=Theme.Text;Font=Theme.Font(10,FontStyle.Regular);
   AutoScaleMode=AutoScaleMode.None;ClientSize=new Size(420,360);MinimumSize=new Size(400,360);StartPosition=FormStartPosition.CenterScreen;KeyPreview=true;MaximizeBox=false;FormBorderStyle=FormBorderStyle.FixedSingle;
   using(var stream=Assembly.GetExecutingAssembly().GetManifestResourceStream("NabuLight.Icon")) { if(stream!=null)Icon=new Icon(stream); }
   root.ColumnCount=1;root.AutoSize=false;root.Padding=new Padding(16,12,16,12);root.BackColor=Theme.Background;
   scroll.Dock=DockStyle.Fill;scroll.AutoScroll=true;scroll.BackColor=Theme.Background;scroll.Controls.Add(root);Controls.Add(scroll);
   var header=new TableLayoutPanel { ColumnCount=4,Dock=DockStyle.Fill,Margin=new Padding(0),Height=48 };header.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,100));header.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute,100));header.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute,80));header.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute,44));
   var names=new TableLayoutPanel { RowCount=2,ColumnCount=1,Dock=DockStyle.Fill,Margin=new Padding(0) };
   names.RowStyles.Add(new RowStyle(SizeType.Absolute,28));names.RowStyles.Add(new RowStyle(SizeType.Percent,100));
   title.Font=Theme.Font(16,FontStyle.Bold);title.Text="Nabu Light";subtitle.Font=Theme.Font(8,FontStyle.Regular);subtitle.ForeColor=Theme.Muted;names.Controls.Add(title);names.Controls.Add(subtitle);title.Dock=subtitle.Dock=DockStyle.Fill;title.Margin=subtitle.Margin=new Padding(0);
   language.Dock=DockStyle.Top;language.Height=30;language.Margin=new Padding(4,3,0,0);language.Click+=(s,e)=>{ru=!ru;Localize();};themeChoice.Dock=DockStyle.Top;themeChoice.Height=30;themeChoice.Font=Theme.Font(9,FontStyle.Regular);themeChoice.Margin=new Padding(0,3,4,0);themeChoice.Click+=(s,e)=>{themeMode=(themeMode+1)%3;ApplyTheme();};developer.Dock=DockStyle.Top;developer.Height=30;developer.Margin=new Padding(0,3,4,0);developer.Font=Theme.Font(9,FontStyle.Regular);developer.Click+=(s,e)=>OpenDeveloper();header.Controls.Add(names,0,0);header.Controls.Add(developer,1,0);header.Controls.Add(themeChoice,2,0);header.Controls.Add(language,3,0);Add(header,48);
   var hero=new TableLayoutPanel { Dock=DockStyle.Fill,ColumnCount=2,Margin=new Padding(0,0,0,8) };hero.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute,116));hero.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,100));
   toggle.Dock=DockStyle.Fill;toggle.Margin=new Padding(0,4,8,4);toggle.Click+=async(s,e)=>await ToggleAsync();hero.Controls.Add(toggle,0,0);
   var status=new TableLayoutPanel { Dock=DockStyle.Fill,ColumnCount=1,RowCount=4,Margin=new Padding(8,8,0,0) };
   status.RowStyles.Add(new RowStyle(SizeType.Absolute,30));status.RowStyles.Add(new RowStyle(SizeType.Absolute,22));status.RowStyles.Add(new RowStyle(SizeType.Absolute,24));status.RowStyles.Add(new RowStyle(SizeType.Percent,100));
   state.Font=Theme.Font(16,FontStyle.Bold);modeText.Font=Theme.Font(10,FontStyle.Regular);modeText.ForeColor=Theme.Muted;elapsed.Font=Theme.Font(10,FontStyle.Regular);elapsed.ForeColor=Theme.Accent;hint.ForeColor=Theme.Muted;hint.Font=Theme.Font(8,FontStyle.Regular);
   foreach(var label in new[]{state,modeText,elapsed,hint}) { label.Dock=DockStyle.Fill;label.Margin=new Padding(0);status.Controls.Add(label); }
   hero.Controls.Add(status,1,0);Add(hero,128);
   modesTitle.Font=Theme.Font(9,FontStyle.Bold);modesTitle.Dock=DockStyle.Fill;Add(modesTitle,20);
   var grid=new TableLayoutPanel { Dock=DockStyle.Fill,ColumnCount=3,RowCount=2,Margin=new Padding(0,0,0,8) };
   for(int i=0;i<3;i++)grid.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,33.333f));grid.RowStyles.Add(new RowStyle(SizeType.Percent,50));grid.RowStyles.Add(new RowStyle(SizeType.Percent,50));
   for(int i=0;i<5;i++) { int selected=i;modes[i]=new FlatButton { Dock=DockStyle.Fill,Margin=new Padding(i%3==0?0:5,3,i%3==2?0:5,3) };modes[i].Click+=async(s,e)=>await SelectModeAsync((LightMode)selected);grid.Controls.Add(modes[i],i<3?i:i-3,i<3?0:1); }
   grid.SetColumnSpan(modes[4],2);Add(grid,80);
   options.Dock=DockStyle.Fill;options.Margin=new Padding(0,0,0,4);options.Font=Theme.Font(9,FontStyle.Regular);options.Click+=(s,e)=>SetOptions(!optionsExpanded);Add(options,32);
   advanced.ColumnCount=1;advanced.RowCount=2;advanced.Dock=DockStyle.Fill;advanced.Margin=new Padding(0);advanced.RowStyles.Add(new RowStyle(SizeType.Percent,50));advanced.RowStyles.Add(new RowStyle(SizeType.Percent,50));advancedRow=root.RowCount;Add(advanced,0);advanced.Visible=false;
   var custom=new TableLayoutPanel { ColumnCount=2,RowCount=3,Dock=DockStyle.Fill,Margin=new Padding(0,6,0,0) };custom.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,55));custom.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,45));
   speedTitle.Dock=textTitle.Dock=DockStyle.Fill;speedTitle.ForeColor=textTitle.ForeColor=Theme.Muted;
   custom.RowStyles.Add(new RowStyle(SizeType.Absolute,24));custom.RowStyles.Add(new RowStyle(SizeType.Absolute,36));custom.RowStyles.Add(new RowStyle(SizeType.Absolute,22));
   custom.Controls.Add(speedTitle,0,0);custom.Controls.Add(textTitle,1,0);
   speed.Minimum=180;speed.Maximum=800;speed.Value=250;speed.TickStyle=TickStyle.None;speed.SmallChange=10;speed.LargeChange=50;speed.Dock=DockStyle.Fill;speed.BackColor=Theme.Background;speed.Margin=new Padding(0,0,16,0);speed.AccessibleName="Morse speed";
   speed.ValueChanged+=(s,e)=>{RefreshState();};speed.MouseUp+=async(s,e)=>{if(controller.Running && !busy)await RestartAsync();};speed.KeyUp+=async(s,e)=>{if(controller.Running && !busy)await RestartAsync();};custom.Controls.Add(speed,0,1);
   morse.Text="SOS";morse.MaxLength=60;morse.BackColor=Theme.Card;morse.ForeColor=Theme.Text;morse.Font=Theme.Font(12,FontStyle.Regular);morse.BorderStyle=BorderStyle.FixedSingle;morse.Dock=DockStyle.Fill;morse.Margin=new Padding(0,3,0,0);morse.AccessibleName="Morse message";
   morse.TextChanged+=(s,e)=>{RefreshState();};morse.KeyDown+=async(s,e)=>{if(e.KeyCode==Keys.Enter && mode==LightMode.Morse){e.SuppressKeyPress=true;await RestartAsync();}};custom.Controls.Add(morse,1,1);
   speedValue.Dock=DockStyle.Fill;speedValue.ForeColor=Theme.Muted;speedValue.Font=Theme.Font(8,FontStyle.Regular);custom.Controls.Add(speedValue,0,2);advanced.Controls.Add(custom,0,0);
   var settings=new TableLayoutPanel { ColumnCount=2,RowCount=3,Dock=DockStyle.Fill,Margin=new Padding(0,6,0,0) };settings.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,55));settings.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,45));settings.RowStyles.Add(new RowStyle(SizeType.Absolute,25));settings.RowStyles.Add(new RowStyle(SizeType.Absolute,36));settings.RowStyles.Add(new RowStyle(SizeType.Absolute,24));
   powerTitle.Dock=timerTitle.Dock=DockStyle.Fill;powerTitle.ForeColor=timerTitle.ForeColor=Theme.Muted;settings.Controls.Add(powerTitle,0,0);settings.Controls.Add(timerTitle,1,0);
   power.Minimum=10;power.Maximum=100;power.Value=30;power.TickStyle=TickStyle.None;power.SmallChange=5;power.LargeChange=10;power.Dock=DockStyle.Fill;power.BackColor=Theme.Background;power.Margin=new Padding(0,0,16,0);power.AccessibleName="Brightness";
   power.ValueChanged+=(s,e)=>RefreshState();power.MouseUp+=async(s,e)=>await PowerAsync();power.KeyUp+=async(s,e)=>await PowerAsync();settings.Controls.Add(power,0,1);
   timer.DropDownStyle=ComboBoxStyle.DropDownList;timer.BackColor=Theme.Card;timer.ForeColor=Theme.Text;timer.FlatStyle=FlatStyle.Flat;timer.Font=Theme.Font(11,FontStyle.Regular);timer.Dock=DockStyle.Fill;timer.Margin=new Padding(0,3,0,0);timer.AccessibleName="Auto off";
   settings.Controls.Add(timer,1,1);powerValue.Dock=DockStyle.Fill;powerValue.ForeColor=Theme.Muted;powerValue.Font=Theme.Font(8,FontStyle.Regular);settings.Controls.Add(powerValue,0,2);advanced.Controls.Add(settings,0,1);
   footer.Dock=DockStyle.Fill;footer.ForeColor=Theme.Muted;footer.Font=Theme.Font(8,FontStyle.Regular);footer.TextAlign=ContentAlignment.MiddleCenter;footer.Margin=new Padding(0,4,0,0);Add(footer,24);
   controller.Failed+=e=>UI(()=>{error=Explain(e);RefreshState();});controller.Completed+=()=>UI(RefreshState);
   refresh.Interval=200;refresh.Tick+=(s,e)=>{LightController.KeepAwake(controller.Running);RefreshState();};refresh.Start();
   FormClosing+=OnCloseAsync;SystemEvents.PowerModeChanged+=OnPowerMode;SystemEvents.UserPreferenceChanged+=OnSystemTheme;Localize();ApplyTheme();ResumeLayout(true);
   Shown+=(s,e)=>{WindowState=FormWindowState.Normal;using(var graphics=CreateGraphics())uiScale=graphics.DpiX/96f;ScaleUi(this,uiScale);maxContentWidth=(int)(420*uiScale);MinimumSize=SizeFromClientSize(new Size((int)(400*uiScale),(int)(356*uiScale)));UpdateContentHeight();BeginInvoke((Action)(()=>{WindowState=FormWindowState.Normal;FitCompactWindow();var area=Screen.FromControl(this).WorkingArea;Location=new Point(area.X+(area.Width-Width)/2,area.Y+(area.Height-Height)/2);ArrangeContent(scroll);SaveUiAudit();}));};
   scroll.Resize+=(s,e)=>ArrangeContent(scroll);
  }
  void Add(Control control,int height) { int row=root.RowCount++;root.RowStyles.Add(new RowStyle(SizeType.Absolute,height));root.Controls.Add(control,0,row); }
  static void ScaleUi(Control control,float scale) {
   control.SuspendLayout();
   foreach(Control child in control.Controls)ScaleUi(child,scale);
   if(control is TableLayoutPanel) { var table=(TableLayoutPanel)control;foreach(RowStyle row in table.RowStyles)if(row.SizeType==SizeType.Absolute)row.Height*=scale;foreach(ColumnStyle column in table.ColumnStyles)if(column.SizeType==SizeType.Absolute)column.Width*=scale; }
   control.Margin=ScalePadding(control.Margin,scale);control.Padding=ScalePadding(control.Padding,scale);
   var bounds=control.Bounds;control.Bounds=new Rectangle((int)(bounds.X*scale),(int)(bounds.Y*scale),(int)(bounds.Width*scale),(int)(bounds.Height*scale));control.ResumeLayout(true);
  }
  static Padding ScalePadding(Padding padding,float scale) { return new Padding((int)(padding.Left*scale),(int)(padding.Top*scale),(int)(padding.Right*scale),(int)(padding.Bottom*scale)); }
  void SaveUiAudit() { if(Program.UiAuditPath==null)return;File.WriteAllText(Program.UiAuditPath,new JavaScriptSerializer().Serialize(new{version="1.1.1",dpiScale=uiScale,window=Bounds.ToString(),client=ClientSize.ToString(),root=root.Bounds.ToString(),rows=root.RowStyles.Cast<RowStyle>().Select(row=>row.Height).ToArray(),state=state.Bounds.ToString(),stateFont=state.Font.Size,header=title.Bounds.ToString(),theme=Theme.Dark?"dark":"light",optionsExpanded=optionsExpanded,verticalScroll=scroll.VerticalScroll.Visible})); }
  void UpdateContentHeight() { root.Height=(int)Math.Ceiling(root.RowStyles.Cast<RowStyle>().Sum(row=>row.Height))+root.Padding.Vertical;scroll.AutoScrollMinSize=new Size(0,root.Height); }
  void FitCompactWindow() {
   if(WindowState!=FormWindowState.Normal)return;
   var area=Screen.FromControl(this).WorkingArea;
   var desired=SizeFromClientSize(new Size((int)(420*uiScale),root.Height));
   Size=new Size(Math.Min(desired.Width,area.Width-24),Math.Min(desired.Height,area.Height-24));
   if(Bottom>area.Bottom)Top=Math.Max(area.Top,area.Bottom-Height);
  }
  void SetOptions(bool expanded) {
   optionsExpanded=expanded;advanced.Visible=expanded;root.RowStyles[advancedRow].Height=expanded?184*uiScale:0;
   options.Text=L(expanded?"Скрыть настройки ▴":"Настройки ▾",expanded?"Hide settings ▴":"Settings ▾");options.AccessibleName=options.Text;
   UpdateContentHeight();scroll.AutoScrollPosition=Point.Empty;FitCompactWindow();ArrangeContent(scroll);SaveUiAudit();
  }
  void UI(Action action) { if(!IsDisposed && IsHandleCreated) { try { BeginInvoke(action); } catch(InvalidOperationException) { } } }
  void ArrangeContent(Panel host) { if(maxContentWidth<=0)return;int gutter=root.Height>host.ClientSize.Height?SystemInformation.VerticalScrollBarWidth:0;int width=Math.Min(maxContentWidth,Math.Max(1,host.ClientSize.Width-gutter));root.Width=width;root.Location=new Point(Math.Max(0,(host.ClientSize.Width-gutter-width)/2),host.AutoScrollPosition.Y); }
  void ApplyTheme() {
   bool dark=themeMode==2;
   if(themeMode==0) { using(var key=Registry.CurrentUser.OpenSubKey(@"Software\Microsoft\Windows\CurrentVersion\Themes\Personalize")) { dark=key!=null && Convert.ToInt32(key.GetValue("AppsUseLightTheme",1))==0; } }
   Theme.Apply(dark);ColorControls(this);
   foreach(var label in new[]{subtitle,modeText,hint,powerTitle,speedTitle,textTitle,timerTitle,footer,powerValue,speedValue})label.ForeColor=Theme.Muted;
   elapsed.ForeColor=Theme.Accent;themeChoice.Text=themeMode==0?L("Система","System"):themeMode==1?L("Светлая","Light"):L("Тёмная","Dark");themeChoice.AccessibleName=L("Тема: ","Theme: ")+themeChoice.Text;RefreshState();Invalidate(true);SaveUiAudit();
  }
  void ColorControls(Control control) { control.BackColor=(control is TextBox || control is ComboBox)?Theme.Card:Theme.Background;control.ForeColor=Theme.Text;foreach(Control child in control.Controls)ColorControls(child); }
  void OnSystemTheme(object sender,UserPreferenceChangedEventArgs e) { if(themeMode==0)UI(ApplyTheme); }
  string ModeName(LightMode m) { return new[]{L("Постоянный","Steady"),L("Мигание","Blink"),L("Быстрое","Fast blink"),"SOS",L("Азбука Морзе","Morse message") }[(int)m]; }
  int Minutes { get { return new[]{1,5,10,30,0}[Math.Max(0,timer.SelectedIndex)]; } }
  void Localize() {
   subtitle.Text="Xiaomi Pad 5 · v1.1.1";language.Text=ru?"EN":"RU";developer.Text=L("Разработчик","Developer");developer.AccessibleName=L("Написать разработчику в Telegram","Contact developer on Telegram");
   options.Text=L(optionsExpanded?"Скрыть настройки ▴":"Настройки ▾",optionsExpanded?"Hide settings ▴":"Settings ▾");options.AccessibleName=options.Text;
   modesTitle.Text=L("Режим света","LIGHT MODE");for(int i=0;i<5;i++)modes[i].Text=ModeName((LightMode)i);
   powerTitle.Text=L("Яркость","Brightness");speedTitle.Text=L("Точка Морзе","Morse dot duration");textTitle.Text=L("Сообщение","Your message");timerTitle.Text=L("Автовыключение","Turn off after");
   int selected=timer.SelectedIndex;timer.Items.Clear();foreach(int n in new[]{1,5,10,30})timer.Items.Add(n+L(" мин"," min"));timer.Items.Add(L("Без таймера","No timer"));timer.SelectedIndex=selected<0?1:selected;
   footer.Text=L("Пробел — вкл/выкл   ·   Esc — выключить","Space — on/off   ·   Esc — turn off");ApplyTheme();
  }
  void RefreshState() {
   bool running=controller.Running;
   state.Text=busy?L("Подождите…","Please wait…"):error.Length>0?L("Не включён","Unavailable"):running?L("Фонарик включён","Light is running"):L("Выключен","Light is off");
   state.ForeColor=error.Length>0?(Theme.Dark?Color.FromArgb(255,149,149):Color.FromArgb(170,48,48)):running?(Theme.Dark?Theme.Amber:Color.FromArgb(130,81,12)):Theme.Text;
   toggle.Lit=running;toggle.Caption=busy?L("ПОДОЖДИТЕ","PLEASE WAIT"):running?L("ВЫКЛЮЧИТЬ","TURN OFF"):L("ВКЛЮЧИТЬ","TURN ON");toggle.AccessibleName=toggle.Caption;toggle.Invalidate();
   modeText.Text=L("Режим: ","Mode: ")+ModeName(mode);
   elapsed.Text=running?controller.Elapsed.ToString(@"mm\:ss")+(Minutes>0?" / "+Minutes+":00":""):L("Готов к включению","Ready to turn on");
   hint.Text=error.Length>0?error:busy?L("Подключение к вспышке…","Connecting to the light…"):L("Свет гаснет при закрытии приложения.","Closing the app turns the light off.");
   speedValue.Text=(speed.Value/1000.0).ToString("0.00",CultureInfo.InvariantCulture)+L(" с · точка"," s · dot");
   powerValue.Text=!adjustableKnown?L("Проверяется при включении","Detected when you turn on"):!controller.PowerSupported?L("Драйвер: фиксированная яркость","Driver: fixed brightness"):power.Value+"%";
   bool custom=mode==LightMode.SOS || mode==LightMode.Morse;speed.Enabled=!busy&&custom;morse.Enabled=!busy&&mode==LightMode.Morse;timer.Enabled=!busy&&!running;
   power.Enabled=!busy&&adjustableKnown&&controller.PowerSupported;toggle.Enabled=!busy;
   for(int i=0;i<5;i++) { modes[i].Selected=(int)mode==i;modes[i].Enabled=!busy;modes[i].Invalidate(); }
  }
  async Task ToggleAsync() { if(busy||closing)return;if(controller.Running)await StopAsync();else await RestartAsync(); }
  async Task SelectModeAsync(LightMode selected) { if(busy||closing)return;mode=selected;error="";if(mode==LightMode.Morse&&!optionsExpanded)SetOptions(true);RefreshState();if(controller.Running)await RestartAsync(); }
  async Task RestartAsync() {
   if(busy||closing)return;busy=true;error="";RefreshState();
   try { await controller.StartAsync(mode,speed.Value,morse.Text,power.Value,Minutes);adjustableKnown=true; }
   catch(Exception e) { error=Explain(e); }
   finally { busy=false;RefreshState(); }
  }
  async Task StopAsync() {
   if(busy)return;busy=true;RefreshState();try { await controller.StopAsync();error=""; } catch(Exception e) { error=Explain(e); }
   finally { busy=false;LightController.KeepAwake(false);RefreshState(); }
  }
  void OpenDeveloper() {
   try { Process.Start(new ProcessStartInfo("https://t.me/deskcj") { UseShellExecute=true }); }
   catch(Exception) { MessageBox.Show(this,L("Не удалось открыть Telegram. Адрес разработчика: ","Could not open Telegram. Developer address: ")+"https://t.me/deskcj","Nabu Light",MessageBoxButtons.OK,MessageBoxIcon.Information); }
  }
  async Task PowerAsync() { if(busy||!controller.Running)return;string failure="";try { await controller.ChangePowerAsync(power.Value); } catch(Exception e) { failure=Explain(e); } if(failure.Length>0) { await StopAsync();error=failure;RefreshState(); } }
  string Explain(Exception e) {
   string msg=e.Message;int hr=e.HResult;
   if(msg.Contains("EMPTY_MORSE"))return L("Введите сообщение для азбуки Морзе.","Enter a Morse message.");
   if(msg.Contains("UNSUPPORTED_MORSE"))return L("Поддерживаются русские и английские буквы, цифры и . , ? ! / -","Use Russian or English letters, digits and . , ? ! / -");
   if(msg.Contains("NO_REAR_CAMERA"))return L("Задняя камера Qualcomm ISP не найдена. Проверьте драйверы камер.","Qualcomm ISP rear camera not found. Check the camera drivers.");
   if(msg.Contains("NO_TORCH_CONTROL"))return L("Этот драйвер не поддерживает управление фонариком.","This driver does not support torch control.");
   if(hr==unchecked((int)0x80070005))return L("Windows запретила доступ к камере. Разрешите доступ настольным приложениям в параметрах Windows.","Windows denied camera access. Allow desktop camera access in Windows Settings.");
   if(msg.Contains("NO_CAMERA_FRAMES"))return L("Камера не отвечает. Закройте другие приложения камеры и попробуйте снова.","The camera is not responding. Close other camera apps and try again.");
   return L("Не удалось включить вспышку. Закройте приложение камеры и повторите. Код ","Cannot control the light. Close other camera apps and retry. Code ")+hr.ToString("X8");
  }
  protected override bool ProcessCmdKey(ref Message msg,Keys key) {
   if(key==Keys.Escape) { if(!busy)StopAsync().ContinueWith(t=>{});return true; }
   if(key==Keys.Space && !morse.Focused && !timer.Focused) { if(!busy)ToggleAsync().ContinueWith(t=>{});return true; }
   return base.ProcessCmdKey(ref msg,key);
  }
  async void OnCloseAsync(object sender,FormClosingEventArgs e) {
   if(closed)return;e.Cancel=true;if(closing)return;closing=true;Enabled=false;refresh.Stop();
   while(busy) await Task.Delay(100);
   try { await controller.StopAsync(); } catch(Exception ex) { MessageBox.Show(this,Explain(ex),"Nabu Light",MessageBoxButtons.OK,MessageBoxIcon.Warning); }
   finally { LightController.KeepAwake(false);SystemEvents.PowerModeChanged-=OnPowerMode;SystemEvents.UserPreferenceChanged-=OnSystemTheme;closed=true;Close(); }
  }
  void OnPowerMode(object sender,PowerModeChangedEventArgs e) { if(e.Mode==PowerModes.Suspend)UI(async()=>await StopAsync()); }
 }
 static class Program {
  public static string UiAuditPath;
  [STAThread] static int Main(string[] args) {
   if(args.Length==2 && args[0]=="--hardware-test")return HardwareTest.Run(args[1]);
   if(args.Length==2 && args[0]=="--test-patterns")return HardwareTest.TestPatterns(args[1]);
   if(args.Length==2 && args[0]=="--ui-audit")UiAuditPath=Path.GetFullPath(args[1]);
   bool owns;using(var mutex=new Mutex(true,@"Local\deskcj.NabuLight",out owns)) {
    if(!owns) { MessageBox.Show("Nabu Light уже запущен / is already running.","Nabu Light");return 0; }
    Application.EnableVisualStyles();Application.SetCompatibleTextRenderingDefault(false);Application.Run(new MainForm());
   }
   return 0;
  }
 }
}
