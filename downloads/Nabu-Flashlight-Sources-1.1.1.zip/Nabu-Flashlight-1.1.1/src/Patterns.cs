using System;
using System.Collections.Generic;
using System.Linq;

namespace NabuLight {
 public enum LightMode { Steady, Blink, FastBlink, SOS, Morse }
 public sealed class Pulse {
  public bool On; public int Units; public string Symbol;
  public Pulse(bool on,int units,string symbol) { On=on; Units=units; Symbol=symbol; }
 }
 public static class Patterns {
  static readonly Dictionary<char,string> Codes=new Dictionary<char,string>();
  static Patterns() {
   string[] latin={"A:.-","B:-...","C:-.-.","D:-..","E:.","F:..-.","G:--.","H:....","I:..","J:.---","K:-.-","L:.-..","M:--","N:-.","O:---","P:.--.","Q:--.-","R:.-.","S:...","T:-","U:..-","V:...-","W:.--","X:-..-","Y:-.--","Z:--..","0:-----","1:.----","2:..---","3:...--","4:....-","5:.....","6:-....","7:--...","8:---..","9:----.",".:.-.-.-",",:--..--","?:..--..","!:-.-.--","/: -..-.","-:-....-"};
   foreach(string row in latin) Codes[row[0]]=row.Substring(2).Trim();
   string letters="АБВГДЕЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯ";
   string[] russian={".-","-...",".--","--.","-..",".","...-","--..","..",".---","-.-",".-..","--","-.","---",".--.",".-.","...","-","..-","..-.","....","-.-.","---.","----","--.-","--.--","-.--","-..-","..-..","..--",".-.-"};
   for(int i=0;i<letters.Length;i++) Codes[letters[i]]=russian[i]; Codes['Ё']=".";
  }
  public static string Encode(string text) {
   if(string.IsNullOrWhiteSpace(text)) throw new ArgumentException("EMPTY_MORSE");
   var words=new List<string>();
   foreach(string word in text.ToUpperInvariant().Split((char[])null,StringSplitOptions.RemoveEmptyEntries)) {
    var letters=new List<string>();
    foreach(char c in word) { string code; if(!Codes.TryGetValue(c,out code)) throw new ArgumentException("UNSUPPORTED_MORSE:"+c); letters.Add(code); }
    if(letters.Count>0) words.Add(string.Join(" ",letters));
   }
   return string.Join(" / ",words);
  }
  public static Pulse[] Morse(string text) {
   string encoded=Encode(text); var result=new List<Pulse>();
   string[] words=encoded.Split(new[]{" / "},StringSplitOptions.None);
   for(int w=0;w<words.Length;w++) {
    string[] letters=words[w].Split(' ');
    for(int c=0;c<letters.Length;c++) {
     string code=letters[c];
     for(int k=0;k<code.Length;k++) { result.Add(new Pulse(true,code[k]=='.'?1:3,code[k].ToString())); if(k+1<code.Length) result.Add(new Pulse(false,1,"")); }
     if(c+1<letters.Length) result.Add(new Pulse(false,3,""));
    }
    result.Add(new Pulse(false,7,""));
   }
   return result.ToArray();
  }
  public static Pulse[] Get(LightMode mode,string text) {
   if(mode==LightMode.SOS) return Morse("SOS");
   if(mode==LightMode.Morse) return Morse(text);
   if(mode==LightMode.Blink || mode==LightMode.FastBlink) return new[]{new Pulse(true,1,""),new Pulse(false,1,"")};
   return new Pulse[0];
  }
 }
}
