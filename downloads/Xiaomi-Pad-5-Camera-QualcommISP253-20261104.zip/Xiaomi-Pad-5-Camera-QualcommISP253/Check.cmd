@echo off
setlocal
cd /d "%~dp0"
"%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe" -NoProfile -ExecutionPolicy Bypass -File "%~dp0Setup.ps1" -Mode Check
set "CAMERA_RESULT=%errorlevel%"
echo.
echo Camera Check exit code: %CAMERA_RESULT%
echo Logs: C:\ProgramData\XiaomiPad5Camera\Logs
pause
exit /b %CAMERA_RESULT%
