Xiaomi Pad 5 (nabu) cameras — Qualcomm ISP 253 / SYS080 / DeviceMFT075b
Public preview, Windows 11 ARM64 only.

INSTALL (same for all three branches)
1. Disable Secure Boot and enable Windows Test Mode:
   https://github.com/erdilS/Port-Windows-11-Xiaomi-Pad-5/blob/main/guide/English/disable-secureboot-en.md
2. Close camera preview/recording in every application. Do not run other camera installers or hardware research tools in parallel.
3. Extract this ZIP completely into a normal local folder. Run Setup.cmd as administrator.
4. If the installer explicitly requests a restart, restart normally and run Setup.cmd again. It never restarts automatically.
5. Wait for the SUCCESS message and exit code 0. The install checks both camera images and their normal closure.
6. Open Windows Camera and check front/rear preview, photos and switching.

CHECK AND DIAGNOSTICS
Check.cmd checks archive integrity and platform; it does not prove a camera image.
Close camera apps, then run Diagnose.cmd as administrator for a fresh image check.
Send the newest complete log folder from C:\ProgramData\XiaomiPad5Camera\Logs,
including result.json and setup.log. Diagnostics may save images: review them before sharing.
Backup-CurrentDrivers.cmd exports existing packages; it is not a one-click rollback.
To change processing branch, close camera apps and run that branch's Setup.cmd.
Only one branch is active at a time. GPU uses a service and two workers; CPU does not.
GPU needs at least 900 MiB free RAM; the other profiles at least 650 MiB. Allow at least 1 GiB free on C:.
Device matching uses hardware identities, not translated Device Manager descriptions.
The installer's guards reject unsafe or busy states rather than forcing applications closed.

SOURCES
Driver ZIP: tested signed binaries, installer and diagnostics.
GPU040 matching C/C++/HLSL sources and EWDK build command: separate source ZIP.
CPUISP4 retained C/H projects: separate source ZIP. QISP253: project code, exact parameters and pipeline notes; original Qualcomm source unavailable.
https://github.com/deskcj/xiaomi-pad5-windows11-camera
No private signing key, personal photographs or original Android measurement dumps are included.

Support: https://www.donationalerts.com/r/deskcj
Independent experimental community software, supplied as is. Not affiliated with Xiaomi,
Qualcomm, Microsoft or OmniVision. Keep a backup and recovery method. Android parity,
all applications/Windows images and uninterrupted 30 FPS are not guaranteed.

During installation, a native Qualcomm opening that returns zero frames can be tested once more only after normal stream closure and complete loss-free tracing are confirmed. The first logs are retained. A second failure, API error or green/empty image remains a failure; no device reset or automatic restart is performed.
