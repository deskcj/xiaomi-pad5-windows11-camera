@echo off
cd /d "%~dp0"
"%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe" -NoProfile -ExecutionPolicy Bypass -File "%~dp0Setup.ps1" -Mode Diagnose
set "CameraSetupExit=%ERRORLEVEL%"
echo.
if not "%CameraSetupExit%"=="0" echo Installation/check stopped. See the log shown above.
pause
exit /b %CameraSetupExit%
