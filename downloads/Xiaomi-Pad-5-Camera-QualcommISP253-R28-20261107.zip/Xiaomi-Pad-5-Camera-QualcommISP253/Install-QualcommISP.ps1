﻿[CmdletBinding()]
param([switch]$Resume,[switch]$NoRestart,[switch]$Elevated,[string]$UserSid=[Security.Principal.WindowsIdentity]::GetCurrent().User.Value)
$ErrorActionPreference='Stop';Set-StrictMode -Version Latest
[Console]::OutputEncoding=[Text.UTF8Encoding]::new($false)
if($PSVersionTable.PSEdition -eq 'Desktop'){$env:PSModulePath=(Join-Path $PSHOME 'Modules')+';'+[Environment]::GetEnvironmentVariable('PSModulePath',[EnvironmentVariableTarget]::Machine)}
$root=[IO.Path]::GetFullPath($PSScriptRoot);$data=Join-Path $root 'Data';$resumeFile=Join-Path $data 'powershell-resume.json'
if(-not ([Security.Principal.WindowsPrincipal]::new([Security.Principal.WindowsIdentity]::GetCurrent())).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)){
 if($Elevated){throw 'Administrator access was not granted.'}
 $arguments=@('-NoProfile','-ExecutionPolicy','Bypass','-File',('"'+$PSCommandPath+'"'),'-Elevated','-UserSid',('"'+$UserSid+'"'));if($Resume){$arguments+='-Resume'};if($NoRestart){$arguments+='-NoRestart'}
 $child=Start-Process -FilePath "$env:windir\System32\WindowsPowerShell\v1.0\powershell.exe" -ArgumentList $arguments -Verb RunAs -Wait -PassThru
 exit $child.ExitCode
}
. (Join-Path $root 'Tools\StandaloneResume.ps1')
$previous=$null;if(Test-Path -LiteralPath $resumeFile){$previous=Get-Content -LiteralPath $resumeFile -Raw -Encoding UTF8|ConvertFrom-Json}
$boot=(Get-CimInstance Win32_OperatingSystem).LastBootUpTime.ToUniversalTime().ToString('o')
if($Resume -and $previous -and $previous.boot -eq $boot){Write-Host 'Restart Windows to continue; this kernel session has not restarted.';exit 3010}
Write-Host 'Qualcomm ISP drivers for Xiaomi Pad 5 on Windows 11 — installer 1.0.7' -ForegroundColor Cyan
Write-Host 'Checking, repairing and verifying the driver package. Logs remain in this extracted folder.'
$logs=Join-Path $data 'Logs';New-Item -ItemType Directory -Path $logs -Force|Out-Null
$before=[datetime]::UtcNow
& (Join-Path $root 'Setup.ps1') -Mode Install -ResultRoot $logs -Elevated
$code=$LASTEXITCODE
$latest=Get-ChildItem -LiteralPath $logs -Recurse -File -Filter result.json|Where-Object LastWriteTimeUtc -ge $before|Sort-Object LastWriteTimeUtc -Descending|Select-Object -First 1
if(-not $latest){Write-Host 'No installer result was produced. Keep this folder and its logs.' -ForegroundColor Red;exit 1}
$result=Get-Content -LiteralPath $latest.FullName -Raw -Encoding UTF8|ConvertFrom-Json
if($result.rebootRequired){
 $plan=Get-StandaloneRecoveryPlan $previous $result.status $boot
 if($plan.stop){
  Set-StandaloneResume $root $UserSid $false
  if(Test-Path -LiteralPath $resumeFile){Remove-Item -LiteralPath $resumeFile -Force}
  Write-Host 'Recovery stopped: repeated restarts made no progress. Keep the latest report; another automatic restart is not scheduled.' -ForegroundColor Red;exit 2
 }
 $task=Set-StandaloneResume $root $UserSid $true
 $record=[ordered]@{boot=$boot;pendingStatus=$result.status;restartRequests=$plan.restartRequests;sameStageRequests=$plan.sameStageRequests;task=$task;report=$latest.FullName}
 $temp=$resumeFile+'.tmp';[IO.File]::WriteAllText($temp,($record|ConvertTo-Json),[Text.UTF8Encoding]::new($false));if(Test-Path -LiteralPath $resumeFile){[IO.File]::Replace($temp,$resumeFile,$null)}else{[IO.File]::Move($temp,$resumeFile)}
 Write-Host 'RESTART REQUIRED. After signing in, wait about 15 seconds: PowerShell reopens and continues. Keep the extracted folder.' -ForegroundColor Yellow
 if(-not $NoRestart){$answer=Read-Host '[R] Restart system now / [L] Restart later';if($answer -match '^(?i:r)$'){& "$env:windir\System32\shutdown.exe" /r /t 10 /d p:2:4 /c 'Qualcomm ISP camera installation continuation';if($LASTEXITCODE){throw 'Windows rejected restart; use Start > Restart.'}}}
 exit 3010
}
if($code -eq 0 -and $result.status -like 'PASS*' -and $result.captures.Count -eq 2 -and $result.captureClosed -and $result.fullMftDecoded){
 Set-StandaloneResume $root $UserSid $false
 if(Test-Path -LiteralPath $resumeFile){Remove-Item -LiteralPath $resumeFile -Force}
 Write-Host '100% — Installation complete. Both cameras delivered frames and closed normally.' -ForegroundColor Green
 Write-Host 'Driver files remain in Windows DriverStore and the Windows driver directory. This extracted folder can now be deleted.';exit 0
}
Set-StandaloneResume $root $UserSid $false
Write-Host ('Installation/verification stopped: '+($result.errors -join '; ')) -ForegroundColor Red
Write-Host ('Report: '+$latest.FullName);if($code -eq 0){$code=1};exit $code
