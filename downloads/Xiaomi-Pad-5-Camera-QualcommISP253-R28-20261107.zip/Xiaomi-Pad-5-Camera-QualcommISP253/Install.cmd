@echo off
title Xiaomi Pad 5 Qualcomm ISP camera installer
call "%~dp0Setup.cmd"
exit /b %ERRORLEVEL%
