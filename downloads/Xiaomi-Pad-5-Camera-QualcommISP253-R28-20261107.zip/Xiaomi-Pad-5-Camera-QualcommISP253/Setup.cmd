@echo off
setlocal EnableExtensions
cd /d "%~dp0"
"%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe" -NoProfile -ExecutionPolicy Bypass -File "%~dp0Install-QualcommISP.ps1"
set "CameraSetupExit=%ERRORLEVEL%"
echo.
if "%CameraSetupExit%"=="3010" goto restart
if "%CameraSetupExit%"=="0" goto success
if "%CameraSetupExit%"=="2" goto incomplete
echo SETUP STOPPED. See the error above.
echo Logs: %~dp0Data\Logs
goto finish
:incomplete
echo DRIVERS INSTALLED; CAMERA VERIFICATION INCOMPLETE.
echo Review the message above and save the complete newest Logs folder.
echo Both cameras have not passed the complete automated test yet.
echo Logs: %~dp0Data\Logs
goto finish
:restart
echo RESTART REQUIRED.
echo After Restart, sign in and wait 15 seconds: PowerShell opens and continues.
echo Keep this archive extracted until installation is complete.
goto finish
:success
echo SUCCESS: both cameras produced images and closed normally.
:finish
pause
exit /b %CameraSetupExit%
