﻿# A control readback and a healthy video stream do not prove physical LED output.
function Get-CameraFlashEvidence([string]$MftFile){
 $r=[ordered]@{status='NO_FLASH_MARKERS';initSucceeded=0;initFailed=0;lowCommands=0;highCommands=0;offCommands=0;errors=@();physicalEmissionVerified=$false}
 $reader=[IO.StreamReader]::new($MftFile,[Text.Encoding]::UTF8,$true)
 try{while($null -ne ($line=$reader.ReadLine())){
  if($line -notmatch 'camxflash\.cpp|SENSOR_FLASH_DEBUG'){continue}
  $event=$line|ConvertFrom-Json;$text=[string]$event.text
  if($text -match 'Flash init command success'){$r.initSucceeded++}
  if($text -match 'Flash init command (?:faled|failed)|\[ERROR\].*(?:Flash::|camxflash\.cpp)'){$r.initFailed++;if($r.errors.Count -lt 20){$r.errors+=@([ordered]@{index=$event.index;text=$text.Trim()})}}
  if($text -match 'Flash Operation: Low'){$r.lowCommands++}
  if($text -match 'Flash Operation: High'){$r.highCommands++}
  if($text -match 'Flash Operation: OFF'){$r.offCommands++}
 }}finally{$reader.Dispose()}
 if($r.initFailed){$r.status='FLASH_DRIVER_FAILURE'}elseif($r.initSucceeded){$r.status='FLASH_INITIALIZATION_CONFIRMED_PHYSICAL_TEST_REQUIRED'}
 return $r
}
