﻿# The WinRT lifecycle and optional native debug evidence are separate verdicts.
function Test-OperationalCapture([string]$Text,[object]$Close,[object]$Decode,[object]$State){
 if(-not $Close -or -not $Decode -or $State.pendingPid -or $State.unsafeToContinue -or -not $State.captureClosed -or -not $State.fullMftDecoded){return $false}
 $retirement=Get-ProbeRetirement $Text
 if(-not $retirement.closed -or $retirement.neverOpened -or $Text -match '(?m)^ERROR256'){return $false}
 if(@([regex]::Matches($Text,'(?m)^RESULT256 ')).Count -ne 1 -or $Text -notmatch '(?m)^RESULT256 hr=00000000 frames=[1-9]\d* duplicatePolls=\d+ width=[1-9]\d* height=[1-9]\d* [^\r\n]*signal=true saved=true controlsChanged=false\r?$'){return $false}
 if($Decode.status -notlike 'PASS*' -or $Decode.eventsLost -ne 0){return $false}
 # No marker at all is unavailable instrumentation, never native close success.
 return $Close.status -eq 'HOLD' -and $Close.evidenceStatus -eq 'MISSING_DRIVER_LOG_MARKERS' -and $Close.eventsLost -eq 0 -and @($Close.errors).Count -eq 0 -and @($Close.markers).Count -eq 0
}
