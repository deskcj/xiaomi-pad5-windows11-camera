﻿using System;
using System.Runtime.InteropServices;

namespace XiaomiPad5 {
 public sealed class BootSecuritySnapshot {
  public bool SecureBootAvailable;
  public bool SecureBootEnabled;
  public bool SecureBootCapable;
  public string SecureBootStatus = "Not queried";
  public bool CodeIntegrityAvailable;
  public uint CodeIntegrityOptions;
  public string CodeIntegrityStatus = "Not queried";
 }

 public static class CameraBootSecurity {
  [DllImport("ntdll.dll", ExactSpelling = true)]
  static extern int NtQuerySystemInformation(int informationClass, IntPtr buffer,
                                           uint length, out uint returnLength);

  static string Status(int status) { return "0x" + unchecked((uint)status).ToString("X8"); }

  public static BootSecuritySnapshot Read() {
   var result = new BootSecuritySnapshot();
   IntPtr buffer = Marshal.AllocHGlobal(8);
   try {
    uint returned;
    Marshal.WriteInt64(buffer, 0);
    try {
     // SYSTEM_SECUREBOOT_INFORMATION contains two BOOLEAN (one-byte) fields.
     int status = NtQuerySystemInformation(145, buffer, 2, out returned);
     result.SecureBootStatus = Status(status);
     if (status >= 0) {
      result.SecureBootAvailable = true;
      result.SecureBootEnabled = Marshal.ReadByte(buffer, 0) != 0;
      result.SecureBootCapable = Marshal.ReadByte(buffer, 1) != 0;
     }
    } catch (Exception ex) { result.SecureBootStatus = ex.GetType().Name + ": " + ex.Message; }
    Marshal.WriteInt64(buffer, 0);
    Marshal.WriteInt32(buffer, 8);
    try {
     // SYSTEM_CODEINTEGRITY_INFORMATION: Length, CodeIntegrityOptions.
     int status = NtQuerySystemInformation(103, buffer, 8, out returned);
     result.CodeIntegrityStatus = Status(status);
     if (status >= 0) {
      result.CodeIntegrityAvailable = true;
      result.CodeIntegrityOptions = unchecked((uint)Marshal.ReadInt32(buffer, 4));
     }
    } catch (Exception ex) { result.CodeIntegrityStatus = ex.GetType().Name + ": " + ex.Message; }
   } finally { Marshal.FreeHGlobal(buffer); }
   return result;
  }
 }
}
