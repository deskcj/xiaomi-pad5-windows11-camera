﻿function Get-StandaloneResumeArguments([string]$Root,[string]$UserSid){
 return '-NoProfile -ExecutionPolicy Bypass -File "'+(Join-Path $Root 'Install-QualcommISP.ps1')+'" -Resume -UserSid "'+$UserSid+'"'
}
function Set-StandaloneResume([string]$Root,[string]$UserSid,[bool]$Register){
 $sid=[Security.Principal.SecurityIdentifier]::new($UserSid);$name='xiaomi-pad5-windows11-camera-powershell-resume-'+$sid.Value
 $exe=Join-Path $env:windir 'System32\WindowsPowerShell\v1.0\powershell.exe';$arguments=Get-StandaloneResumeArguments $Root $sid.Value
 $existing=Get-ScheduledTask -TaskName $name -ErrorAction SilentlyContinue
 if($existing -and ($existing.Actions.Count -ne 1 -or $existing.Actions[0].Execute -ine $exe -or $existing.Actions[0].Arguments -cne $arguments)){throw 'An unrelated task uses the camera PowerShell resume name; it was not changed.'}
 if(-not $Register){if($existing){Unregister-ScheduledTask -TaskName $name -Confirm:$false};return}
 if(-not(Test-Path -LiteralPath (Join-Path $Root 'Install-QualcommISP.ps1'))){throw 'Extracted installer folder missing; cannot resume.'}
 $action=New-ScheduledTaskAction -Execute $exe -Argument $arguments -WorkingDirectory $Root
 $trigger=New-ScheduledTaskTrigger -AtLogOn -User $sid.Value;$trigger.Delay='PT15S'
 $principal=New-ScheduledTaskPrincipal -UserId $sid.Value -LogonType Interactive -RunLevel Limited
 $settings=New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -StartWhenAvailable -MultipleInstances IgnoreNew -ExecutionTimeLimit ([TimeSpan]::Zero)
 Register-ScheduledTask -TaskName $name -Action $action -Trigger $trigger -Principal $principal -Settings $settings -Description 'Temporary Qualcomm ISP PowerShell installation continuation; removed on completion or recovery stop.' -Force|Out-Null
 $check=Get-ScheduledTask -TaskName $name
 if($check.Actions.Count -ne 1 -or $check.Actions[0].Execute -ine $exe -or $check.Actions[0].Arguments -cne $arguments){throw 'PowerShell resume task verification failed.'}
 return $name
}
function Get-StandaloneRecoveryPlan([object]$Previous,[string]$Status,[string]$Boot){
 $attempts=0;$repeats=0
 if($Previous){$attempts=[int]$Previous.restartRequests;if($Previous.pendingStatus -eq $Status){$repeats=[int]$Previous.sameStageRequests}}
 # Reopening before restarting does not consume another recovery attempt.
 if(-not $Previous -or $Previous.boot -ne $Boot){$attempts++;$repeats++}
 [pscustomobject]@{restartRequests=$attempts;sameStageRequests=$repeats;stop=($attempts -gt 3 -or $repeats -gt 2)}
}
