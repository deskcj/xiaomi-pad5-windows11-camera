﻿function Test-FlashRecoveryAllowed([object]$State){
 if($State.pendingPid -or $State.unsafeToContinue -or -not $State.captureClosed -or -not $State.fullMftDecoded -or $State.rebootRequired){return $false}
 return -not $State.Contains('flashRecoveryAttempts') -or $State.flashRecoveryAttempts -lt 1
}
function Restart-CameraFlashDevice([string]$Label){
 Assert-Idle
 if($r.pendingPid -or $r.unsafeToContinue -or -not $r.captureClosed -or -not $r.fullMftDecoded){throw 'Flash recovery requires a closed camera and completed trace decoding'}
 $nodes=@(Get-PrerequisiteNodes|Where-Object {$_.id -like 'ACPI\QCOM052A\*'})
 if($nodes.Count -ne 1 -or $nodes[0].problem -ne 0){throw 'Expected one healthy real flash device; prerequisite repair is required'}
 $id=$nodes[0].id;$r.driverActions=$true;Save-State
 $null=Run-Child $Label (Join-Path $env:windir 'System32\pnputil.exe') @('/restart-device',('"'+$id+'"')) 90000 -DeferRestart
 $after=Problem $id
 if($after -ne 0 -and -not($r.rebootRequired -and $after -eq 14)){throw 'Flash device did not return to a healthy state after restart'}
 if(-not $r.Contains('flashDeviceRestarts')){$r.flashDeviceRestarts=@()}
 $r.flashDeviceRestarts+=@([ordered]@{device=$id;label=$Label;afterProblem=$after;rebootRequired=$r.rebootRequired;forceUsed=$false})
 Save-State
}
