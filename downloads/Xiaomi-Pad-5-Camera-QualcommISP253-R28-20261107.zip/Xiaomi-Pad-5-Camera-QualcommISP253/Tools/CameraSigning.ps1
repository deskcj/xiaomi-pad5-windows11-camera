﻿function Get-CameraSigningState {
 if(-not ('XiaomiPad5.CameraBootSecurity' -as [type])){Add-Type -Path (Join-Path $PSScriptRoot 'BootSecurity.cs')}
 $native=[XiaomiPad5.CameraBootSecurity]::Read()
 $options=(Get-Item -LiteralPath 'HKLM:\SYSTEM\CurrentControlSet\Control').GetValue('SystemStartOptions','')
 $test=if($native.CodeIntegrityAvailable){($native.CodeIntegrityOptions -band 2) -ne 0}else{$options -match '(?i)(^|\s)TESTSIGNING($|\s)'}
 $secure='Unknown'
 if($native.SecureBootAvailable){$secure=if($native.SecureBootEnabled){'Enabled'}else{'Disabled'}}
 else{try{$firmware=Confirm-SecureBootUEFI -ErrorAction Stop;if($firmware -is [bool]){$secure=if($firmware){'Enabled'}else{'Disabled'}}}catch{}}
 [pscustomobject]@{testMode=[bool]$test;secureBoot=$secure;allowed=($test -and ($secure -eq 'Disabled' -or ($secure -eq 'Unknown' -and $native.CodeIntegrityAvailable)));native=$native}
}
function Assert-CameraSigning {
 $signing=Get-CameraSigningState
 if(-not $signing.testMode){throw 'These drivers are test-signed. Enable Windows Test Mode, disable Secure Boot and restart Windows before installation.'}
 if(-not $signing.allowed){throw 'Secure Boot is enabled or its disabled state could not be confirmed. Disable Secure Boot in UEFI before installing test-signed drivers.'}
 return $signing
}
