﻿# Remove only OEM packages whose complete model list targets these camera devices.
# Platform/JPEG/flash/SMMU/display packages and packages referenced by any remaining device are retained.
function Test-CameraOnlyHardwareId([string]$Id){return $Id -match '^(?i:ACPI\\(?:QCOM(?:0528|05A4|0506|0529)|VEN_QCOM&DEV_(?:0528|05A4|0506|0529))(?:&SUBSYS_[A-Z0-9]+)?|\*QCOM(?:0528|05A4|0506|0529)|VIDEO\\QCOM_AVStream_8150|VIDEO\\VEN_4D4F4351&DEV_41333530(?:&SUBSYS_303531384150544D(?:&REV_506)?)?&QCOM_AVStream_8150|ROOT\\NABUCAMVIRTUAL(?:FRONT|REAR))$'}
function Select-StaleCameraDevices([object[]]$Devices,[string[]]$PresentIds){
 $present=@{};foreach($id in $PresentIds){$present[$id]=$true}
 foreach($device in $Devices){
  if($present.ContainsKey($device.id) -or $device.id -notmatch '^(?i:ACPI\\QCOM(?:0528|05A4|0506|0529)\\|DISPLAY\\QCOM_AVStream_8150\\|ROOT\\CAMERA\\)'){continue}
  if(@($device.hardware).Count -eq 0 -or @($device.hardware|Where-Object {-not(Test-CameraOnlyHardwareId $_)}).Count){continue}
  $device
 }
}
function Get-CameraPackageModels([string]$Text){
 $sections=@{};$section=''
 foreach($raw in ($Text -split '\r?\n')){$line=($raw -split ';',2)[0].Trim();if($line -match '^\[([^]]+)\]$'){$section=$Matches[1];if(-not $sections.ContainsKey($section)){$sections[$section]=@()}}elseif($line -and $section){$sections[$section]+=$line}}
 if(-not $sections.ContainsKey('Version') -or -not $sections.ContainsKey('Manufacturer')){return @()}
 $class=@($sections['Version']|Where-Object {$_ -match '^Class\s*=\s*"?(Camera|System|Extension)"?\s*$'});if(-not $class.Count){return @()}
 $modelSections=@();foreach($line in $sections['Manufacturer']){if($line -notmatch '=\s*([^,]+)'){return @()};$base=$Matches[1].Trim().Trim('"');$modelSections+=@($sections.Keys|Where-Object {$_ -ieq $base -or $_.StartsWith($base+'.',[StringComparison]::OrdinalIgnoreCase)})}
 $models=@();foreach($name in ($modelSections|Sort-Object -Unique)){foreach($line in $sections[$name]){if($line -notmatch '=\s*[^,]+,(.+)$'){return @()};foreach($value in ($Matches[1] -split ',')){$id=$value.Trim().Trim('"');if(-not(Test-CameraOnlyHardwareId $id)){return @()};$models+=$id}}}
 return @($models|Sort-Object -Unique)
}
function Get-ReferencedDriverInfs {
 $referenced=@{};foreach($device in @(Get-PnpDevice -ErrorAction Stop)){$key=Get-Item -LiteralPath ('Registry::HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Enum\'+$device.InstanceId) -ErrorAction SilentlyContinue;if(-not $key){continue};$driver=$key.GetValue('Driver','');if($driver){$class=Get-Item -LiteralPath ('Registry::HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\Class\'+$driver) -ErrorAction SilentlyContinue;if($class){$inf=[string]$class.GetValue('InfPath','');if($inf){$referenced[$inf.ToLowerInvariant()]=$true}}}}
 return $referenced
}
function Get-UnusedCameraPackages {
 $referenced=Get-ReferencedDriverInfs
 foreach($inf in @(Get-ChildItem -LiteralPath (Join-Path $env:windir 'INF') -Filter 'oem*.inf' -File)){
  if($referenced.ContainsKey($inf.Name.ToLowerInvariant())){continue}
  $text=[IO.File]::ReadAllText($inf.FullName)
  # InfPath does not include Extension associations. Handle conflicting sensor
  # extensions separately; never call an arbitrary Extension package unused.
  if($text -match '(?im)^\s*Class\s*=\s*"?Extension"?\s*(?:;.*)?$'){continue}
  $models=@(Get-CameraPackageModels $text);if($models.Count){[pscustomobject]@{inf=$inf.Name;models=$models;sha256=(Get-FileHash -LiteralPath $inf.FullName).Hash}}
 }
}
function Test-ConflictingSensorExtension([string]$Text){
 if($Text -notmatch '(?im)^\s*Class\s*=\s*"?Extension"?\s*(?:;.*)?$' -or $Text -notmatch '(?im)^\s*HKR\s*,\s*,\s*"?CameraImagesPath"?\s*,'){return $false}
 $models=@(Get-CameraPackageModels $Text)
 return $models.Count -gt 0 -and @($models|Where-Object {$_ -notmatch '^(?i:ACPI\\(?:QCOM(?:0506|0529)|VEN_QCOM&DEV_(?:0506|0529))(?:&SUBSYS_[A-Z0-9]+)?)$'}).Count -eq 0
}
function Get-ConflictingSensorExtensions([string]$InfRoot=(Join-Path $env:windir 'INF')){
 foreach($inf in @(Get-ChildItem -LiteralPath $InfRoot -Filter 'oem*.inf' -File)){
  if(Test-ConflictingSensorExtension ([IO.File]::ReadAllText($inf.FullName))){[pscustomobject]@{inf=$inf.Name;path=$inf.FullName;sha256=(Get-FileHash -LiteralPath $inf.FullName).Hash}}
 }
}
function Invoke-CameraPackageTool([string[]]$Arguments,[string]$LogPrefix){
 $p=Start-Process -FilePath (Join-Path $env:windir 'System32\pnputil.exe') -ArgumentList $Arguments -WindowStyle Hidden -PassThru -RedirectStandardOutput ($LogPrefix+'.out.log') -RedirectStandardError ($LogPrefix+'.err.log');$null=$p.Handle
 if(-not $p.WaitForExit(90000)){return [pscustomobject]@{pending=$true;pid=$p.Id;creation=$p.StartTime.ToString('o');code=$null}}
 $p.WaitForExit();$p.Refresh();return [pscustomobject]@{pending=$false;pid=0;creation='';code=$p.ExitCode}
}
function Remove-ConflictingSensorExtensions([string]$LogRoot,[object[]]$Candidates){
 New-Item -ItemType Directory -Path $LogRoot -Force|Out-Null
 $report=[ordered]@{status='COMPLETE';removed=@();retained=@();backups=@();rebootRequired=$false;forceUsed=$false}
 foreach($candidate in $Candidates){
  if($candidate.inf -notmatch '^oem\d+\.inf$' -or -not(Test-Path -LiteralPath $candidate.path) -or (Get-FileHash -LiteralPath $candidate.path).Hash -ne $candidate.sha256 -or -not(Test-ConflictingSensorExtension ([IO.File]::ReadAllText($candidate.path)))){
   $report.status='FAILED';$report.retained+=@([ordered]@{inf=$candidate.inf;reason='Extension changed before removal'});break
  }
  $backup=Join-Path $LogRoot ('Backup\'+$candidate.inf);New-Item -ItemType Directory -Path $backup -Force|Out-Null
  $op=Invoke-CameraPackageTool @('/export-driver',$candidate.inf,('"'+$backup+'"')) (Join-Path $LogRoot ($candidate.inf+'-export'))
  if($op.pending){$report.status='PENDING_PROCESS';$report.pendingPid=$op.pid;$report.pendingCreation=$op.creation;break}
  # Export must contain the exact INF, not just an unrelated or partial file.
  $exported=@(Get-ChildItem -LiteralPath $backup -Recurse -File -Filter '*.inf'|Where-Object {(Get-FileHash -LiteralPath $_.FullName).Hash -eq $candidate.sha256})
  if($op.code -ne 0 -or -not $exported.Count){$report.status='FAILED';$report.retained+=@([ordered]@{inf=$candidate.inf;reason='Exact extension backup failed';code=$op.code});break}
  $report.backups+=@([ordered]@{inf=$candidate.inf;path=$backup;sha256=$candidate.sha256})
  # Only a sensor Extension that writes CameraImagesPath reaches /uninstall.
  # Windows removes its association; no main driver or system package is forced out.
  $op=Invoke-CameraPackageTool @('/delete-driver',$candidate.inf,'/uninstall') (Join-Path $LogRoot ($candidate.inf+'-delete'))
  if($op.pending){$report.status='PENDING_PROCESS';$report.pendingPid=$op.pid;$report.pendingCreation=$op.creation;break}
  if($op.code -in 3010,3011){$report.rebootRequired=$true}
  if($op.code -notin 0,3010,3011){$report.status='FAILED';$report.retained+=@([ordered]@{inf=$candidate.inf;reason='Windows could not detach the conflicting sensor extension';code=$op.code});break}
  if(-not(Test-Path -LiteralPath $candidate.path)){$report.removed+=@($candidate.inf)}elseif($report.rebootRequired){$report.status='PENDING_RESTART';$report.retained+=@([ordered]@{inf=$candidate.inf;reason='Removal pending Windows restart'})}else{$report.status='FAILED';$report.retained+=@([ordered]@{inf=$candidate.inf;reason='Extension still present after Windows reported success'});break}
 }
 [IO.File]::WriteAllText((Join-Path $LogRoot 'extensions.json'),($report|ConvertTo-Json -Depth 8),[Text.UTF8Encoding]::new($false));return $report
}
function Remove-UnusedCameraPackages([string]$LogRoot){
 New-Item -ItemType Directory -Path $LogRoot -Force|Out-Null;$report=[ordered]@{status='COMPLETE';removedNodes=@();retainedNodes=@();removed=@();retained=@();rebootRequired=$false;forceUsed=$false}
 $present=@(Get-PnpDevice -PresentOnly -ErrorAction Stop|ForEach-Object InstanceId)
 $devices=@(foreach($d in @(Get-PnpDevice -ErrorAction Stop)){
  $key=Get-Item -LiteralPath ('Registry::HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Enum\'+$d.InstanceId) -ErrorAction SilentlyContinue
  if($key){[pscustomobject]@{id=$d.InstanceId;hardware=@($key.GetValue('HardwareID',@()))}}
 })
 foreach($device in @(Select-StaleCameraDevices $devices $present)){
  # Rescan presence immediately before removing a phantom node. Never use /subtree or /force.
  if($device.id -in @(Get-PnpDevice -PresentOnly -ErrorAction Stop|ForEach-Object InstanceId)){continue}
  $safe=$device.id -replace '[^A-Za-z0-9_-]','_';$out=Join-Path $LogRoot ('node-'+$safe+'.out.log');$err=Join-Path $LogRoot ('node-'+$safe+'.err.log')
  $p=Start-Process -FilePath (Join-Path $env:windir 'System32\pnputil.exe') -ArgumentList @('/remove-device',('"'+$device.id+'"')) -WindowStyle Hidden -PassThru -RedirectStandardOutput $out -RedirectStandardError $err;$null=$p.Handle
  if(-not $p.WaitForExit(90000)){$report.status='PENDING_PROCESS';$report.pendingPid=$p.Id;$report.pendingCreation=$p.StartTime.ToString('o');break};$p.WaitForExit();$p.Refresh()
  if($p.ExitCode -in 3010,3011){$report.rebootRequired=$true}
  if($p.ExitCode -in 0,3010,3011){$report.removedNodes+=@($device.id)}else{$report.retainedNodes+=@([ordered]@{id=$device.id;code=$p.ExitCode})}
 }
 if($report.status -eq 'PENDING_PROCESS'){[IO.File]::WriteAllText((Join-Path $LogRoot 'packages.json'),($report|ConvertTo-Json -Depth 6),[Text.UTF8Encoding]::new($false));return $report}
 foreach($candidate in @(Get-UnusedCameraPackages)){
  $path=Join-Path (Join-Path $env:windir 'INF') $candidate.inf
  if(-not(Test-Path -LiteralPath $path) -or (Get-FileHash -LiteralPath $path).Hash -ne $candidate.sha256 -or (Get-ReferencedDriverInfs).ContainsKey($candidate.inf.ToLowerInvariant())){$report.retained+=@([ordered]@{inf=$candidate.inf;reason='Package changed or is referenced by a device'});continue}
  $out=Join-Path $LogRoot ($candidate.inf+'.out.log');$err=Join-Path $LogRoot ($candidate.inf+'.err.log')
  $p=Start-Process -FilePath (Join-Path $env:windir 'System32\pnputil.exe') -ArgumentList @('/delete-driver',$candidate.inf) -WindowStyle Hidden -PassThru -RedirectStandardOutput $out -RedirectStandardError $err;$null=$p.Handle;if(-not $p.WaitForExit(90000)){$report.status='PENDING_PROCESS';$report.pendingPid=$p.Id;$report.pendingCreation=$p.StartTime.ToString('o');break};$p.WaitForExit();$p.Refresh()
  if($p.ExitCode -in 3010,3011){$report.rebootRequired=$true}
  if(-not(Test-Path -LiteralPath $path)){$report.removed+=@($candidate.inf)}else{$report.retained+=@([ordered]@{inf=$candidate.inf;reason='Windows retained an in-use or protected package';code=$p.ExitCode});$report.status='RETAINED_BY_WINDOWS'}
 }
 [IO.File]::WriteAllText((Join-Path $LogRoot 'packages.json'),($report|ConvertTo-Json -Depth 6),[Text.UTF8Encoding]::new($false));return $report
}
