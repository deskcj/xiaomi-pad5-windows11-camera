﻿function Get-CameraPrerequisitePlan([object[]]$Devices){
 $specs=@(
  [pscustomobject]@{slot='platform';prefix='ACPI\QCOM0535\';hardware='ACPI\QCOM0535';inf='Prerequisites\platform\qccamplatform8150.inf'},
  [pscustomobject]@{slot='jpeg';prefix='ACPI\QCOM0536\';hardware='ACPI\QCOM0536';inf='Prerequisites\jpeg\qccamjpege_ffu8150.inf'},
  [pscustomobject]@{slot='flash';prefix='ACPI\QCOM052A\';hardware='ACPI\QCOM052A';inf='Prerequisites\flash\qccamflash8150.inf'})
 $entries=@(foreach($spec in $specs){$nodes=@($Devices|Where-Object {$_.id.StartsWith($spec.prefix,[StringComparison]::OrdinalIgnoreCase)});[pscustomobject]@{spec=$spec;nodes=$nodes;healthy=($nodes.Count -eq 1 -and $nodes[0].problem -eq 0)}})
 [pscustomobject]@{eligible=($entries[0].nodes.Count -eq 1 -and @($entries|Where-Object {$_.nodes.Count -gt 1}).Count -eq 0);needsRepair=(@($entries|Where-Object {-not $_.healthy}).Count -gt 0);entries=$entries}
}
function Get-PrerequisiteNodes {
 foreach($parent in 'ACPI\QCOM0535','ACPI\QCOM0536','ACPI\QCOM052A'){
  foreach($k in @(Get-ChildItem -LiteralPath ('Registry::HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Enum\'+$parent) -ErrorAction SilentlyContinue)){
   $id=$parent+'\'+$k.PSChildName;if($null -ne (Problem $id)){Node $id}
  }
 }
}
function Repair-CameraPrerequisites {
 $plan=Get-CameraPrerequisitePlan @(Get-PrerequisiteNodes)
 if(-not $plan.eligible){throw 'Qualcomm Camera Platform ACPI device is missing or ambiguous. Check NABU UEFI/base drivers; a camera installer cannot create a missing ACPI platform.'}
 $r.prerequisiteRepair=[ordered]@{attempted=@();before=$plan;status='CHECKING'};Save-State
 if($plan.needsRepair){
  Import-PackageCertificates
  foreach($entry in $plan.entries){$cat=@(Get-ChildItem -LiteralPath (Split-Path -Parent (Join-Path $root $entry.spec.inf)) -Filter '*.cat');if($cat.Count -ne 1 -or (Get-AuthenticodeSignature -LiteralPath $cat[0].FullName).Status -ne 'Valid'){throw ('Prerequisite catalog signature is not trusted: '+$entry.spec.slot)}}
  Progress 8 'Restoring Qualcomm Camera Platform / JPEG / Flash'
  # This gate cannot enumerate physical children until their platform driver exists.
  for($i=0;(Get-Service FrameServer).Status -ne 'Stopped';++$i){if($i -ge 45){throw 'Close camera applications before repairing the camera platform.'};Start-Sleep -Seconds 1}
  if(@(Get-Process WindowsCamera,CameraProbe256,GpuCameraPump -ErrorAction SilentlyContinue).Count){throw 'A camera owner is active; close it before platform repair.'}
  foreach($entry in $plan.entries){
   # Installing the parent can expose already healthy JPEG/Flash children.
   $entry=@((Get-CameraPrerequisitePlan @(Get-PrerequisiteNodes)).entries|Where-Object {$_.spec.slot -eq $entry.spec.slot})[0]
   if($entry.healthy){continue}
   $spec=$entry.spec;$r.prerequisiteRepair.attempted+=@($spec.slot);Save-State
   if($entry.nodes.Count -eq 0){
    $r.driverActions=$true;$null=Run-Child ('prerequisite-stage-'+$spec.slot) "$env:windir\System32\pnputil.exe" @('/add-driver',('"'+(Join-Path $root $spec.inf)+'"')) 90000 -DeferRestart
   }
   elseif($entry.nodes.Count -eq 1 -and $entry.nodes[0].problem -eq 14){$r.rebootRequired=$true;Note ('Prerequisite already requests Windows restart: '+$spec.slot)}
   elseif($entry.nodes.Count -eq 1 -and $entry.nodes[0].problem -eq 22){$r.driverActions=$true;$null=Run-Child ('prerequisite-enable-'+$spec.slot) "$env:windir\System32\pnputil.exe" @('/enable-device',('"'+$entry.nodes[0].id+'"')) -DeferRestart}
   else{
    $inf=Join-Path $root $spec.inf
    # Use only the three bundled, manifest-verified Qualcomm prerequisite INFs.
    # A successful parent update can defer enumeration of its children until reboot.
    # Stage each bundled INF even when those child nodes are not visible yet.
    $r.driverActions=$true;$null=Run-Child ('prerequisite-'+$spec.slot) (Join-Path $root 'Tools\devcon.exe') @('update',('"'+$inf+'"'),$spec.hardware) 90000 -DeferRestart
   }
   $null=Run-Child ('prerequisite-scan-'+$spec.slot) "$env:windir\System32\pnputil.exe" @('/scan-devices') -DeferRestart
  }
 }
 $after=Get-CameraPrerequisitePlan @(Get-PrerequisiteNodes)
 $pending=@($after.entries|Where-Object {-not $_.healthy})
 $deferred=$r.rebootRequired -and @($pending|Where-Object {$_.nodes.Count -gt 1 -or ($_.nodes.Count -eq 1 -and $_.nodes[0].problem -notin 14,28)}).Count -eq 0
 $r.prerequisiteRepair.after=$after;$r.prerequisiteRepair.status=if($deferred){'PENDING_RESTART'}elseif($after.needsRepair){'INCOMPLETE'}else{'COMPLETE'};Save-State
 if($after.needsRepair -and -not $deferred){throw 'Camera platform prerequisites could not be restored. See prerequisite logs; no ISP success is claimed.'}
}
