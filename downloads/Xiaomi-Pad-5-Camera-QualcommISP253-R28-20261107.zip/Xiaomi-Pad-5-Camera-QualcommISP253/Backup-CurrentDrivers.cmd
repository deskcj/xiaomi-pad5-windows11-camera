@echo off
cd /d "%~dp0"
"%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe" -NoProfile -ExecutionPolicy Bypass -File "%~dp0Backup-CurrentDrivers.ps1"
set "CameraBackupExit=%ERRORLEVEL%"
echo.
if not "%CameraBackupExit%"=="0" echo Backup failed. Do not install until a usable backup is saved.
pause
exit /b %CameraBackupExit%
