﻿Qualcomm ISP drivers for Xiaomi Pad 5 on Windows 11
PowerShell installer 1.0.7 / R28 — ISP253, SYS080, DeviceMFT075b

1. Extract the entire ZIP into a folder on the desktop. Do not run inside ZIP.
2. Run Install-QualcommISP.cmd or Install-QualcommISP.ps1 with PowerShell.
   Approve administrator access. Windows 11 ARM64 / Xiaomi Pad 5 (nabu),
   Test Mode enabled and Secure Boot disabled are required and checked.
3. Missing Camera Platform / JPEG / Flash drivers are restored. The bundled
   Qualcomm ISP drivers, active files/settings and both camera streams are checked.
4. If RESTART REQUIRED appears, choose R to restart or L to postpone.
   After signing in, wait about 15 seconds: PowerShell reopens and continues.
   Keep this extracted folder. If it does not reopen, run the same CMD again.
   You may need to approve a new administrator prompt.
5. Wait for 100% / Installation complete. Then this folder can be deleted.

EXE and ZIP use the same engine and driver payload. Successful operations
requiring a restart are batched; repeated unsuccessful restarts stop with a report.
Some old configurations need more than one restart. Real driver errors and
incomplete camera verification are never described as successful installation.

After camera checks, disconnected old native/known virtual camera nodes and
unused camera-only OEM packages are removed with Windows PnP tools.
Before camera checks, conflicting sensor Extension packages that redirect
CameraImagesPath are exported and detached; our stable data path is restored.
Active primary packages, Platform/JPEG/Flash, display/SMMU and unrelated
drivers are retained. No force deletion is used.

Logs and backups: Data\Logs inside this folder.
Installed SYS/INF/CAT: Windows DriverStore.
Permanent camera firmware/tuning/recovery state:
C:\Windows\System32\drivers\XiaomiPad5Camera
Deleting this extracted folder does not delete installed driver data.
The temporary PowerShell logon task is removed after completion or recovery stop.

Driver binaries/tuning remain the accepted 253 payload. This revision fixes
installation, continuation and diagnostic waiting times. Front OV8856 is fixed
focus. Image refinement continues; stable 30 FPS in every scene is not claimed.

Developer: https://t.me/deskcj
Project: https://github.com/deskcj/xiaomi-pad5-windows11-camera
