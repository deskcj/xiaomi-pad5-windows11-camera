@echo off
setlocal EnableExtensions
cd /d "%~dp0"

fltmc >nul 2>&1
if errorlevel 1 (
  echo ERROR: Right-click Install-AV137.cmd and select Run as administrator.
  pause
  exit /b 1
)

if not exist "Tools\devcon.exe" goto incomplete
if not exist "Certificate\NabuCameraDev-20260821.cer" goto incomplete

"Tools\devcon.exe" find "ACPI\QCOM05A4" | findstr /i "QCOM05A4" >nul
if errorlevel 1 goto incompatible
"Tools\devcon.exe" find "ACPI\QCOM0529" | findstr /i "QCOM0529" >nul
if errorlevel 1 goto incompatible

echo [1/6] Installing the public test certificate...
certutil.exe -addstore -f Root "Certificate\NabuCameraDev-20260821.cer" >nul
if errorlevel 1 goto failed
certutil.exe -addstore -f TrustedPublisher "Certificate\NabuCameraDev-20260821.cer" >nul
if errorlevel 1 goto failed

echo [2/6] Disabling the conflicting stock Qualcomm AVStream device if present...
"Tools\devcon.exe" disable "DISPLAY\QCOM_AVStream_8150*" >nul 2>&1

echo [3/6] Installing the front hardware driver...
"Tools\devcon.exe" update "Drivers\Front\Hardware\NabuCamHwFront.inf" "ACPI\QCOM05A4"
if errorlevel 1 goto failed

echo [4/6] Installing the rear hardware driver...
"Tools\devcon.exe" update "Drivers\Rear\Hardware\NabuCamHwRear.inf" "ACPI\QCOM0529"
if errorlevel 1 goto failed

echo [5/6] Installing or updating the front virtual camera...
"Tools\devcon.exe" find "ROOT\NABUCAMVIRTUALFRONT" | findstr /c:"No matching devices found." >nul
if errorlevel 1 (
  "Tools\devcon.exe" update "Drivers\Front\Virtual\NabuCamAvStreamFrontVirtual.inf" "ROOT\NABUCAMVIRTUALFRONT"
) else (
  "Tools\devcon.exe" install "Drivers\Front\Virtual\NabuCamAvStreamFrontVirtual.inf" "ROOT\NABUCAMVIRTUALFRONT"
)
if errorlevel 1 goto failed
"Tools\devcon.exe" enable "ROOT\NABUCAMVIRTUALFRONT" >nul

echo [6/6] Installing or updating the rear virtual camera...
"Tools\devcon.exe" find "ROOT\NABUCAMVIRTUALREAR" | findstr /c:"No matching devices found." >nul
if errorlevel 1 (
  "Tools\devcon.exe" update "Drivers\Rear\Virtual\NabuCamAvStreamRearVirtual.inf" "ROOT\NABUCAMVIRTUALREAR"
) else (
  "Tools\devcon.exe" install "Drivers\Rear\Virtual\NabuCamAvStreamRearVirtual.inf" "ROOT\NABUCAMVIRTUALREAR"
)
if errorlevel 1 goto failed
"Tools\devcon.exe" enable "ROOT\NABUCAMVIRTUALREAR" >nul
pnputil.exe /scan-devices >nul

echo.
echo SUCCESS: both Xiaomi Pad 5 cameras were installed.
echo Open Windows Camera and test front/rear switching.
pause
exit /b 0

:incomplete
echo ERROR: the archive is incomplete. Extract every file before installation.
pause
exit /b 2

:incompatible
echo ERROR: Xiaomi Pad 5 camera hardware QCOM05A4/QCOM0529 was not found.
pause
exit /b 3

:failed
echo.
echo ERROR: installation failed. If Windows requested a restart, restart once and run this installer again.
pause
exit /b 4
