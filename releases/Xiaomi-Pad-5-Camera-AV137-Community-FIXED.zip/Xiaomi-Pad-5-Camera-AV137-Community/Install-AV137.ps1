[CmdletBinding()]
param([switch]$CheckOnly)

$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSCommandPath
$log = Join-Path $root 'install-av137.log'
$devcon = Join-Path $root 'Tools\devcon.exe'
$certificate = Join-Path $root 'Certificate\WDKTestCert-Xiaomi.cer'
$signerThumbprint = '25016B6DA14EA774195E72D2A7FD07DA95255903'

function Write-Log([string]$Message) {
    $line = '{0:yyyy-MM-dd HH:mm:ss} {1}' -f (Get-Date), $Message
    $line | Tee-Object -FilePath $log -Append | Write-Host
}

function Invoke-Devcon([string]$Label, [string[]]$Arguments) {
    Write-Log "BEGIN $Label"
    $output = & $devcon @Arguments 2>&1
    $code = $LASTEXITCODE
    $output | ForEach-Object { Write-Log ([string]$_) }
    if (($output -join "`n") -match '(?i)(reboot|restart).*(required|needed)|(required|needed).*(reboot|restart)') {
        throw "$Label requested a reboot. Reboot once, then run the installer again."
    }
    if ($code -ne 0) { throw "$Label failed with exit code $code." }
    Write-Log "OK $Label"
}

$identity = [Security.Principal.WindowsIdentity]::GetCurrent()
$principal = [Security.Principal.WindowsPrincipal]$identity
if (-not $CheckOnly -and -not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    throw 'Run Install-AV137.cmd as Administrator.'
}
if (-not (Test-Path -LiteralPath $devcon) -or -not (Test-Path -LiteralPath $certificate)) {
    throw 'The archive is incomplete: devcon.exe or the certificate is missing.'
}
$processor = Get-CimInstance Win32_Processor | Select-Object -First 1
if ($processor.Architecture -ne 12) { throw 'This package requires Windows ARM64.' }
$certInfo = New-Object System.Security.Cryptography.X509Certificates.X509Certificate2 $certificate
if ($certInfo.Thumbprint -ne $signerThumbprint) {
    throw 'The bundled certificate does not match the AV137 package signer.'
}
$driverFiles = @(Get-ChildItem -LiteralPath (Join-Path $root 'Drivers') -Recurse -File |
    Where-Object Extension -In '.sys','.cat')
if ($driverFiles.Count -ne 8) { throw "Expected eight signed SYS/CAT files, found $($driverFiles.Count)." }
foreach ($file in $driverFiles) {
    $signature = Get-AuthenticodeSignature -LiteralPath $file.FullName
    if (-not $signature.SignerCertificate -or $signature.SignerCertificate.Thumbprint -ne $signerThumbprint) {
        throw "Wrong or missing driver signer: $($file.Name)"
    }
}
foreach ($relative in @(
    'Drivers\Front\Hardware\NabuCamHwFront.inf',
    'Drivers\Front\Virtual\NabuCamAvStreamFrontVirtual.inf',
    'Drivers\Rear\Hardware\NabuCamHwRear.inf',
    'Drivers\Rear\Virtual\NabuCamAvStreamRearVirtual.inf'
)) {
    if (-not (Test-Path -LiteralPath (Join-Path $root $relative))) { throw "Missing INF: $relative" }
}

$frontAcpi = Get-PnpDevice -PresentOnly | Where-Object InstanceId -Like 'ACPI\QCOM05A4*'
$rearAcpi = Get-PnpDevice -PresentOnly | Where-Object InstanceId -Like 'ACPI\QCOM0529*'
if (-not $frontAcpi -or -not $rearAcpi) {
    throw 'This package is only for Xiaomi Pad 5 (nabu): expected QCOM05A4 and QCOM0529 were not found.'
}
if ($CheckOnly) {
    Write-Host 'AV137 preflight passed: ARM64, front/rear hardware IDs, four INF files, eight signed files and matching certificate.'
    return
}

Set-Content -LiteralPath $log -Value ('AV137 installation started: {0:o}' -f (Get-Date)) -Encoding UTF8
Write-Log "Installing the matching AV137 test-signing certificate ($signerThumbprint)."
& certutil.exe -addstore -f Root $certificate | ForEach-Object { Write-Log ([string]$_) }
if ($LASTEXITCODE -ne 0) { throw 'Could not add the certificate to Trusted Root.' }
& certutil.exe -addstore -f TrustedPublisher $certificate | ForEach-Object { Write-Log ([string]$_) }
if ($LASTEXITCODE -ne 0) { throw 'Could not add the certificate to Trusted Publishers.' }

foreach ($name in 'WindowsCamera','Camera','Telegram','Zoom','Teams','ms-teams','Discord','obs32','obs64') {
    Stop-Process -Name $name -Force -ErrorAction SilentlyContinue
}

# The AV137 bypass stack and the stock Qualcomm AVStream stack must not own the
# same sensors at the same time.
Get-PnpDevice -PresentOnly | Where-Object InstanceId -Like 'DISPLAY\QCOM_AVStream_8150*' | ForEach-Object {
    if ($_.Status -eq 'OK') {
        Write-Log "Disabling stock Qualcomm AVStream: $($_.InstanceId)"
        & pnputil.exe /disable-device $_.InstanceId | ForEach-Object { Write-Log ([string]$_) }
        if ($LASTEXITCODE -ne 0) { throw "Could not disable stock Qualcomm AVStream: $($_.InstanceId)" }
    }
}

Invoke-Devcon 'front hardware backend 222.0.0.34' @(
    'update', (Join-Path $root 'Drivers\Front\Hardware\NabuCamHwFront.inf'), 'ACPI\QCOM05A4'
)
Invoke-Devcon 'rear hardware backend 223.0.0.24' @(
    'update', (Join-Path $root 'Drivers\Rear\Hardware\NabuCamHwRear.inf'), 'ACPI\QCOM0529'
)

function Get-NabuVirtual([string]$HardwareId) {
    @(Get-PnpDevice -PresentOnly -Class Camera -ErrorAction SilentlyContinue | Where-Object {
        $ids = (Get-PnpDeviceProperty -InstanceId $_.InstanceId -KeyName 'DEVPKEY_Device_HardwareIds' -ErrorAction SilentlyContinue).Data
        $ids -contains $HardwareId
    })
}

function Install-VirtualCamera([string]$Label, [string]$Inf, [string]$HardwareId) {
    $existing = @(Get-NabuVirtual $HardwareId)
    if (-not $existing) {
        Invoke-Devcon $Label @('install', $Inf, $HardwareId)
    } else {
        Invoke-Devcon $Label @('update', $Inf, $HardwareId)
    }
    Invoke-Devcon "$Label enable" @('enable', $HardwareId)
    $nodes = @(Get-NabuVirtual $HardwareId | Sort-Object InstanceId -Descending)
    if (-not $nodes) { throw "$Label did not create a present camera device." }
    foreach ($extra in @($nodes | Select-Object -Skip 1)) {
        if ($extra.Status -eq 'OK') {
            Write-Log "Disabling duplicate $Label instance: $($extra.InstanceId)"
            & pnputil.exe /disable-device $extra.InstanceId | ForEach-Object { Write-Log ([string]$_) }
            if ($LASTEXITCODE -ne 0) { throw "Could not disable duplicate camera $($extra.InstanceId)" }
        }
    }
}

Install-VirtualCamera 'front virtual camera 222.0.0.77' `
    (Join-Path $root 'Drivers\Front\Virtual\NabuCamAvStreamFrontVirtual.inf') `
    'ROOT\NABUCAMVIRTUALFRONT'
Install-VirtualCamera 'rear virtual camera 223.0.0.63' `
    (Join-Path $root 'Drivers\Rear\Virtual\NabuCamAvStreamRearVirtual.inf') `
    'ROOT\NABUCAMVIRTUALREAR'

& pnputil.exe /scan-devices | ForEach-Object { Write-Log ([string]$_) }
Start-Sleep -Seconds 3

$expected = @{
    'Xiaomi Pad 5 Front Camera' = '222.0.0.77'
    'Xiaomi Pad 5 Rear Camera'  = '223.0.0.63'
    'Xiaomi Pad 5 Front Camera Hardware Backend' = '222.0.0.34'
    'Xiaomi Pad 5 Rear Camera Hardware Backend'  = '223.0.0.24'
}
foreach ($name in $expected.Keys) {
    $device = Get-PnpDevice -PresentOnly | Where-Object { $_.FriendlyName -eq $name -and $_.Status -eq 'OK' } |
        Sort-Object InstanceId -Descending | Select-Object -First 1
    if (-not $device) { throw "$name was not created." }
    $version = (Get-PnpDeviceProperty -InstanceId $device.InstanceId -KeyName 'DEVPKEY_Device_DriverVersion').Data
    $problem = (Get-PnpDeviceProperty -InstanceId $device.InstanceId -KeyName 'DEVPKEY_Device_ProblemCode').Data
    Write-Log "ACTIVE name=$name instance=$($device.InstanceId) version=$version problem=$problem"
    if ($version -ne $expected[$name] -or $problem -ne 0) {
        throw "$name has unexpected version/state: version=$version problem=$problem"
    }
}

Write-Log 'AV137 installation completed successfully. Open Windows Camera and test both cameras.'
Write-Host ''
Write-Host 'AV137 installed successfully: both Xiaomi Pad 5 cameras are ready.' -ForegroundColor Green
