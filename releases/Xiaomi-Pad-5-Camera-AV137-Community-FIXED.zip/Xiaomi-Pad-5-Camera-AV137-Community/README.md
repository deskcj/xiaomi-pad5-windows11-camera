# Xiaomi Pad 5 cameras for Windows 11 ARM64 — AV137

Experimental front and rear camera drivers for **Xiaomi Pad 5 (nabu)**. This is a test build, not an Android-quality or officially supported release.

## Install (English)

1. On Xiaomi Pad 5 with Windows 11 ARM64, enable Windows Test Mode and disable Secure Boot **before** installing. Test Mode requires a reboot; the installer does not change boot settings or reboot the tablet.
2. Extract the whole ZIP. Double-click `Install-AV137.cmd` and approve the administrator prompt.
3. Wait for `AV137 installed successfully`, then test both cameras in Windows Camera. Do not run the installer directly inside the ZIP.

The package includes both front/rear hardware and virtual drivers, the matching **public** test-signing certificate, and ARM64 DevCon. It does **not** include a private signing key. The installer adds the public certificate to Trusted Root and Trusted Publishers; do this only if you trust this package. Its log is `install-av137.log` beside the installer.

If the front camera still fails, send the install log, the Windows build, and the status/error code of **Xiaomi Pad 5 Front Camera** and **Xiaomi Pad 5 Front Camera Hardware Backend** in Device Manager. A driver version number change alone will not fix an unknown hardware or configuration failure.

## Установка (русский)

1. Нужен Xiaomi Pad 5 (`nabu`) с Windows 11 ARM64. До установки включите тестовый режим Windows и отключите Secure Boot. Изменение тестового режима требует перезагрузки; установщик сам настройки загрузки не меняет и планшет не перезагружает.
2. Полностью распакуйте ZIP. Дважды щёлкните `Install-AV137.cmd` и подтвердите запрос администратора.
3. Дождитесь сообщения `AV137 installed successfully`, затем проверьте обе камеры в приложении «Камера» Windows. Не запускайте установщик прямо из ZIP.

В архиве есть драйверы обеих камер, соответствующий **публичный** сертификат тестовой подписи и ARM64 DevCon. Закрытого ключа подписи в архиве нет. Установщик добавляет сертификат в доверенные хранилища; делайте это только если доверяете пакету. Журнал — `install-av137.log` рядом с установщиком.

Если фронтальная камера не заработала, пришлите журнал установки, версию Windows и код ошибки обоих фронтальных устройств в диспетчере устройств: **Xiaomi Pad 5 Front Camera** и **Xiaomi Pad 5 Front Camera Hardware Backend**. Простое повышение номера версии не устраняет неизвестную аппаратную или конфигурационную причину.

More detail in [README-RU.md](README-RU.md).
