@echo off
setlocal EnableExtensions EnableDelayedExpansion
cd /d "%~dp0"
fltmc >nul 2>&1
if errorlevel 1 (
  set "NABU_INSTALL_CMD=%~f0"
  powershell.exe -NoProfile -Command "try { $p = Start-Process -FilePath $env:NABU_INSTALL_CMD -Verb RunAs -Wait -PassThru; exit $p.ExitCode } catch { Write-Host $_; exit 1 }"
  exit /b !errorlevel!
)
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Install-AV137.ps1"
set "NABU_INSTALL_EXIT=%errorlevel%"
echo.
pause
exit /b %NABU_INSTALL_EXIT%
